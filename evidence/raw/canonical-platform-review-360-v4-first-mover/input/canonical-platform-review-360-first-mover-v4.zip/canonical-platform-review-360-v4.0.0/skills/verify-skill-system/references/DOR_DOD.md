# Verify Skill System — DoR / DoD

Use this as an execution gate. Each criterion must be evidence-backed, `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — At least one source or installed skill root is readable.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-02 — Expected registry/version is known or can be derived.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-03 — Host/client discovery roots can be inspected.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-04 — Structural validator is available or equivalent checks can run.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-05 — Dependency checks can run without revealing secrets.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-06 — Activation smoke test is safe.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-07 — Eval execution, if requested, has runtime/auth budget and authorization.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-08 — Output report path is available.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.

### DoR blockers

- No readable skill source/installation exists.
- Verification would require unauthorized execution or secret disclosure.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Pack structural validator passes or failures are enumerated.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-02 — Installed versus source versions are compared.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-03 — Missing/extra skills are reported.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-04 — Name collisions and shadowing are reported.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-05 — `SKILL.md` and optional `agents/openai.yaml` parse successfully.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-06 — Declared dependencies have READY/MISSING/UNKNOWN status.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-07 — Host catalog visibility is checked when possible.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-08 — At least one bounded activation smoke test is executed when runtime/auth are available.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-09 — Skill eval readiness/results are recorded when requested.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-10 — Mutation/rollback artifacts from installation are still usable.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-11 — Final system posture is READY, DEGRADED, or NOT_READY with reasons.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-12 — Verification report includes next corrective action per failure.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.

## Handoff evidence

- Record source pack/version, target scope/path, host/client, run ID, mode, and authorization boundary.
- Link every FAIL/UNKNOWN criterion to a corrective next action.
- For APPLY, record exact changed paths, rollback/removal method, and post-change verification.
- Do not mark an unexecuted activation or eval as PASS.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available.
