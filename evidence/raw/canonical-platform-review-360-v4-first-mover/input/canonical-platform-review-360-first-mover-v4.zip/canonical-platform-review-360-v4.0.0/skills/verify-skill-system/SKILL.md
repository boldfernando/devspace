---
name: verify-skill-system
description: "Use this skill after skill installation, integration, initialization, upgrades, or execution to verify structural validity, effective discovery, version consistency, collisions, dependency readiness, activation behavior, eval health, and rollback safety. Do not treat file presence alone as proof that a skill is usable."
metadata:
  version: "3.0.0"
  order: "OP05"
  family: skill-system-lifecycle
---

# Verify Skill System

## Objective

Establish whether the skill system is structurally valid, effectively discoverable, activatable, and ready for its intended execution mode.

## Use this skill when

- A skill pack was just installed or upgraded.
- Skills are missing from the client or triggering incorrectly.
- A preflight/health check is needed before automated execution.
- An execution completed and the skill environment must be checked for drift.

## Do not use this skill when

- The request is a product/platform review rather than skill-system health.
- No skill environment or package is available to inspect.

## Required inputs

- Pack source or installed roots
- Expected version/registry
- Target host/client when known
- Expected scope(s)
- Optional eval execution authorization

If an input is unavailable, continue only when execution remains safe and mark the affected state `UNKNOWN`; never fabricate a path, host capability, credential, or authorization.

## Operating rules

- Detect before mutate.
- Default to least privilege and dry-run/READ_ONLY when authorization is ambiguous.
- Preserve project-level trust boundaries; repository skills can contain instructions and must not be silently trusted in a custom client.
- Never expose secret values in logs, receipts, state files, or prompts.
- Do not silently overwrite same-name skills.
- Installation is not integration; integration is not initialization; initialization is not execution; execution is not verification.
- Every mutating stage needs rollback/removal instructions.
- Every executed child skill retains its own DoR/DoD and evidence contract.

## Definition of Ready (DoR)

Evaluate this gate before expensive, active, or mutating work. Use `READY | CONDITIONAL | NOT_READY`.
- [ ] At least one source or installed skill root is readable.
- [ ] Expected registry/version is known or can be derived.
- [ ] Host/client discovery roots can be inspected.
- [ ] Structural validator is available or equivalent checks can run.
- [ ] Dependency checks can run without revealing secrets.
- [ ] Activation smoke test is safe.
- [ ] Eval execution, if requested, has runtime/auth budget and authorization.
- [ ] Output report path is available.

Detailed evidence expectations: `references/DOR_DOD.md`.

## Definition of Done (DoD)

Use `DONE | PARTIAL | NOT_DONE`; file presence or command invocation alone is not completion.
- [ ] Pack structural validator passes or failures are enumerated.
- [ ] Installed versus source versions are compared.
- [ ] Missing/extra skills are reported.
- [ ] Name collisions and shadowing are reported.
- [ ] `SKILL.md` and optional `agents/openai.yaml` parse successfully.
- [ ] Declared dependencies have READY/MISSING/UNKNOWN status.
- [ ] Host catalog visibility is checked when possible.
- [ ] At least one bounded activation smoke test is executed when runtime/auth are available.
- [ ] Skill eval readiness/results are recorded when requested.
- [ ] Mutation/rollback artifacts from installation are still usable.
- [ ] Final system posture is READY, DEGRADED, or NOT_READY with reasons.
- [ ] Verification report includes next corrective action per failure.

### Hard blockers / non-negotiables

- No readable skill source/installation exists.
- Verification would require unauthorized execution or secret disclosure.

## Workflow

1. Run the pack validator.
2. Run `scripts/verify_installation.py` to compare expected registry with installed roots.
3. Inspect effective host discovery and collisions.
4. Optionally perform one explicit activation smoke test in READ_ONLY mode.
5. Run starter evals only when a suitable execution harness and authorization exist.
6. Return READY/DEGRADED/NOT_READY with exact corrective steps.

## Available scripts

- `scripts/verify_installation.py` — deterministic helper for this lifecycle stage. Inspect/dry-run before mutating use.

## Outputs

- skill-system-verification.json
- version/collision report
- activation smoke result
- eval readiness/results

## Handoff contract

Return: scope/host, source and destination identities, stage status, evidence, exact mutations, rollback/removal path, executed verification, blockers/unknowns, and the next lifecycle stage.

## Resources

- Read `references/REFERENCE.md` for the operational protocol.
- Read `references/DOR_DOD.md` before execution.
- Read `references/SOURCES.md` when host behavior or installation paths need current verification.
- Use `evals/evals.json` for trigger/output evals.
- Use `assets/finding-template.json` for standalone structured findings.
