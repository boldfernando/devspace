#!/usr/bin/env python3
from pathlib import Path
import argparse,json,re

def name_of(p):
    try: t=p.read_text(encoding='utf-8')
    except Exception:return None
    m=re.search(r'^name:\s*["\']?([^"\'\n]+)',t,re.M); return m.group(1).strip() if m else None

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--pack-root',default=str(Path(__file__).resolve().parents[3])); ap.add_argument('--installed-root',required=True); args=ap.parse_args()
    pack=Path(args.pack_root); inst=Path(args.installed_root).expanduser().resolve(); reg=json.loads((pack/'skill-registry.json').read_text(encoding='utf-8')); expected={x['name'] for x in reg['skills']}
    actual={d.name for d in inst.iterdir() if d.is_dir() and (d/'SKILL.md').exists()} if inst.exists() else set()
    invalid=[]
    for n in sorted(actual & expected):
        got=name_of(inst/n/'SKILL.md')
        if got!=n: invalid.append({'directory':n,'frontmatter_name':got})
    result={'expected_version':reg.get('version'),'installed_root':str(inst),'expected_count':len(expected),'actual_count':len(actual),'missing':sorted(expected-actual),'extra':sorted(actual-expected),'invalid':invalid,'posture':'READY' if not (expected-actual or invalid) else 'DEGRADED'}
    print(json.dumps(result,indent=2)); raise SystemExit(0 if result['posture']=='READY' else 2)
if __name__=='__main__': main()
