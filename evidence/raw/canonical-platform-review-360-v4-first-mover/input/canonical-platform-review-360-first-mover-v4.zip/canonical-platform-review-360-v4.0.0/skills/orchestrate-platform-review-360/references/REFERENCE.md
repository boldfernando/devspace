# Orchestrate Platform Review 360 Reference Rubric

## Objective

Coordinate the complete evidence-driven review without blurring observation, recommendation, mutation, verification, or release authority.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Baseline captured before change
- No PASS without executed evidence
- P0/P1 findings have reproducible evidence
- Applied changes have rollback and verification
- Final report separates AS-IS, GAP, TO-BE, APPLIED, VERIFIED, and RESIDUAL RISK

## Outputs expected

- review-ledger.json
- finding set
- dependency-aware remediation graph
- gate matrix
- executive 360 report

## Gate interpretation

- G0 repository integrity
- G1 architecture
- G2 product
- G3 contracts
- G4 data
- G5 security
- G6 quality
- G7 UX/a11y/performance
- G8 operations
- G9 release

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
