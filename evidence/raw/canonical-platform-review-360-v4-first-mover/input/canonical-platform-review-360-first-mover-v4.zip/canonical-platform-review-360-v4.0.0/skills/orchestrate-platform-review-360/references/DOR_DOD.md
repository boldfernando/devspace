# Orchestrate Platform Review 360 — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Scope and review objective are explicit.**
  - Evidence: Request, charter, ticket, or review ledger identifies product/repository, intended decision, and in-scope domains.
- [ ] **DOR-02 — Execution mode is explicit.**
  - Evidence: READ_ONLY, PLAN, APPLY, VERIFY, or RELEASE_GATE is recorded; mutation authority is not inferred.
- [ ] **DOR-03 — Authorization boundaries are known.**
  - Evidence: Allowed repositories, environments, accounts, targets, data classes, and destructive/active actions are documented.
- [ ] **DOR-04 — Repository or evidence baseline is accessible.**
  - Evidence: At least one authoritative codebase/workspace or bounded evidence set can be inspected.
- [ ] **DOR-05 — Git/provenance baseline can be established.**
  - Evidence: Current SHA/checkpoint and working-tree provenance are available or explicitly UNKNOWN.
- [ ] **DOR-06 — Environment inventory is bounded.**
  - Evidence: Local/dev/test/staging/production and deployed targets in scope are listed or intentionally excluded.
- [ ] **DOR-07 — Critical product journeys are identified.**
  - Evidence: At least the highest-risk or highest-value user/system journeys are named for prioritization.
- [ ] **DOR-08 — Shared finding/evidence contracts are available.**
  - Evidence: Specialists can emit compatible findings, evidence pointers, statuses, severity, and confidence.
- [ ] **DOR-09 — Specialist dependencies are resolvable.**
  - Evidence: Required domain skills/tools can run or unavailable domains are pre-marked as potential UNKNOWN.
- [ ] **DOR-10 — Safety and secret-handling constraints are defined.**
  - Evidence: Sensitive values, production data, active scanning, and mutation constraints are explicit.
- [ ] **DOR-11 — Decision owner and gate semantics are known.**
  - Evidence: Who consumes GREEN/YELLOW/RED or PASS/PARTIAL/FAIL and what the decision governs are recorded.
- [ ] **DOR-12 — Output location is writable without altering product state.**
  - Evidence: Review artifacts can be emitted independently from production/runtime state.

### DoR blockers

- No execution mode or authorization boundary for requested mutations.
- No authoritative repository/evidence surface from which to establish AS-IS.
- A P0 safety/integrity issue makes further active testing unsafe without containment.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — All scoped domains have an explicit terminal state.**
  - Evidence/acceptance: Each specialist returns PASS, PARTIAL, FAIL, UNKNOWN, or NOT_APPLICABLE with confidence.
- [ ] **DOD-02 — Material claims are evidence-backed.**
  - Evidence/acceptance: Every P0/P1 and release-affecting claim points to reproducible source/runtime/test/metric evidence.
- [ ] **DOD-03 — Cross-domain duplicates are reconciled.**
  - Evidence/acceptance: Symptoms sharing the same root cause are merged or linked instead of inflating finding counts.
- [ ] **DOD-04 — Dependency-aware remediation graph exists.**
  - Evidence/acceptance: Findings are ordered by prerequisites, blast radius, reversibility, and verification dependencies.
- [ ] **DOD-05 — AS-IS, GAP, TO-BE, APPLIED, VERIFIED, and RESIDUAL RISK are separated.**
  - Evidence/acceptance: Report does not blur current facts with recommendations or unverified changes.
- [ ] **DOD-06 — Applied changes have provenance and rollback.**
  - Evidence/acceptance: Every mutation records baseline, patch/change-set, rollback path, and authorization.
- [ ] **DOD-07 — Verification is independent of implementation claims.**
  - Evidence/acceptance: Executed tests/checks prove outcomes; code edits alone never close a finding.
- [ ] **DOD-08 — Unknowns and blockers remain explicit.**
  - Evidence/acceptance: Missing evidence is not promoted to PASS to force a release decision.
- [ ] **DOD-09 — Gate matrix is complete.**
  - Evidence/acceptance: G0-G9 or scoped equivalents have status, evidence, blockers, and owner/disposition.
- [ ] **DOD-10 — Final release/refactor posture is issued.**
  - Evidence/acceptance: GREEN/YELLOW/RED or equivalent decision includes rationale and conditions.
- [ ] **DOD-11 — Prioritized roadmap is actionable.**
  - Evidence/acceptance: P0-P4 backlog includes owner/next action, dependencies, verification, and acceptance criteria where known.
- [ ] **DOD-12 — Review artifacts are integrity-checkable.**
  - Evidence/acceptance: Final report, ledgers, findings, and generated manifests/checksums are stored consistently.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
