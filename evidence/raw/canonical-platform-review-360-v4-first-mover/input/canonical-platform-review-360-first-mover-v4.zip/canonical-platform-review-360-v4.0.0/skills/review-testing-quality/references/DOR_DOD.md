# Review Testing and Quality — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Test frameworks and commands are discoverable.**
  - Evidence: Existing test/lint/typecheck tooling and package-manager authority are known.
- [ ] **DOR-02 — Critical journeys/business rules are identified.**
  - Evidence: Quality is measured against behavior, not only line coverage.
- [ ] **DOR-03 — Test environments/fixtures are available.**
  - Evidence: Tests can run reproducibly without uncontrolled production dependencies.
- [ ] **DOR-04 — Current CI quality gates are inspectable.**
  - Evidence: Local results can be compared with pipeline expectations.
- [ ] **DOR-05 — Known flaky/quarantined tests are identifiable.**
  - Evidence: Skipped tests are not silently treated as coverage.
- [ ] **DOR-06 — Contract/auth/migration risks are known.**
  - Evidence: High-risk test dimensions receive priority.
- [ ] **DOR-07 — External service mocking/sandbox policy is known.**
  - Evidence: Deterministic tests do not accidentally call production providers.
- [ ] **DOR-08 — Baseline test result can be captured before APPLY.**
  - Evidence: Regressions can be attributed.

### DoR blockers

- No executable verification path for requested code changes.
- Test execution would contact prohibited production systems or mutate sensitive data.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Test inventory is mapped by layer.**
  - Evidence/acceptance: Static/unit/component/contract/integration/E2E/performance/security/migration coverage is recorded.
- [ ] **DOD-02 — Critical journey coverage is assessed.**
  - Evidence/acceptance: Priority user/system flows have executable proof or explicit gaps.
- [ ] **DOD-03 — Business-rule coverage is assessed.**
  - Evidence/acceptance: Domain invariants and edge cases are represented beyond rendering tests.
- [ ] **DOD-04 — Authorization/permission coverage is assessed.**
  - Evidence/acceptance: Critical role/resource matrix rows are tested.
- [ ] **DOD-05 — Failure/recovery coverage is assessed.**
  - Evidence/acceptance: Negative paths, provider failures, validation, timeouts, and retries are represented.
- [ ] **DOD-06 — Contract coverage is assessed.**
  - Evidence/acceptance: Producer/consumer schemas and breaking changes have tests where material.
- [ ] **DOD-07 — Migration/data integrity coverage is assessed.**
  - Evidence/acceptance: Schema evolution and invariants are tested when relevant.
- [ ] **DOD-08 — Tests are actually executed.**
  - Evidence/acceptance: Pass/fail/skip counts and commands are captured; unrun suites are UNKNOWN.
- [ ] **DOD-09 — Flakiness/skips are triaged.**
  - Evidence/acceptance: A green run with critical skips does not become false PASS.
- [ ] **DOD-10 — Fixtures are deterministic and safe.**
  - Evidence/acceptance: Tests do not depend on uncontrolled real accounts/data.
- [ ] **DOD-11 — CI gates match risk.**
  - Evidence/acceptance: Required suites block merge/release appropriately or gap is documented.
- [ ] **DOD-12 — Quality gate state is issued with evidence.**
  - Evidence/acceptance: Coverage percentages alone do not decide readiness.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
