# Review Testing and Quality Reference Rubric

## Objective

Determine whether the test system proves the behaviors that matter and whether failures are reproducible in CI/local environments.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Skipped tests never counted as PASS
- Critical auth/payment/data flows have integration/E2E evidence
- Flakiness tracked separately
- Test commands match repo package-manager authority

## Outputs expected

- TEST_INVENTORY.json
- CRITICAL_COVERAGE_MATRIX.json
- FLAKINESS_REGISTER.json
- TEST_STRATEGY.md

## Gate interpretation

- Authoritative test baseline reproducible
- Critical paths covered
- No unresolved P0/P1 regression

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
