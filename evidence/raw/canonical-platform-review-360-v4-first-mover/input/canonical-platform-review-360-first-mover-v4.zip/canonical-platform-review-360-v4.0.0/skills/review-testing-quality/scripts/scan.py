#!/usr/bin/env python3
"""Find test configuration and test files, emitting JSON only."""
import json, sys
from pathlib import Path
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
configs=[]; tests=[]
for p in root.rglob('*'):
    if any(part in {'.git','node_modules','.next','dist','build'} for part in p.parts): continue
    if not p.is_file(): continue
    n=p.name.lower()
    rel=str(p.relative_to(root))
    if any(k in n for k in ['playwright.config','vitest.config','jest.config','pytest.ini','tox.ini']): configs.append(rel)
    if any(n.endswith(s) for s in ['.test.ts','.test.tsx','.spec.ts','.spec.tsx','_test.py','test.py']): tests.append(rel)
print(json.dumps({'root':str(root),'configs':sorted(configs),'tests':sorted(tests)},indent=2))
