# Review Frontend Architecture Reference Rubric

## Objective

Find architectural causes of frontend complexity, stale state, rendering waste, hydration issues, and data-flow fragility without premature rewrites.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- No duplicate source of truth
- Critical data invalidation understood
- Hydration/console errors checked
- Optimization tied to evidence

## Outputs expected

- FRONTEND_ARCHITECTURE_MAP.json
- STATE_OWNERSHIP_MAP.json
- RENDERING_FINDINGS.json
- FRONTEND_REFACTOR_PLAN.md

## Gate interpretation

- Critical routes stable
- No unresolved critical hydration/race issue
- State ownership explicit

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
