# Review Frontend Architecture — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Frontend framework/version is detected.**
  - Evidence: React/Next/Vite/TanStack/etc. is established from manifests/runtime rather than assumed.
- [ ] **DOR-02 — Build/typecheck/test commands are known or discoverable.**
  - Evidence: Architecture changes can be verified.
- [ ] **DOR-03 — Routing and entrypoints are identifiable.**
  - Evidence: App/router structure and major layout boundaries are available.
- [ ] **DOR-04 — Data-access layer is identifiable.**
  - Evidence: API clients, server actions/loaders, query libraries, and caching layers are visible.
- [ ] **DOR-05 — State-management authorities are known.**
  - Evidence: Local/global/server state tools and ownership are discoverable.
- [ ] **DOR-06 — Client/server rendering boundaries can be inspected.**
  - Evidence: SSR/SSG/CSR/RSC or equivalent boundaries are available when applicable.
- [ ] **DOR-07 — Critical routes/components are prioritized.**
  - Evidence: Review avoids optimizing irrelevant code first.
- [ ] **DOR-08 — Performance/UX baseline exists or will be measured separately.**
  - Evidence: Architectural recommendations are tied to user impact.

### DoR blockers

- Frontend runtime cannot be identified with acceptable confidence.
- No verification path exists for requested APPLY and change risk is material.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Component/module boundaries are assessed.**
  - Evidence/acceptance: Oversized/duplicated/coupled components and ownership boundaries are evidenced.
- [ ] **DOD-02 — State ownership is coherent.**
  - Evidence/acceptance: Local, global, server, URL, and form state are not duplicated without rationale.
- [ ] **DOD-03 — Hooks/effects are reviewed for correctness.**
  - Evidence/acceptance: Effects, dependencies, subscriptions, and derived state avoid avoidable loops/staleness.
- [ ] **DOD-04 — Data-fetch waterfalls/duplication are identified.**
  - Evidence/acceptance: Critical route network/data dependencies are mapped.
- [ ] **DOD-05 — Caching/revalidation behavior is understood.**
  - Evidence/acceptance: Cache authority, invalidation, freshness, and optimistic updates are explicit.
- [ ] **DOD-06 — Hydration/rendering boundaries are safe.**
  - Evidence/acceptance: Mismatch, excessive client bundles, blocking rendering, or accidental dynamic behavior is identified.
- [ ] **DOD-07 — Forms/error/loading states are architecturally supported.**
  - Evidence/acceptance: Critical interaction states are not one-off hacks.
- [ ] **DOD-08 — Code splitting/lazy loading is measured where relevant.**
  - Evidence/acceptance: Bundle changes follow measured route/component cost.
- [ ] **DOD-09 — Error boundaries/recovery paths exist where needed.**
  - Evidence/acceptance: Frontend failures degrade predictably.
- [ ] **DOD-10 — Applied refactors pass static and behavioral verification.**
  - Evidence/acceptance: Build/typecheck/tests and critical journeys are rerun.
- [ ] **DOD-11 — No framework-specific advice is applied to the wrong runtime.**
  - Evidence/acceptance: Recommendations cite detected architecture.
- [ ] **DOD-12 — Residual architectural debt is prioritized by impact.**
  - Evidence/acceptance: Style preferences do not outrank correctness/performance risks.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
