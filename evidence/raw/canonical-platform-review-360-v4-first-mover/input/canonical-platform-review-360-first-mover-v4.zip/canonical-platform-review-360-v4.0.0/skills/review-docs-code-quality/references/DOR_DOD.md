# Review Documentation and Code Quality — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Repository and documentation surfaces are readable.**
  - Evidence: README/docs/ADRs/runbooks/config/comments/source are accessible.
- [ ] **DOR-02 — Runtime architecture baseline is available or discoverable.**
  - Evidence: Documentation can be compared against actual behavior.
- [ ] **DOR-03 — Build/test/onboarding paths are known or testable.**
  - Evidence: Doc correctness can be validated.
- [ ] **DOR-04 — Project coding/lint/type conventions are identifiable.**
  - Evidence: Quality review respects existing intentional standards.
- [ ] **DOR-05 — Ownership/domain boundaries are discoverable.**
  - Evidence: Coupling and documentation gaps can be assigned appropriately.
- [ ] **DOR-06 — TODO/issue/deprecation sources are accessible when in scope.**
  - Evidence: Known debt can be reconciled with code reality.
- [ ] **DOR-07 — Generated/vendor code boundaries are known.**
  - Evidence: Quality findings avoid irrelevant third-party/generated artifacts.
- [ ] **DOR-08 — Refactor APPLY has a verification path.**
  - Evidence: Structural changes can be typechecked/tested/built.

### DoR blockers

- Requested structural refactor has no executable verification path.
- Documentation cannot be compared to any authoritative implementation/runtime evidence.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Documentation inventory is produced.**
  - Evidence/acceptance: Architecture, onboarding, environment, API, runbook, ADR, contribution and operational docs are located.
- [ ] **DOD-02 — Documentation drift/contradictions are evidenced.**
  - Evidence/acceptance: Stale commands, wrong architecture, missing env contracts, or obsolete diagrams are identified.
- [ ] **DOD-03 — Architecture decisions are sufficiently captured.**
  - Evidence/acceptance: Material non-obvious constraints have ADR/decision context or gap is explicit.
- [ ] **DOD-04 — Onboarding path is executable or gaps are clear.**
  - Evidence/acceptance: A new engineer can reach install/build/test/dev with known prerequisites.
- [ ] **DOD-05 — Operational runbooks cover critical tasks.**
  - Evidence/acceptance: Deploy/rollback/incident/data recovery or equivalent procedures exist where required.
- [ ] **DOD-06 — Dead/duplicate code is identified with evidence.**
  - Evidence/acceptance: Removal recommendations consider runtime/import/reflection/build behavior.
- [ ] **DOD-07 — Coupling/circular dependencies are assessed.**
  - Evidence/acceptance: Structural hotspots have concrete dependency evidence.
- [ ] **DOD-08 — Hidden side effects/magic values/type gaps are prioritized.**
  - Evidence/acceptance: Findings focus on correctness/maintenance risk, not cosmetics.
- [ ] **DOD-09 — TODO/deprecation debt is triaged.**
  - Evidence/acceptance: Unowned/stale/high-risk debt is separated from harmless notes.
- [ ] **DOD-10 — Applied refactors preserve behavior.**
  - Evidence/acceptance: Static tests/build/critical journeys are rerun.
- [ ] **DOD-11 — Updated docs match verified reality.**
  - Evidence/acceptance: Documentation changes reflect actual commands/runtime after patches.
- [ ] **DOD-12 — Maintainability gate state is issued.**
  - Evidence/acceptance: Style-only issues do not falsely block release; material operational drift can.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
