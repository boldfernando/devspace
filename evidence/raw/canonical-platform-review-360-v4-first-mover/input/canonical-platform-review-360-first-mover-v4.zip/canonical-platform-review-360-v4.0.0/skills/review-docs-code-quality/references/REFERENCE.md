# Review Documentation and Code Quality Reference Rubric

## Objective

Reduce maintainability risk by aligning documentation and code structure with the architecture that actually runs.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Docs claims verified against source/runtime
- Code-quality finding includes impact
- No style-only P0/P1
- Refactors preserve behavior via tests

## Outputs expected

- DOC_DRIFT.json
- CODE_QUALITY_FINDINGS.json
- ARCHITECTURE_DEBT.json
- DOCS_REFACTOR_PLAN.md

## Gate interpretation

- Critical runbooks/environment docs adequate
- No severe undocumented architecture drift
- High-risk refactor areas covered by tests

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
