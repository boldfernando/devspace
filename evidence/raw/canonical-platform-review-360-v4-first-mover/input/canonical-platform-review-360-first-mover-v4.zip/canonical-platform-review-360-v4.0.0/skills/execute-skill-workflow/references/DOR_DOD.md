# Execute Skill Workflow — DoR / DoD

Use this as an execution gate. Each criterion must be evidence-backed, `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Requested task is explicit.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-02 — Selected skill exists in the effective catalog.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-03 — Runtime state is current or deliberately refreshed.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-04 — Skill DoR has been evaluated.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-05 — Execution mode matches authorization.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-06 — Required tools/dependencies are available or marked UNKNOWN.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-07 — Read/write conflict policy is defined for multi-skill runs.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-08 — Output capture path is available.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-09 — Host authentication exists when a remote/model execution is required.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-10 — No hard blocker from a prerequisite skill is being ignored.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.

### DoR blockers

- No effective installed skill matches an explicitly required skill name.
- APPLY is requested without write authorization or adequate sandbox boundary.
- A prerequisite hard blocker makes execution unsafe.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Every planned skill has terminal execution status.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-02 — Explicit skill activation is recorded.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-03 — Actual host/model execution is distinguishable from planning.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-04 — Each skill returns evidence pointers and DoD/gate status.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-05 — Read-heavy parallel work is reconciled before writes.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-06 — Conflicting write-heavy skills are serialized or isolated.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-07 — APPLY runs record changed files/state and rollback.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-08 — Verification commands actually executed are recorded.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-09 — Failed/blocked skill runs remain failed/blocked rather than being summarized away.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-10 — Final ledger links parent task to child skill runs.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-11 — Machine-readable output is produced when requested.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-12 — Residual UNKNOWN/PARTIAL states are preserved.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.

## Handoff evidence

- Record source pack/version, target scope/path, host/client, run ID, mode, and authorization boundary.
- Link every FAIL/UNKNOWN criterion to a corrective next action.
- For APPLY, record exact changed paths, rollback/removal method, and post-change verification.
- Do not mark an unexecuted activation or eval as PASS.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available.
