#!/usr/bin/env python3
from pathlib import Path
import argparse,json

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--pack-root',default=str(Path(__file__).resolve().parents[3])); ap.add_argument('--skills',nargs='+',required=True); ap.add_argument('--mode',default='READ_ONLY'); args=ap.parse_args()
    reg=json.loads((Path(args.pack_root)/'skill-registry.json').read_text(encoding='utf-8')); names={s['name'] for s in reg['skills']}; missing=[s for s in args.skills if s not in names]
    print(json.dumps({'mode':args.mode,'requested':args.skills,'missing':missing,'lanes':{'parallel_read_candidates':[s for s in args.skills if args.mode!='APPLY'],'serialized_write_candidates':args.skills if args.mode=='APPLY' else []}},indent=2)); raise SystemExit(2 if missing else 0)
if __name__=='__main__': main()
