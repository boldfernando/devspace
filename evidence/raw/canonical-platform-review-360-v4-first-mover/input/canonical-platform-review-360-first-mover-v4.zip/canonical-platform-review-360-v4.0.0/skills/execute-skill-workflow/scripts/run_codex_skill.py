#!/usr/bin/env python3
import argparse, json, shutil, subprocess, sys
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(description='Invoke an installed skill explicitly through codex exec.')
    ap.add_argument('skill')
    ap.add_argument('task', nargs='+')
    ap.add_argument('--workspace',default='.')
    ap.add_argument('--mode',choices=['READ_ONLY','PLAN','APPLY','VERIFY','RELEASE_GATE'],default='READ_ONLY')
    ap.add_argument('--json',action='store_true')
    ap.add_argument('--ephemeral',action='store_true')
    ap.add_argument('--output')
    ap.add_argument('--dry-run',action='store_true')
    args=ap.parse_args()
    codex=shutil.which('codex')
    prompt=f"${args.skill} " + ' '.join(args.task) + f"\nExecution mode: {args.mode}. Evaluate the skill DoR before work and its DoD before completion. Preserve evidence, blockers, unknowns, and rollback boundaries."
    if args.dry_run:
        preview=['codex','exec']
        if args.mode=='APPLY': preview += ['--sandbox','workspace-write']
        if args.json: preview.append('--json')
        if args.ephemeral: preview.append('--ephemeral')
        if args.output: preview += ['--output-last-message',args.output]
        preview.append('<prompt>')
        print(json.dumps({'status':'DRY_RUN','cwd':str(Path(args.workspace).resolve()),'codex_available':bool(codex),'command':preview,'prompt':prompt},indent=2)); return
    if not codex:
        print(json.dumps({'status':'BLOCKED','reason':'codex executable not found'})); raise SystemExit(2)
    cmd=[codex,'exec']
    if args.mode=='APPLY': cmd += ['--sandbox','workspace-write']
    # READ_ONLY is the default codex exec sandbox; keep least privilege.
    if args.json: cmd.append('--json')
    if args.ephemeral: cmd.append('--ephemeral')
    if args.output: cmd += ['--output-last-message',args.output]
    cmd.append(prompt)
    raise SystemExit(subprocess.call(cmd,cwd=Path(args.workspace).resolve()))
if __name__=='__main__': main()
