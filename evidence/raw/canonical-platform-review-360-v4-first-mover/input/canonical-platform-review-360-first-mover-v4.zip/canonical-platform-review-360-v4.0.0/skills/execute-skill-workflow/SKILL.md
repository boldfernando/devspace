---
name: execute-skill-workflow
description: "Use this skill when installed skills must actually run against a task. Select explicit skills or route by description, evaluate each skill DoR, execute read-heavy work in safe parallel lanes when supported, serialize conflicting writes, enforce mode/approval boundaries, and collect DoD/evidence/gates into one execution ledger."
metadata:
  version: "3.0.0"
  order: "OP04"
  family: skill-system-lifecycle
---

# Execute Skill Workflow

## Objective

Run one or more skills as an evidence-backed workflow with explicit activation, bounded permissions, sequencing, and completion semantics.

## Use this skill when

- A user asks to run a named skill or a multi-skill workflow.
- A CI/CLI job must invoke a skill non-interactively.
- A manager agent must coordinate several specialists and collect their results.

## Do not use this skill when

- Skills are not installed/integrated/initialized yet.
- The user only wants an execution plan with no actual run; PLAN mode can be used but must not be reported as executed.

## Required inputs

- Task/prompt
- Selected skill names or routing permission
- Initialized runtime state
- Execution mode
- Concurrency policy
- Output directory/schema when automation requires structured results

If an input is unavailable, continue only when execution remains safe and mark the affected state `UNKNOWN`; never fabricate a path, host capability, credential, or authorization.

## Operating rules

- Detect before mutate.
- Default to least privilege and dry-run/READ_ONLY when authorization is ambiguous.
- Preserve project-level trust boundaries; repository skills can contain instructions and must not be silently trusted in a custom client.
- Never expose secret values in logs, receipts, state files, or prompts.
- Do not silently overwrite same-name skills.
- Installation is not integration; integration is not initialization; initialization is not execution; execution is not verification.
- Every mutating stage needs rollback/removal instructions.
- Every executed child skill retains its own DoR/DoD and evidence contract.

## Definition of Ready (DoR)

Evaluate this gate before expensive, active, or mutating work. Use `READY | CONDITIONAL | NOT_READY`.
- [ ] Requested task is explicit.
- [ ] Selected skill exists in the effective catalog.
- [ ] Runtime state is current or deliberately refreshed.
- [ ] Skill DoR has been evaluated.
- [ ] Execution mode matches authorization.
- [ ] Required tools/dependencies are available or marked UNKNOWN.
- [ ] Read/write conflict policy is defined for multi-skill runs.
- [ ] Output capture path is available.
- [ ] Host authentication exists when a remote/model execution is required.
- [ ] No hard blocker from a prerequisite skill is being ignored.

Detailed evidence expectations: `references/DOR_DOD.md`.

## Definition of Done (DoD)

Use `DONE | PARTIAL | NOT_DONE`; file presence or command invocation alone is not completion.
- [ ] Every planned skill has terminal execution status.
- [ ] Explicit skill activation is recorded.
- [ ] Actual host/model execution is distinguishable from planning.
- [ ] Each skill returns evidence pointers and DoD/gate status.
- [ ] Read-heavy parallel work is reconciled before writes.
- [ ] Conflicting write-heavy skills are serialized or isolated.
- [ ] APPLY runs record changed files/state and rollback.
- [ ] Verification commands actually executed are recorded.
- [ ] Failed/blocked skill runs remain failed/blocked rather than being summarized away.
- [ ] Final ledger links parent task to child skill runs.
- [ ] Machine-readable output is produced when requested.
- [ ] Residual UNKNOWN/PARTIAL states are preserved.

### Hard blockers / non-negotiables

- No effective installed skill matches an explicitly required skill name.
- APPLY is requested without write authorization or adequate sandbox boundary.
- A prerequisite hard blocker makes execution unsafe.

## Workflow

1. Resolve explicit skill names first; otherwise route by skill descriptions.
2. Evaluate each selected skill DoR before expensive/active work.
3. Build a dependency DAG and identify read-only parallel lanes versus conflicting writes.
4. For Codex automation, use `scripts/run_codex_skill.py`; `codex exec` is read-only by default and APPLY maps to `--sandbox workspace-write`.
5. For interactive Codex, invoke the skill explicitly with `$skill-name`; ChatGPT skill selection can use `@` when available.
6. Collect child outputs, verify DoD, reconcile contradictions, and emit one execution ledger.

## Available scripts

- `scripts/run_codex_skill.py` — deterministic helper for this lifecycle stage. Inspect/dry-run before mutating use.
- `scripts/plan_execution.py` — deterministic helper for this lifecycle stage. Inspect/dry-run before mutating use.

## Outputs

- skill-execution-ledger.json
- per-skill result artifacts
- verification evidence
- residual risk/unknown report

## Handoff contract

Return: scope/host, source and destination identities, stage status, evidence, exact mutations, rollback/removal path, executed verification, blockers/unknowns, and the next lifecycle stage.

## Resources

- Read `references/REFERENCE.md` for the operational protocol.
- Read `references/DOR_DOD.md` before execution.
- Read `references/SOURCES.md` when host behavior or installation paths need current verification.
- Use `evals/evals.json` for trigger/output evals.
- Use `assets/finding-template.json` for standalone structured findings.
