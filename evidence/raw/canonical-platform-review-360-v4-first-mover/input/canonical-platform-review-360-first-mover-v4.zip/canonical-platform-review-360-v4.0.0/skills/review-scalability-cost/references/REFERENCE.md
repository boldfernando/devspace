# Review Scalability and Cost Reference Rubric

## Objective

Build a capacity and cost model that identifies real bottlenecks, scaling thresholds, and economic failure modes before traffic increases.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Assumptions separated from measurements
- Provider prices dated/source-linked
- Load tests authorized
- Cost optimization does not violate reliability/security

## Outputs expected

- CAPACITY_MODEL.json
- BOTTLENECK_GRAPH.json
- COST_MODEL.json
- SCALING_THRESHOLDS.json
- SCALABILITY_PLAN.md

## Gate interpretation

- Known launch capacity
- Critical quotas monitored
- Cost guardrails defined

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
