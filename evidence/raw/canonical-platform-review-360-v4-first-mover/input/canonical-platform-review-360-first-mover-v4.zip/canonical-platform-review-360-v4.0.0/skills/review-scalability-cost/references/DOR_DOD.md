# Review Scalability and Cost — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Representative workload is characterized.**
  - Evidence: Traffic, concurrency, payload size, job volume, or user behavior has a baseline or bounded assumptions.
- [ ] **DOR-02 — Performance/SLO targets are known.**
  - Evidence: Capacity is evaluated against an outcome, not “scale infinitely”.
- [ ] **DOR-03 — Infrastructure/runtime limits are discoverable.**
  - Evidence: CPU/memory/connections/instances/queues/serverless limits are known.
- [ ] **DOR-04 — Database/cache/network/provider quotas are identifiable.**
  - Evidence: External constraints are included in the capacity model.
- [ ] **DOR-05 — Cost evidence is available or uncertainty is explicit.**
  - Evidence: Cloud/provider/LLM/storage/egress cost inputs are sourced when possible.
- [ ] **DOR-06 — Load testing authorization is explicit.**
  - Evidence: Concurrency tests do not target production without permission.
- [ ] **DOR-07 — Critical workload mix is known.**
  - Evidence: Read/write/background/compute-intensive/external-service paths are separated where material.
- [ ] **DOR-08 — Existing autoscaling/caching strategy is inspectable.**
  - Evidence: Recommendations can build on current mechanisms.

### DoR blockers

- No meaningful workload/SLO information exists for a quantitative scalability claim.
- Requested load test lacks target authorization or safe capacity guardrails.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Capacity model is documented.**
  - Evidence/acceptance: Workload units, concurrency, throughput, utilization, and bottleneck assumptions are explicit.
- [ ] **DOD-02 — Measured bottlenecks are identified.**
  - Evidence/acceptance: CPU/memory/DB/cache/network/provider constraints have evidence where feasible.
- [ ] **DOD-03 — Database/connections are assessed.**
  - Evidence/acceptance: Pool size, query cost, contention, and limit behavior are considered.
- [ ] **DOD-04 — Cache strategy is assessed.**
  - Evidence/acceptance: Hit rate, invalidation, memory/cost, and failure behavior are included.
- [ ] **DOD-05 — Provider quotas/rate limits are modeled.**
  - Evidence/acceptance: External dependencies cannot surprise scale-out plans.
- [ ] **DOD-06 — Autoscaling thresholds and saturation signals are defined.**
  - Evidence/acceptance: Scale policy is tied to leading indicators and SLOs.
- [ ] **DOD-07 — Cost unit economics are estimated.**
  - Evidence/acceptance: Cost/request, session, conversion, workload, or token-intensive operation is calculated where data allows.
- [ ] **DOD-08 — Load test results match the modeled workload when authorized.**
  - Evidence/acceptance: Smoke/average/stress/spike/soak claims include scenario and environment.
- [ ] **DOD-09 — Performance-cost tradeoffs are explicit.**
  - Evidence/acceptance: Recommendations quantify or describe marginal cost and benefit.
- [ ] **DOD-10 — Failure/degraded capacity is considered.**
  - Evidence/acceptance: Single-region/provider/cache failure does not invalidate the plan.
- [ ] **DOD-11 — Scaling recommendations are prioritized by evidence.**
  - Evidence/acceptance: Speculative re-platforming is not presented as necessary.
- [ ] **DOD-12 — Scalability/cost gate state is issued.**
  - Evidence/acceptance: Capacity UNKNOWN remains visible when workload data is missing.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
