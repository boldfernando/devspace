# Primary and Authoritative Sources

Verify applicability and current version before relying on a source.

- [Agent Skills Specification](https://agentskills.io/specification)
- [Agent Skills Client Integration](https://agentskills.io/client-implementation/adding-skills-support)
- [Agent Skills Best Practices](https://agentskills.io/skill-creation/best-practices)
- [Agent Skills Scripts Guide](https://agentskills.io/skill-creation/using-scripts)
- [Agent Skills Evaluation Guide](https://agentskills.io/skill-creation/evaluating-skills)
- [OpenAI Build Skills](https://developers.openai.com/codex/skills)
- [OpenAI Codex Non-interactive Mode](https://developers.openai.com/codex/non-interactive-mode)
- [OpenAI Codex Agent Approvals and Security](https://developers.openai.com/codex/agent-approvals-security)
- [OpenAI Codex Subagents](https://developers.openai.com/codex/subagents)
- [OpenAI Agents SDK](https://openai.github.io/openai-agents-python/)
- [OpenAI Agents SDK Skills Capability](https://openai.github.io/openai-agents-python/ref/sandbox/capabilities/skills/)
- [OpenAI Sandbox Agents](https://openai.github.io/openai-agents-python/sandbox_agents/)
