---
name: bootstrap-skill-system
description: "Use this skill when a skill pack must be made operational end to end: detect the host, install the pack, integrate discovery/runtime boundaries, initialize execution state, run requested skills, and verify the result. Orchestrate the lifecycle skills without bypassing their DoR/DoD or approval gates."
metadata:
  version: "3.0.0"
  order: "OP00"
  family: skill-system-lifecycle
---

# Bootstrap Skill System

## Objective

Coordinate the complete skill-system lifecycle from package evidence to a verified executable skill environment.

## Use this skill when

- A user asks to set up, bootstrap, activate, or run a complete skill pack.
- The host/runtime is not yet known and installation plus execution must be coordinated.
- A reproducible install → integrate → initialize → execute → verify chain is required.

## Do not use this skill when

- Only one already-installed specialist skill needs to perform its domain job.
- The user only wants to inspect skill source without installing or executing it.

## Required inputs

- Skill pack root or package artifact
- Target workspace/repository when repo-scoped operation is intended
- Requested scope: repo, user, admin, sandbox, or explicit custom destination
- Requested execution mode: READ_ONLY, PLAN, APPLY, VERIFY, or RELEASE_GATE
- Authorization boundary for filesystem/runtime changes

If an input is unavailable, continue only when execution remains safe and mark the affected state `UNKNOWN`; never fabricate a path, host capability, credential, or authorization.

## Operating rules

- Detect before mutate.
- Default to least privilege and dry-run/READ_ONLY when authorization is ambiguous.
- Preserve project-level trust boundaries; repository skills can contain instructions and must not be silently trusted in a custom client.
- Never expose secret values in logs, receipts, state files, or prompts.
- Do not silently overwrite same-name skills.
- Installation is not integration; integration is not initialization; initialization is not execution; execution is not verification.
- Every mutating stage needs rollback/removal instructions.
- Every executed child skill retains its own DoR/DoD and evidence contract.

## Definition of Ready (DoR)

Evaluate this gate before expensive, active, or mutating work. Use `READY | CONDITIONAL | NOT_READY`.
- [ ] Pack root or package artifact is readable.
- [ ] Target host/runtime can be identified or safely classified UNKNOWN.
- [ ] Installation scope is explicit or can remain PLAN-only.
- [ ] Mutation authorization is explicit before copy/symlink/config writes.
- [ ] Pack validator is available or equivalent structural validation can run.
- [ ] Target repository/workspace provenance can be established when repo-scoped.
- [ ] Collision policy is known before replacing existing skill names.
- [ ] Runtime credentials are not required for install-only stages.
- [ ] Output/state location is writable without altering unrelated product state.
- [ ] Requested skill/task is bounded enough to plan execution.

Detailed evidence expectations: `references/DOR_DOD.md`.

## Definition of Done (DoD)

Use `DONE | PARTIAL | NOT_DONE`; file presence or command invocation alone is not completion.
- [ ] Host/runtime and supported discovery path are recorded.
- [ ] Pack structural validation completed.
- [ ] Installation result is verified or explicitly skipped.
- [ ] Integration/discovery result is verified.
- [ ] Runtime initialization state is emitted.
- [ ] Requested skills have an execution plan.
- [ ] Actual skill execution is performed when runtime/auth are available and authorized.
- [ ] Every executed skill returns its DoR/DoD/gate state.
- [ ] Write-heavy execution is serialized or isolated to avoid conflicting edits.
- [ ] Final verification detects collisions, stale versions, missing dependencies, and failed activations.
- [ ] Rollback/uninstall path is documented for mutations.
- [ ] Bootstrap report separates INSTALLED, INTEGRATED, INITIALIZED, EXECUTED, VERIFIED, UNKNOWN.

### Hard blockers / non-negotiables

- The pack cannot be read or validated at all.
- Requested mutation has no authorization boundary.
- Target installation would overwrite an existing same-name skill without an explicit collision decision.

## Workflow

1. Run `install-skill-pack` after determining scope and collision policy.
2. Run `integrate-skill-pack` to verify host discovery, metadata, dependencies, and precedence.
3. Run `initialize-skill-runtime` to materialize a run state and tool/dependency matrix.
4. Run `execute-skill-workflow` for the requested task and mode.
5. Run `verify-skill-system` after installation/integration and after any execution that changed state.
6. Return one lifecycle ledger with stage status and evidence.

## Outputs

- skill-bootstrap-report.json
- installation receipt
- integration matrix
- runtime state
- execution ledger
- verification report

## Handoff contract

Return: scope/host, source and destination identities, stage status, evidence, exact mutations, rollback/removal path, executed verification, blockers/unknowns, and the next lifecycle stage.

## Resources

- Read `references/REFERENCE.md` for the operational protocol.
- Read `references/DOR_DOD.md` before execution.
- Read `references/SOURCES.md` when host behavior or installation paths need current verification.
- Use `evals/evals.json` for trigger/output evals.
- Use `assets/finding-template.json` for standalone structured findings.
