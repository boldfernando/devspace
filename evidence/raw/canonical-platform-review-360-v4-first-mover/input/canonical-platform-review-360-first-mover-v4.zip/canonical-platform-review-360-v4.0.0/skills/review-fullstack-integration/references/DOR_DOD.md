# Review Full-Stack Integration — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Critical workflows are selected.**
  - Evidence: At least one high-value/risk end-to-end path is bounded.
- [ ] **DOR-02 — Frontend and backend implementations are inspectable.**
  - Evidence: Request origin and server handling can both be traced.
- [ ] **DOR-03 — Network/request evidence is obtainable.**
  - Evidence: Browser trace, logs, test instrumentation, or code mapping is available.
- [ ] **DOR-04 — Data/provider dependencies are identified.**
  - Evidence: Database/cache/queue/external providers involved in the flow are known.
- [ ] **DOR-05 — Safe test data/accounts are available.**
  - Evidence: End-to-end execution can run without prohibited production mutation.
- [ ] **DOR-06 — Correlation/trace identifiers are available or absence is noted.**
  - Evidence: Cross-layer attribution is feasible or recorded as an observability gap.
- [ ] **DOR-07 — Retry/cache/state-management authorities are identifiable.**
  - Evidence: Duplicate ownership can be assessed.
- [ ] **DOR-08 — Expected consistency/idempotency semantics are known.**
  - Evidence: The intended outcome for retries/concurrency is explicit.

### DoR blockers

- No path can be traced across both producer and consumer boundaries.
- Dynamic execution would cause unauthorized external, regulated, irreversible, or production side effects.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — End-to-end data flow is traced.**
  - Evidence/acceptance: UI → state → network → API → service → data/provider → response → reconciliation is evidenced.
- [ ] **DOD-02 — Request waterfalls/duplication are identified.**
  - Evidence/acceptance: Avoidable serial/duplicate calls are quantified or located.
- [ ] **DOD-03 — Race/stale-state conditions are assessed.**
  - Evidence/acceptance: Concurrency and out-of-order responses are considered on critical actions.
- [ ] **DOD-04 — Cache ownership/invalidation is explicit.**
  - Evidence/acceptance: Client/server/provider cache layers do not silently disagree.
- [ ] **DOD-05 — Retry/idempotency responsibilities are aligned.**
  - Evidence/acceptance: Retry storms and duplicate mutations are prevented.
- [ ] **DOD-06 — Error semantics survive layer boundaries.**
  - Evidence/acceptance: Actionable/user-safe errors retain correlation and diagnostic context.
- [ ] **DOD-07 — Provider latency/failure behavior is understood.**
  - Evidence/acceptance: External dependency impact on UX and system outcome is visible.
- [ ] **DOD-08 — Data consistency expectations are verified.**
  - Evidence/acceptance: Read-after-write/eventual consistency behavior matches product expectations.
- [ ] **DOD-09 — Optimization is measured on the full path.**
  - Evidence/acceptance: Local micro-optimizations do not claim end-to-end improvement without evidence.
- [ ] **DOD-10 — Critical integration tests run.**
  - Evidence/acceptance: Happy and failure paths are exercised where feasible.
- [ ] **DOD-11 — Residual cross-layer coupling is documented.**
  - Evidence/acceptance: Risks are assigned to the correct owner/root cause.
- [ ] **DOD-12 — Integration gate state is issued.**
  - Evidence/acceptance: Any broken critical path remains a release blocker as appropriate.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
