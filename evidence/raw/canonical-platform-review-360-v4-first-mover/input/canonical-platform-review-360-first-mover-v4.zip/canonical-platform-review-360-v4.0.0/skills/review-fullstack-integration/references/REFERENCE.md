# Review Full-Stack Integration Reference Rubric

## Objective

Verify that cross-layer data flow is coherent, observable, and resilient from user action to persisted/returned state.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Cross-layer trace complete for critical paths
- Retry ownership is singular and bounded
- Cache invalidation strategy explicit
- Side effects idempotent or guarded

## Outputs expected

- DATA_FLOW_MAP.json
- INTEGRATION_FAILURES.json
- LATENCY_BREAKDOWN.json
- INTEGRATION_REMEDIATION_PLAN.md

## Gate interpretation

- Critical transaction coherent
- No unresolved duplicate side effect
- State reconciliation verified

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
