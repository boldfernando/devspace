# Reconcile Git State Reference Rubric

## Objective

Establish a reproducible Git baseline and safe rollback point before any architectural conclusion or code mutation.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- HEAD SHA recorded
- Dirty state explicit
- Ahead/behind based on current fetch or marked stale/UNKNOWN
- Rollback point exists before APPLY

## Outputs expected

- GIT_BASELINE.json
- BRANCH_GRAPH.json
- CHANGESET.json
- ROLLBACK_POINT.json

## Gate interpretation

- No ambiguous branch authority
- No hidden user changes overwritten
- Remote freshness stated

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
