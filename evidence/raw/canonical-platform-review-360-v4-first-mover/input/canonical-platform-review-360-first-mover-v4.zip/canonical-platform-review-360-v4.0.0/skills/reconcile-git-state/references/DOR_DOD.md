# Reconcile Git State — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Target path is a Git worktree or repository.**
  - Evidence: `git rev-parse` or equivalent can establish repository context.
- [ ] **DOR-02 — Read-only Git commands are authorized.**
  - Evidence: Status/log/branch/remote/worktree/submodule inspection is permitted.
- [ ] **DOR-03 — No automatic clean/reset/checkout is authorized by default.**
  - Evidence: The skill will not mutate local edits merely to make the tree look clean.
- [ ] **DOR-04 — Remote/network policy is known.**
  - Evidence: Whether fetch/remote calls are allowed is explicit; no-network results are not guessed.
- [ ] **DOR-05 — Nested repos, submodules, and worktrees are in scope or excluded.**
  - Evidence: Multiple Git state surfaces are not conflated.
- [ ] **DOR-06 — Deployment/checkpoint identifiers are supplied when comparison is required.**
  - Evidence: Deployed artifact relation can be verified or marked UNKNOWN.
- [ ] **DOR-07 — Sensitive remote URLs are handled safely.**
  - Evidence: Tokens/credentials embedded in URLs are redacted.
- [ ] **DOR-08 — Review time is recorded.**
  - Evidence: Ahead/behind and remote state are time-sensitive and tied to a timestamp.

### DoR blockers

- Repository is unreadable/corrupt to the point provenance cannot be established.
- An in-progress destructive operation makes further mutation unsafe until reconciled.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — HEAD identity is captured.**
  - Evidence/acceptance: Commit SHA, commit subject/time, and detached/non-detached state are recorded.
- [ ] **DOD-02 — Branch and upstream are captured.**
  - Evidence/acceptance: Current branch, tracking branch, and absence of upstream are explicit.
- [ ] **DOD-03 — Working tree is classified.**
  - Evidence/acceptance: Staged, unstaged, untracked, ignored/relevant generated changes are distinguished.
- [ ] **DOD-04 — Merge/rebase/cherry-pick/bisect state is checked.**
  - Evidence/acceptance: In-progress operations are surfaced as blockers/risks.
- [ ] **DOD-05 — Remotes are inventoried safely.**
  - Evidence/acceptance: Remote names/URLs are recorded with secrets redacted.
- [ ] **DOD-06 — Ahead/behind is verified or UNKNOWN.**
  - Evidence/acceptance: Result states whether a fetch occurred and avoids stale certainty.
- [ ] **DOD-07 — Worktrees/submodules are reconciled.**
  - Evidence/acceptance: Independent branch/SHA state is captured where applicable.
- [ ] **DOD-08 — Tags/checkpoints/rollback candidates are identified.**
  - Evidence/acceptance: A safe restoration reference is documented without performing reset.
- [ ] **DOD-09 — Local, tracking, remote, and deployed states are separated.**
  - Evidence/acceptance: No claim treats them as interchangeable.
- [ ] **DOD-10 — Conflict/divergence risks are stated.**
  - Evidence/acceptance: Potential lost work, force-push risk, or divergent histories are explicit.
- [ ] **DOD-11 — Git baseline artifact is emitted.**
  - Evidence/acceptance: Machine-readable baseline supports later APPLY and verification.
- [ ] **DOD-12 — No unrequested Git mutation occurred.**
  - Evidence/acceptance: No checkout/reset/clean/rebase/commit/push was performed without authority.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
