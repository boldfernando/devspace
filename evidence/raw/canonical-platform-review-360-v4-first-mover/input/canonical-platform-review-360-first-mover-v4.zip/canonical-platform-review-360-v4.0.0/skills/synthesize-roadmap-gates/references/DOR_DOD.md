# Synthesize Roadmap and Gates — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Specialist outputs are available for scoped domains.**
  - Evidence: Each scoped review returned findings/evidence or explicit UNKNOWN/NOT_APPLICABLE.
- [ ] **DOR-02 — Findings use compatible severity/status semantics.**
  - Evidence: P0-P4, PASS/PARTIAL/FAIL/UNKNOWN/N/A, and confidence can be reconciled.
- [ ] **DOR-03 — Evidence references are intact.**
  - Evidence: Material findings can be traced back without relying on narrative memory.
- [ ] **DOR-04 — Review scope and candidate version are fixed.**
  - Evidence: Roadmap/gate decision applies to a known baseline/release candidate.
- [ ] **DOR-05 — Gate model is defined.**
  - Evidence: Required release/refactor gates and blocking thresholds are explicit.
- [ ] **DOR-06 — Priority dimensions are available.**
  - Evidence: Impact, likelihood, blast radius, effort, reversibility, dependency, and confidence can be assigned.
- [ ] **DOR-07 — Mutation/verification results are separated.**
  - Evidence: Applied changes are not presumed fixed without verification.
- [ ] **DOR-08 — Decision horizon is known.**
  - Evidence: Immediate release blockers, near-term remediation, and strategic improvements can be separated.

### DoR blockers

- Specialist evidence is missing/corrupt for a release-critical domain.
- Candidate baseline changed materially after reviews without revalidation.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Findings are deduplicated.**
  - Evidence/acceptance: Multiple symptoms of the same root cause are linked/merged.
- [ ] **DOD-02 — Root causes are separated from symptoms.**
  - Evidence/acceptance: Roadmap targets the causal layer where evidence supports it.
- [ ] **DOD-03 — Dependency graph is complete enough to execute.**
  - Evidence/acceptance: Prerequisite/order/conflict relationships are explicit.
- [ ] **DOD-04 — Priority scoring is defensible.**
  - Evidence/acceptance: P0-P4 ordering cites impact, likelihood, blast radius, effort, reversibility, and confidence.
- [ ] **DOD-05 — P0/P1 disposition is explicit.**
  - Evidence/acceptance: Block/fix/mitigate/accept decisions have owner/authority and verification condition.
- [ ] **DOD-06 — Remediation tasks carry their own DoR/DoD.**
  - Evidence/acceptance: Each actionable work item states prerequisites and acceptance/verification, not just a title.
- [ ] **DOD-07 — Gate matrix is complete.**
  - Evidence/acceptance: Every required gate has status, evidence, blockers, residual risk, and next action.
- [ ] **DOD-08 — Release/refactor decision is issued against exact baseline.**
  - Evidence/acceptance: GREEN/YELLOW/RED rationale is reproducible.
- [ ] **DOD-09 — Residual risks/UNKNOWN states are visible.**
  - Evidence/acceptance: The synthesis never paints missing evidence green.
- [ ] **DOD-10 — Roadmap is segmented by horizon.**
  - Evidence/acceptance: Now/next/later or equivalent separates blockers from strategic optimization.
- [ ] **DOD-11 — Cross-domain owners/handoffs are clear.**
  - Evidence/acceptance: No remediation is orphaned between product/security/data/platform teams.
- [ ] **DOD-12 — Executive and engineering views reconcile.**
  - Evidence/acceptance: High-level decision numbers trace to underlying findings/evidence.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
