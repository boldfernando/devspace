# Synthesize Roadmap and Gates Reference Rubric

## Objective

Turn a multi-domain finding set into a dependency-aware remediation sequence and defensible release decision.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- P0/P1 cannot be hidden by score averages
- UNKNOWN remains UNKNOWN
- Every roadmap item links to finding/evidence
- Gate exception has owner/rationale/expiry if used

## Outputs expected

- RECONCILED_FINDINGS.json
- DEPENDENCY_GRAPH.json
- PRIORITIZED_ROADMAP.md
- RELEASE_GATES.json
- EXECUTIVE_SUMMARY.md

## Gate interpretation

- No unowned P0
- Release decision traceable
- Residual risks explicit

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
