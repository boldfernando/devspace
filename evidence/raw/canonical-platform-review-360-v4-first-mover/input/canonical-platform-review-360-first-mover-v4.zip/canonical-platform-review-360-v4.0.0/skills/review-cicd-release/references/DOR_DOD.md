# Review CI/CD and Release — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — CI/CD definitions are accessible.**
  - Evidence: Workflow/pipeline/build/deploy configuration and relevant scripts are inspectable.
- [ ] **DOR-02 — Source/build/release/deploy boundaries are identifiable.**
  - Evidence: Commit, artifact, image/package, release, and deployed revision are not conflated.
- [ ] **DOR-03 — Environment inventory is known.**
  - Evidence: Dev/test/preview/staging/prod promotion path is bounded.
- [ ] **DOR-04 — Artifact registry/store is identifiable.**
  - Evidence: Built outputs and provenance can be traced.
- [ ] **DOR-05 — Branch/tag/release policy is available.**
  - Evidence: Trigger and promotion semantics can be reviewed.
- [ ] **DOR-06 — Secret/credential handling is inspectable without revealing values.**
  - Evidence: CI identities/scopes can be evaluated.
- [ ] **DOR-07 — Rollback/recovery procedures are discoverable.**
  - Evidence: Release safety can be assessed.
- [ ] **DOR-08 — Pipeline execution/log access is available or gap is explicit.**
  - Evidence: Configured stages are distinguished from proven runs.

### DoR blockers

- Cannot identify the release candidate/deployed artifact.
- Requested production deployment/rollback lacks explicit authorization.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Pipeline stages and gates are mapped.**
  - Evidence/acceptance: Checkout/deps/static/test/security/build/package/deploy/smoke sequence is evidenced.
- [ ] **DOD-02 — Build reproducibility is assessed.**
  - Evidence/acceptance: Lockfiles, pinned toolchains, clean build, and deterministic inputs are reviewed.
- [ ] **DOD-03 — Artifact provenance is traceable.**
  - Evidence/acceptance: Artifact/image/package maps back to source SHA and build identity.
- [ ] **DOD-04 — SBOM/provenance posture is assessed.**
  - Evidence/acceptance: CycloneDX/SPDX/SLSA or equivalent capability is present or gap documented.
- [ ] **DOD-05 — Promotion strategy is explicit.**
  - Evidence/acceptance: Rebuild-per-env versus build-once-promote behavior and risk are documented.
- [ ] **DOD-06 — Environment contracts are assessed.**
  - Evidence/acceptance: Required config/secrets/services differ intentionally rather than by drift.
- [ ] **DOD-07 — CI/CD identities follow least privilege.**
  - Evidence/acceptance: Deployment credentials and branch protections are bounded.
- [ ] **DOD-08 — Rollback path is executable/evidenced.**
  - Evidence/acceptance: A concrete prior artifact/checkpoint and restoration procedure exist.
- [ ] **DOD-09 — Post-deploy smoke/readiness checks exist.**
  - Evidence/acceptance: Deployment success means application health, not only job completion.
- [ ] **DOD-10 — Release blockers map to objective gates.**
  - Evidence/acceptance: P0/P1/test/security/data failures cannot be silently bypassed.
- [ ] **DOD-11 — Pipeline changes are verified on real runner path when authorized.**
  - Evidence/acceptance: Local config syntax alone is not enough.
- [ ] **DOD-12 — Release gate state ties deployed artifact to evidence.**
  - Evidence/acceptance: Final decision names the exact candidate version.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
