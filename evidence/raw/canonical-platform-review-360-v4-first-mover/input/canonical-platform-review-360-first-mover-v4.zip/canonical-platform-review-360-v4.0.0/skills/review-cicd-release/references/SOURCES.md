# Primary and Authoritative Sources

Verify applicability and current version before relying on a source.

- [Agent Skills Specification](https://agentskills.io/specification)
- [Agent Skills Best Practices](https://agentskills.io/skill-creation/best-practices)
- [Agent Skills Scripts Guide](https://agentskills.io/skill-creation/using-scripts)
- [Agent Skills Description Optimization](https://agentskills.io/skill-creation/optimizing-descriptions)
- [Agent Skills Evaluation Guide](https://agentskills.io/skill-creation/evaluating-skills)
- [OpenAI Build Skills](https://developers.openai.com/codex/build-skills)
- [OpenAI Agents SDK Guide](https://developers.openai.com/api/docs/guides/agents)
- [OpenAI Agent Definitions](https://developers.openai.com/api/docs/guides/agents/define-agents)
- [OpenAI Agent Orchestration](https://developers.openai.com/api/docs/guides/agents/orchestration)
- [OpenAI Guardrails and Human Review](https://developers.openai.com/api/docs/guides/agents/guardrails-approvals)
- [OpenAI Agent Evals](https://developers.openai.com/api/docs/guides/agent-evals)
- [OpenAI Sandbox Agents](https://developers.openai.com/api/docs/guides/agents/sandboxes)
- [OpenAI Agents SDK Python](https://github.com/openai/openai-agents-python)
- [OpenAI Agents SDK TypeScript](https://github.com/openai/openai-agents-js)
- [SLSA Specification](https://slsa.dev/spec/)
- [CycloneDX Specification](https://cyclonedx.org/specification/overview/)
- [GitHub Actions documentation](https://docs.github.com/actions)
- [OpenSSF Scorecard](https://scorecard.dev/)
