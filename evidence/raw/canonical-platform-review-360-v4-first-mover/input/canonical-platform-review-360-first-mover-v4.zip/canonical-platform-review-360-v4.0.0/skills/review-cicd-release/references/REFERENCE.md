# Review CI/CD and Release Reference Rubric

## Objective

Ensure releases are traceable, reproducible, gated, observable, and reversible from source through deployed artifact.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Artifact traceable to commit
- Rollback executable or tested
- Secrets not embedded in artifacts
- Release gate has explicit failure behavior

## Outputs expected

- PIPELINE_MAP.json
- ARTIFACT_PROVENANCE.json
- ENVIRONMENT_MATRIX.json
- RELEASE_GATE.json
- CICD_REMEDIATION_PLAN.md

## Gate interpretation

- Build reproducible
- Artifact provenance adequate
- Rollback verified
- Post-deploy smoke exists

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
