# Review API Contracts — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — API/event surfaces are inventoried or bounded.**
  - Evidence: REST/RPC/GraphQL/WebSocket/SSE/webhook/event/MCP/agent interfaces in scope are known.
- [ ] **DOR-02 — Producer implementation is readable.**
  - Evidence: Routes/handlers/resolvers/event producers can be inspected.
- [ ] **DOR-03 — Consumers are identifiable.**
  - Evidence: Frontend, services, partners, SDKs, agents, or external consumers are known or UNKNOWN.
- [ ] **DOR-04 — Machine-readable contracts are available or absence is explicit.**
  - Evidence: OpenAPI/GraphQL/JSON Schema/RPC types/AsyncAPI or equivalent sources are identified.
- [ ] **DOR-05 — Authentication/authorization context is known.**
  - Evidence: Security requirements per surface can be evaluated.
- [ ] **DOR-06 — Versioning/compatibility expectations are known.**
  - Evidence: Breaking-change semantics are explicit or flagged as missing.
- [ ] **DOR-07 — Tests/fixtures can exercise critical contracts.**
  - Evidence: Validation can be executed rather than inferred.
- [ ] **DOR-08 — Environment/endpoint authority is known.**
  - Evidence: Generated docs, runtime routes, and deployment versions are not conflated.

### DoR blockers

- Critical API producer/consumer cannot be identified enough to assess compatibility.
- A requested contract change would be breaking and no migration/authorization exists.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Complete scoped API surface register exists.**
  - Evidence/acceptance: Operation/event, owner, producer, consumer, auth, and contract source are recorded.
- [ ] **DOD-02 — Implementation ↔ contract drift is assessed.**
  - Evidence/acceptance: Request/response/event shapes are compared with evidence.
- [ ] **DOD-03 — Consumer compatibility is assessed.**
  - Evidence/acceptance: Critical clients are checked against current/target contracts.
- [ ] **DOD-04 — Request/response validation is explicit.**
  - Evidence/acceptance: Schema validation exists or gap is recorded at trust boundaries.
- [ ] **DOD-05 — Status/error semantics are consistent.**
  - Evidence/acceptance: Errors, codes, retryability, and problem shapes are documented/tested.
- [ ] **DOD-06 — Pagination/filter/sort semantics are deterministic.**
  - Evidence/acceptance: Collection contracts avoid hidden or ambiguous behavior.
- [ ] **DOD-07 — Idempotency/replay rules are explicit.**
  - Evidence/acceptance: Mutations, payments, webhooks, and events handle duplicate/retry behavior where material.
- [ ] **DOD-08 — Auth requirements are part of the contract.**
  - Evidence/acceptance: Protected operations are not secured only by UI convention.
- [ ] **DOD-09 — Breaking changes are registered.**
  - Evidence/acceptance: Compatibility impact and migration/version strategy are documented.
- [ ] **DOD-10 — Critical contracts have executable tests.**
  - Evidence/acceptance: Contract/consumer/provider tests run and results are captured.
- [ ] **DOD-11 — Contract freeze or migration plan exists when needed.**
  - Evidence/acceptance: Refactors can proceed without silent drift.
- [ ] **DOD-12 — Contract gate state is issued.**
  - Evidence/acceptance: Unknown/unversioned critical interfaces prevent false PASS.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
