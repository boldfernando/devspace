# Review API Contracts Reference Rubric

## Objective

Make API behavior machine-readable, testable, and traceable while identifying contract drift and unsafe breaking changes.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Implementation ↔ contract ↔ test ↔ client alignment
- Breaking changes identified
- Request/response validation present or gap recorded
- Webhook/event idempotency addressed

## Outputs expected

- API_SURFACE.json
- CONTRACT_DRIFT.json
- BREAKING_CHANGE_REGISTER.json
- CONTRACT_FREEZE_PLAN.md

## Gate interpretation

- Critical contracts versioned
- No silent breaking change
- Validation and auth requirements explicit

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
