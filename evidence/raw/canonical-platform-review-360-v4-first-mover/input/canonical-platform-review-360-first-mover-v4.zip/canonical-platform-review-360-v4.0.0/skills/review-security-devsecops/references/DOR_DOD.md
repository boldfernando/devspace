# Review Security and DevSecOps — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Scope and authorization are explicit.**
  - Evidence: Repositories, applications, domains/IPs, environments, accounts, and test classes are authorized.
- [ ] **DOR-02 — Active versus passive/static testing boundary is explicit.**
  - Evidence: DAST/exploit-like actions are never inferred from a generic review request.
- [ ] **DOR-03 — Critical assets and trust boundaries are identifiable.**
  - Evidence: Identity, sensitive/project-classified data, secrets, privileged actions, and integrations are mapped.
- [ ] **DOR-04 — Data classification/redaction rules are known.**
  - Evidence: Evidence handling will not leak credentials/PII.
- [ ] **DOR-05 — Authentication/authorization context is available.**
  - Evidence: Critical access-control tests can be scoped safely.
- [ ] **DOR-06 — Dependency/container/IaC manifests are accessible.**
  - Evidence: Supply-chain and configuration surfaces can be scanned when present.
- [ ] **DOR-07 — Scanner/tool safety is bounded.**
  - Evidence: Rate limits, target exclusions, and non-destructive modes are configured.
- [ ] **DOR-08 — Baseline commit/environment is recorded.**
  - Evidence: Findings can be reproduced against a specific version.
- [ ] **DOR-09 — Existing security controls/policies are discoverable.**
  - Evidence: Project-specific controls override generic assumptions where stronger.
- [ ] **DOR-10 — Incident/escalation path exists for critical discovery.**
  - Evidence: P0 findings have a safe containment/reporting path.

### DoR blockers

- No explicit authorization for requested active/exploit-like testing.
- Evidence handling cannot be performed without exposing live credentials/regulated data.
- A discovered P0 requires containment before continuing broad active testing.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Threat model covers critical assets/flows.**
  - Evidence/acceptance: Trust boundaries, attacker goals, entry points, and high-impact abuse cases are documented.
- [ ] **DOD-02 — SAST is executed or explicitly unavailable.**
  - Evidence/acceptance: Results are triaged for reachability rather than copied blindly.
- [ ] **DOD-03 — SCA/dependency risk is executed or explicitly unavailable.**
  - Evidence/acceptance: Direct/transitive vulnerable dependencies are contextualized.
- [ ] **DOD-04 — Secret scanning is executed safely.**
  - Evidence/acceptance: Reports redact values and focus on live/reachable exposure.
- [ ] **DOD-05 — IaC/container/config posture is assessed when present.**
  - Evidence/acceptance: Misconfiguration and image risks are included.
- [ ] **DOD-06 — Web/API/authz controls are assessed.**
  - Evidence/acceptance: OWASP ASVS/API Security/CWE mappings support, not replace, evidence.
- [ ] **DOD-07 — DAST/active tests run only on authorized targets.**
  - Evidence/acceptance: Scope/rate/safety evidence is retained.
- [ ] **DOD-08 — False positives/duplicates are triaged.**
  - Evidence/acceptance: Scanner counts are not treated as finding counts.
- [ ] **DOD-09 — P0 findings are absent or explicitly unresolved.**
  - Evidence/acceptance: No security GREEN with an unresolved critical exploitable issue.
- [ ] **DOD-10 — P1 disposition is explicit.**
  - Evidence/acceptance: Fix, mitigation, acceptance, or release block has owner/authority.
- [ ] **DOD-11 — Fixes are rescanned/retested.**
  - Evidence/acceptance: Code change alone does not close security findings.
- [ ] **DOD-12 — Security evidence is sanitized and reproducible.**
  - Evidence/acceptance: No secret values or unnecessary sensitive payloads are retained.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
