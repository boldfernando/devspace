# Review Security and DevSecOps Reference Rubric

## Objective

Find plausible exploitable security weaknesses with evidence, prioritize by impact and reachability, and verify remediations without unsafe testing.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- No active scan without authorization
- Scanner output manually triaged
- Secrets never echoed into reports
- Critical authz/data findings have reproduction evidence

## Outputs expected

- THREAT_MODEL.md
- SECURITY_FINDINGS.json
- SCAN_SUMMARY.json
- SECURITY_GATE.json
- REMEDIATION_PLAN.md

## Gate interpretation

- No unresolved P0
- P1 disposition explicit
- Critical authz/secret/dependency risks reviewed

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
