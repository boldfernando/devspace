# Review UX Journeys — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Priority journeys and actors are named.**
  - Evidence: Entry point, actor, intent, and expected outcome are explicit.
- [ ] **DOR-02 — Journey start/end success criteria are known.**
  - Evidence: Completion can be distinguished from abandonment or partial success.
- [ ] **DOR-03 — Runnable or observable product surface is available.**
  - Evidence: Test environment, recordings, analytics, or source flow supports evidence.
- [ ] **DOR-04 — Required test data/accounts are available safely.**
  - Evidence: Role/account states can be exercised without using prohibited production data.
- [ ] **DOR-05 — Supported devices/channels are defined.**
  - Evidence: Mobile/desktop/web or other channel constraints are known.
- [ ] **DOR-06 — Known business rules and constraints are available.**
  - Evidence: UX recommendations will not contradict required compliance/process steps.
- [ ] **DOR-07 — Analytics/feedback sources are identified.**
  - Evidence: Behavioral evidence can be separated from reviewer intuition.
- [ ] **DOR-08 — Gamification is treated as hypothesis, not default.**
  - Evidence: Any engagement mechanic requires target behavior and KPI before implementation.

### DoR blockers

- No identifiable end-to-end journey or success outcome.
- Required account/data access would violate authorization or privacy boundaries.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Critical journeys are traced step-by-step.**
  - Evidence/acceptance: Entry, decision points, actions, feedback, success, failure, and return paths are mapped.
- [ ] **DOD-02 — Friction and dead ends are evidenced.**
  - Evidence/acceptance: Unclear choices, redundant steps, abandonment, loops, or missing feedback are located.
- [ ] **DOD-03 — Failure/recovery UX is reviewed.**
  - Evidence/acceptance: Network, validation, provider, auth, and partial-failure states are represented.
- [ ] **DOD-04 — Cross-device journey continuity is assessed.**
  - Evidence/acceptance: Priority tasks do not break solely due to viewport/input modality.
- [ ] **DOD-05 — Conversion/activation moments are explicit.**
  - Evidence/acceptance: Measures exist for whether UX improvements change intended behavior.
- [ ] **DOD-06 — Cognitive load and information timing are evaluated.**
  - Evidence/acceptance: Required information appears at the right decision point.
- [ ] **DOD-07 — Trust/safety cues are assessed where material.**
  - Evidence/acceptance: Sensitive, privileged, irreversible, or regulated actions communicate consequence and status.
- [ ] **DOD-08 — Gamification proposals have measurable hypotheses.**
  - Evidence/acceptance: No points/badges/loops are added without intended behavior, guardrail, and KPI.
- [ ] **DOD-09 — TO-BE journey has acceptance criteria.**
  - Evidence/acceptance: Each major improvement can be tested end-to-end.
- [ ] **DOD-10 — Applied changes are regression-tested on the full journey.**
  - Evidence/acceptance: Local screen improvements do not break downstream steps.
- [ ] **DOD-11 — Residual UX debt is prioritized.**
  - Evidence/acceptance: High-impact friction is separated from polish.
- [ ] **DOD-12 — Journey evidence can feed product/testing skills.**
  - Evidence/acceptance: Artifacts are reusable downstream.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
