# Review UX Journeys Reference Rubric

## Objective

Reconstruct and test critical journeys end to end, identifying friction and state failures that materially affect task completion or trust.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Happy path and failure path tested
- Role-specific journeys separated
- Observed friction distinguished from inferred friction
- Metrics defined for proposed UX changes

## Outputs expected

- JOURNEY_MAPS.md
- FRICTION_REGISTER.json
- UX_HYPOTHESES.json
- UX_PRIORITY_PLAN.md

## Gate interpretation

- Critical journeys complete
- No critical dead end
- Error recovery usable
- Measurement plan exists

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
