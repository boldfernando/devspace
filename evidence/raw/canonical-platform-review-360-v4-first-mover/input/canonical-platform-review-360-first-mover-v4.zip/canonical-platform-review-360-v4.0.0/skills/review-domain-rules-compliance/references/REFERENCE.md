# Review Domain Rules and Compliance — Reference Rubric

## Objective

Verify that domain-specific business rules, policies, contractual obligations, standards, and jurisdictional constraints are explicit, source-traceable, version-aware, and testable.

## Evidence hierarchy

Prefer, in order:

1. Executed behavior and reproducible tests.
2. Current runtime/configuration/schema state.
3. Versioned contracts, rules, policies, or standards adopted by the project.
4. Current authoritative external sources applicable to the exact jurisdiction/context.
5. Project documentation and decision records.
6. Secondary explanatory material, used only as supporting context.

Re-verify any time-sensitive external claim before treating it as current.

## Required review dimensions

- Rule identity, source/owner, and rationale
- Authority class and precedence
- Applicability: jurisdiction, tenant, product, market, segment, plan, role, or contract
- Effective/version boundaries
- Rule-to-code/config/schema/test traceability
- Calculations, units, thresholds, rounding, defaults, and exceptions
- Dataset provenance and refresh semantics
- Ambiguity/conflict handling and escalation
- Rule change detection and release path

## Outputs expected

- `DOMAIN_RULE_REGISTER.json`
- `RULE_IMPLEMENTATION_MAP.json`
- `DATA_SOURCE_PROVENANCE.json`
- `DOMAIN_COMPLIANCE_FINDINGS.json`

## Gate interpretation

A PASS requires material scoped rules to be traceable, applicability-bounded, implementation-mapped, and verified where executable. Unresolved authority or applicability remains `UNKNOWN`/`PARTIAL`, not an invented compliance claim.

## Severity guidance

- **P0**: active exploit/data loss/system-integrity, unlawful/forbidden behavior with immediate catastrophic impact, or catastrophic release blocker.
- **P1**: critical business/compliance/release blocker with high materiality.
- **P2**: material reliability, data, UX, compliance, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; preserve as UNKNOWN/needs verification when material.
