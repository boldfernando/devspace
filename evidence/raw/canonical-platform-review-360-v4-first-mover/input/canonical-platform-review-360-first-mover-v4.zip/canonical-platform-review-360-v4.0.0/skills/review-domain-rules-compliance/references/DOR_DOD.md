# Review Domain Rules and Compliance — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Capability/process scope is explicit.**
  - Evidence: Feature, workflow, API, calculation, policy engine, or business process boundaries are recorded.
- [ ] **DOR-02 — Rule categories in scope are explicit.**
  - Evidence: External regulation, standard, contract, partner policy, internal policy, business rule, eligibility, calculation, or data constraint categories are identified.
- [ ] **DOR-03 — Applicability context is identifiable.**
  - Evidence: Relevant jurisdiction, tenant, product, market, segment, role, contract, or version context is known or explicitly UNKNOWN.
- [ ] **DOR-04 — Source hierarchy is defined.**
  - Evidence: The team knows which source wins when law/regulation, standard, contract, external policy, internal policy, and code disagree.
- [ ] **DOR-05 — Rule implementation/configuration is inspectable.**
  - Evidence: Code, config, schema, policy files, tables, or calculations can be traced.
- [ ] **DOR-06 — Required inputs and provenance are identifiable.**
  - Evidence: Material datasets, constants, rates, thresholds, catalogs, or external inputs have source/owner metadata or are marked UNKNOWN.
- [ ] **DOR-07 — Effective/version semantics can be represented.**
  - Evidence: Effective-from/to, version, retrieved-at, tenant/product scope, or equivalent boundaries can be recorded.
- [ ] **DOR-08 — Interpretation boundary is explicit.**
  - Evidence: Engineering verification is separated from legal, regulatory, standards-certification, or contractual advice requiring an external authority.
- [ ] **DOR-09 — Sensitive-data implications are in scope where relevant.**
  - Evidence: Privacy, confidentiality, residency, retention, access, or regulated-data concerns can be assessed when triggered by the scoped rule.
- [ ] **DOR-10 — Organization-specific policy is separated from external authority.**
  - Evidence: Internal product/company choices will not be mislabeled as law, regulation, or industry mandate.

### DoR blockers

- A material rule has no identifiable source/owner and cannot be safely treated as a provisional implementation assumption.
- Applicability cannot be bounded enough to prevent cross-jurisdiction, cross-tenant, cross-product, or cross-contract misapplication.
- Requested implementation depends on unresolved interpretation whose authority sits outside engineering.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Material rule register is complete for the scoped capability.**
  - Evidence/acceptance: Each rule has ID, category, source/owner, applicability, version/effective context, implementation pointer, and status.
- [ ] **DOD-02 — Rule-to-implementation mapping exists.**
  - Evidence/acceptance: Material rules map to code/config/schema/data/tests or are explicitly documented as not implemented.
- [ ] **DOD-03 — Applicability and precedence are explicit.**
  - Evidence/acceptance: Conflicting contexts/sources have deterministic precedence or an escalation path.
- [ ] **DOD-04 — Calculations/eligibility/policy logic has provenance.**
  - Evidence/acceptance: Inputs, units, thresholds, rounding, defaults, formulas, boundaries, exceptions, and outputs are traceable where relevant.
- [ ] **DOD-05 — Effective dates and version transitions are represented.**
  - Evidence/acceptance: Time/version-sensitive behavior cannot silently apply superseded rules.
- [ ] **DOD-06 — External dataset provenance/quality is assessed.**
  - Evidence/acceptance: Source, owner, timestamp/version, scope, units/schema, refresh cadence, and fallback behavior are known where material.
- [ ] **DOD-07 — Sensitive-data/compliance implications are reviewed where applicable.**
  - Evidence/acceptance: Applicable privacy, confidentiality, residency, retention, access, audit, or regulated-data concerns are surfaced without overclaiming legal certainty.
- [ ] **DOD-08 — Conflicting/ambiguous sources are documented.**
  - Evidence/acceptance: No certainty is invented where authority, standard, contract, or policy sources disagree or are incomplete.
- [ ] **DOD-09 — Material rule boundaries and edge cases are verified.**
  - Evidence/acceptance: Boundary values, transitions, exceptions, negative cases, and precedence paths have executed tests where implementation exists.
- [ ] **DOD-10 — Rule changes have a change-management path.**
  - Evidence/acceptance: Source/policy updates can trigger review, tests, migration/config update, approval, and release rather than silent drift.
- [ ] **DOD-11 — Residual interpretation unknowns are escalated.**
  - Evidence/acceptance: Each material UNKNOWN names the next authority, owner, or evidence required.
- [ ] **DOD-12 — Gate state is scoped, not universalized.**
  - Evidence/acceptance: PASS/PARTIAL/FAIL/UNKNOWN is issued for the actual capability/context/version reviewed, never as an unbounded “compliant” label.

## Evidence and handoff requirements

- Record repository commit, runtime/environment, artifact/config/rule version, authority/source snapshot, and applicability context used as baseline.
- Link every failed or unknown criterion to a finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
