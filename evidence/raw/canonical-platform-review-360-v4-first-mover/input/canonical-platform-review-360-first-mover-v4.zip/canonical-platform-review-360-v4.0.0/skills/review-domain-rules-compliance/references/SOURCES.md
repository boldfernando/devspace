# Canonical Source Hierarchy and Verification Protocol

Do not hard-code one country, regulator, industry, or vendor into the default skill. Determine applicability at runtime and use the most authoritative current source for that exact context.

## Source hierarchy

1. **Applicable law/regulation or competent authority publication**, when the rule is jurisdictional.
2. **Normative standard/specification adopted by the product or contract**, using the exact version in force for the scoped system.
3. **Signed contract, customer/partner agreement, or externally binding policy**, when contractual behavior is in scope.
4. **Official provider/vendor documentation**, for external platform/API behavior.
5. **Approved internal policy, ADR, product specification, or rule catalog**, for organization-owned rules.
6. **Implemented code/config/schema/tests**, as evidence of AS-IS behavior, not as proof that the behavior is normatively correct.
7. **Secondary sources**, only for orientation or corroboration, never to overrule an applicable primary source.

## Runtime verification rules

- Record source URI/document identifier, issuing authority/owner, version/effective date, retrieval date, and applicability scope.
- Re-check time-sensitive sources before changing behavior or issuing a current-state compliance conclusion.
- Separate facts from interpretation.
- If authoritative sources conflict, preserve the conflict and escalate. Do not choose the more convenient source silently.
- Never treat a generic best-practice guide as a substitute for an applicable law, standard, contract, or policy.

## Agent/Skill protocol references

- [Agent Skills Specification](https://agentskills.io/specification)
- [Agent Skills Best Practices](https://agentskills.io/skill-creation/best-practices)
- [OpenAI Build Skills](https://developers.openai.com/codex/build-skills)
- [OpenAI Agents SDK Guide](https://developers.openai.com/api/docs/guides/agents)
- [OpenAI Agent Orchestration](https://developers.openai.com/api/docs/guides/agents/orchestration)
- [OpenAI Guardrails and Human Review](https://developers.openai.com/api/docs/guides/agents/guardrails-approvals)
- [OpenAI Agent Evals](https://developers.openai.com/api/docs/guides/agent-evals)
