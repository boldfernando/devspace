# Review Data and Database Reference Rubric

## Objective

Establish schema provenance, integrity, and query health before data-layer refactoring or release.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Declared schema = migration history = runtime schema or drift is explicit
- No production mutation for read-only review
- Indexes justified by query plans/workload
- Integrity constraints match domain invariants

## Outputs expected

- SCHEMA_MAP.json
- MIGRATION_PROVENANCE.json
- INTEGRITY_FINDINGS.json
- QUERY_PLAN_FINDINGS.json
- DATA_REMEDIATION_PLAN.md

## Gate interpretation

- Schema provenance PASS/PARTIAL/FAIL
- Critical integrity rules enforced
- Migration path reproducible

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
