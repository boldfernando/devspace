# Review Data and Database — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Declared schema/ORM definitions are accessible.**
  - Evidence: Tables/models/relations can be inspected.
- [ ] **DOR-02 — Migration history is accessible.**
  - Evidence: Migration files/journal/tool metadata are available or explicitly missing.
- [ ] **DOR-03 — Runtime database access is read-only when used.**
  - Evidence: Credentials/connection allow safe introspection without mutation.
- [ ] **DOR-04 — Target database/environment is explicit.**
  - Evidence: Local/dev/test/staging/prod is not ambiguous.
- [ ] **DOR-05 — Sensitive data classes are known.**
  - Evidence: Sensitive, personal, regulated, or project-classified data handling and redaction constraints are defined.
- [ ] **DOR-06 — Representative query/workload evidence exists when optimizing.**
  - Evidence: Slow queries, traces, logs, or known hot paths prevent speculative indexing.
- [ ] **DOR-07 — Backup/restore and migration safety constraints are known.**
  - Evidence: Schema recommendations consider rollback and data loss risk.
- [ ] **DOR-08 — Data ownership/tenancy model is identifiable.**
  - Evidence: Critical isolation and lifecycle rules can be assessed.

### DoR blockers

- Requested production mutation lacks explicit authorization/backup/rollback.
- Schema provenance is too incomplete to safely propose destructive migration as APPLY.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Declared schema is inventoried.**
  - Evidence/acceptance: Entities/tables, keys, relations, constraints, and relevant generated schema are recorded.
- [ ] **DOD-02 — Migration provenance is reconciled.**
  - Evidence/acceptance: Migration files, journals, applied state, and anomalies are documented.
- [ ] **DOD-03 — Runtime schema is compared when authorized.**
  - Evidence/acceptance: Declared ↔ migration ↔ runtime drift is proven or marked UNKNOWN.
- [ ] **DOD-04 — Referential/integrity constraints are assessed.**
  - Evidence/acceptance: Critical invariants are DB-enforced, application-enforced, or explicitly unprotected.
- [ ] **DOD-05 — Indexes/query plans are evidence-based.**
  - Evidence/acceptance: EXPLAIN/slow-query evidence supports optimization recommendations where possible.
- [ ] **DOD-06 — N+1/connection/pooling risks are assessed.**
  - Evidence/acceptance: Application access patterns and database limits are considered.
- [ ] **DOD-07 — Data lineage/ownership is mapped for critical fields.**
  - Evidence/acceptance: Sources, transformations, consumers, and system of record are explicit.
- [ ] **DOD-08 — Retention/deletion/privacy behavior is reviewed.**
  - Evidence/acceptance: Lifecycle rules are aligned with policy/regulatory requirements.
- [ ] **DOD-09 — Seed/test data behavior is safe.**
  - Evidence/acceptance: Fixtures do not contaminate production or expose sensitive values.
- [ ] **DOD-10 — Migration changes include forward/backward safety.**
  - Evidence/acceptance: Applied schema changes have backup/rollback/verification appropriate to risk.
- [ ] **DOD-11 — Schema provenance gate is explicit.**
  - Evidence/acceptance: Any unproven production schema history remains FAIL/UNKNOWN rather than GREEN.
- [ ] **DOD-12 — Data findings include exact object/query evidence.**
  - Evidence/acceptance: Recommendations are actionable and traceable.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
