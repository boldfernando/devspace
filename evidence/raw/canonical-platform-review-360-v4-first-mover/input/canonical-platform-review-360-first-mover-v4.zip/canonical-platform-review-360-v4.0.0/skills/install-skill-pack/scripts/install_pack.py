#!/usr/bin/env python3
from pathlib import Path
import argparse, json, os, shutil, datetime

def valid_skill(path: Path):
    p=path/'SKILL.md'
    if not p.is_file(): return False, 'missing SKILL.md'
    t=p.read_text(encoding='utf-8', errors='replace')
    if not t.startswith('---\n') or '\nname:' not in t[:2000]: return False, 'invalid frontmatter/name'
    return True, None

def main():
    ap=argparse.ArgumentParser(description='Transaction-safe Agent Skill installer with staging, backup, receipt, and rollback.')
    ap.add_argument('--source', default=str(Path(__file__).resolve().parents[3] / 'skills'))
    ap.add_argument('--scope', choices=['repo','user','admin','custom'], default='repo')
    ap.add_argument('--repo', default='.')
    ap.add_argument('--dest')
    ap.add_argument('--mode', choices=['copy','symlink'], default='copy')
    ap.add_argument('--collision', choices=['fail','skip','replace'], default='fail')
    ap.add_argument('--skills', nargs='*')
    ap.add_argument('--apply', action='store_true')
    ap.add_argument('--receipt')
    args=ap.parse_args()
    source=Path(args.source).expanduser().resolve()
    if args.scope=='repo': dest=Path(args.repo).expanduser().resolve()/'.agents'/'skills'
    elif args.scope=='user': dest=Path.home()/'.agents'/'skills'
    elif args.scope=='admin': dest=Path('/etc/codex/skills')
    else:
        if not args.dest: ap.error('--dest is required for custom scope')
        dest=Path(args.dest).expanduser().resolve()
    names=set(args.skills or [])
    selected=[]; invalid=[]
    for d in sorted(source.iterdir() if source.exists() else []):
        if d.is_dir() and (not names or d.name in names):
            ok, why=valid_skill(d)
            if ok: selected.append(d)
            elif d.name in names: invalid.append({'skill':d.name,'reason':why})
    missing=sorted(names-{d.name for d in selected}-{x['skill'] for x in invalid})
    ops=[]
    for src in selected:
        target=dest/src.name
        exists=target.exists() or target.is_symlink()
        action='install' if not exists else {'fail':'blocked_collision','skip':'skipped_collision','replace':'replace'}[args.collision]
        ops.append({'skill':src.name,'source':str(src),'destination':str(target),'exists':exists,'action':action})
    blocked=bool(missing or invalid) or any(x['action']=='blocked_collision' for x in ops)
    receipt={'status':'BLOCKED' if blocked else ('DRY_RUN' if not args.apply else 'PENDING'), 'scope':args.scope,'mode':args.mode,'collision':args.collision,'source':str(source),'destination':str(dest),'missing_requested_skills':missing,'invalid_skills':invalid,'operations':ops,'backups':[],'rollback_performed':False}
    code=2 if blocked else 0
    if args.apply and not blocked:
        dest.mkdir(parents=True, exist_ok=True)
        txid=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
        stage_root=dest.parent/'.canonical-skill-staging'/txid
        backup_root=dest.parent/'.canonical-skill-backups'/txid
        stage_root.mkdir(parents=True, exist_ok=True)
        completed=[]
        try:
            for op in ops:
                if op['action']=='skipped_collision': continue
                src=Path(op['source']); target=Path(op['destination']); staged=stage_root/src.name
                if args.mode=='symlink': staged.symlink_to(src, target_is_directory=True)
                else: shutil.copytree(src, staged)
                ok, why=valid_skill(staged.resolve() if staged.is_symlink() else staged)
                if not ok: raise RuntimeError(f'staged skill {src.name} invalid: {why}')
                backup=None
                if target.exists() or target.is_symlink():
                    backup=backup_root/src.name; backup.parent.mkdir(parents=True, exist_ok=True)
                    os.replace(target, backup)
                    receipt['backups'].append({'skill':src.name,'path':str(backup)})
                os.replace(staged, target)
                completed.append((target, backup))
            receipt['status']='APPLIED'; code=0
        except Exception as e:
            receipt['status']='ROLLED_BACK'; receipt['error']=str(e); receipt['rollback_performed']=True; code=3
            for target, backup in reversed(completed):
                try:
                    if target.exists() or target.is_symlink():
                        if target.is_symlink() or target.is_file(): target.unlink()
                        else: shutil.rmtree(target)
                    if backup and backup.exists(): os.replace(backup, target)
                except Exception as re:
                    receipt.setdefault('rollback_errors',[]).append(str(re))
        finally:
            if stage_root.exists(): shutil.rmtree(stage_root, ignore_errors=True)
    text=json.dumps(receipt,indent=2)
    print(text)
    if args.receipt: Path(args.receipt).write_text(text+'\n',encoding='utf-8')
    raise SystemExit(code)
if __name__=='__main__': main()
