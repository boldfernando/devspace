# Install Skill Pack — DoR / DoD

Use this as an execution gate. Each criterion must be evidence-backed, `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Source `skills/` directory is readable.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-02 — Every selected skill has `SKILL.md`.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-03 — Pack or selected skills pass structural validation.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-04 — Target scope/destination resolves deterministically.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-05 — Target parent directory is writable for APPLY.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-06 — Collision inventory has been produced.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-07 — Replacement is explicitly authorized when requested.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-08 — Symlink support is confirmed when symlink mode is selected.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-09 — Source and destination are not the same physical directory.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-10 — A receipt/output location is available.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.

### DoR blockers

- Destination cannot be written in APPLY mode.
- A same-name destination exists and collision action is undefined.
- Source validation fails for a selected skill.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Selected skills are installed at the intended scope.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-02 — Destination contains exact skill directory names.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-03 — Each installed `SKILL.md` remains readable and valid.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-04 — Copy/symlink mode matches the requested install strategy.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-05 — No undeclared same-name skill was overwritten.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-06 — Collision outcomes are recorded per skill.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-07 — Source version and destination paths are recorded.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-08 — Installed file counts or hashes are captured where practical.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-09 — Rollback/removal instructions are emitted.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-10 — Host restart/reload requirement is stated only when applicable.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-11 — Dry-run produces an exact proposed operation set without writes.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-12 — Installation receipt has terminal status for every selected skill.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.

## Handoff evidence

- Record source pack/version, target scope/path, host/client, run ID, mode, and authorization boundary.
- Link every FAIL/UNKNOWN criterion to a corrective next action.
- For APPLY, record exact changed paths, rollback/removal method, and post-change verification.
- Do not mark an unexecuted activation or eval as PASS.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available.
