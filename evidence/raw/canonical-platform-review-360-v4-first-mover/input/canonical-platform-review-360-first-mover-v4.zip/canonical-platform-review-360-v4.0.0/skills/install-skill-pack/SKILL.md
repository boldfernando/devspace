---
name: install-skill-pack
description: "Use this skill when one or more Agent Skills must be installed or updated into a repository, user, admin, sandbox, or explicit custom skill-discovery location. Inspect collisions first, default to dry-run when authorization is ambiguous, and never overwrite an existing same-name skill without an explicit replacement decision."
metadata:
  version: "3.0.0"
  order: "OP01"
  family: skill-system-lifecycle
---

# Install Skill Pack

## Objective

Install a validated set of skill directories into an explicit discovery scope with deterministic collision handling and an auditable receipt.

## Use this skill when

- A local or unpacked skill pack must be installed for Codex/ChatGPT desktop or another Agent Skills-compatible client.
- Skills need to be copied or symlinked into `.agents/skills` or another explicit host path.
- An existing installation needs a controlled version update.

## Do not use this skill when

- The skills are already installed and only need discovery/integration verification.
- The request is to distribute a multi-skill package publicly; use the host distribution/plugin workflow instead of treating local copy as distribution.

## Required inputs

- Source skill-pack root containing `skills/`
- Scope: repo, user, admin, or custom
- Target repository or explicit destination when required
- Install mode: copy or symlink
- Collision action: fail, skip, or replace
- Authorization for writes/replacement

If an input is unavailable, continue only when execution remains safe and mark the affected state `UNKNOWN`; never fabricate a path, host capability, credential, or authorization.

## Operating rules

- Detect before mutate.
- Default to least privilege and dry-run/READ_ONLY when authorization is ambiguous.
- Preserve project-level trust boundaries; repository skills can contain instructions and must not be silently trusted in a custom client.
- Never expose secret values in logs, receipts, state files, or prompts.
- Do not silently overwrite same-name skills.
- Installation is not integration; integration is not initialization; initialization is not execution; execution is not verification.
- Every mutating stage needs rollback/removal instructions.
- Every executed child skill retains its own DoR/DoD and evidence contract.

## Definition of Ready (DoR)

Evaluate this gate before expensive, active, or mutating work. Use `READY | CONDITIONAL | NOT_READY`.
- [ ] Source `skills/` directory is readable.
- [ ] Every selected skill has `SKILL.md`.
- [ ] Pack or selected skills pass structural validation.
- [ ] Target scope/destination resolves deterministically.
- [ ] Target parent directory is writable for APPLY.
- [ ] Collision inventory has been produced.
- [ ] Replacement is explicitly authorized when requested.
- [ ] Symlink support is confirmed when symlink mode is selected.
- [ ] Source and destination are not the same physical directory.
- [ ] A receipt/output location is available.

Detailed evidence expectations: `references/DOR_DOD.md`.

## Definition of Done (DoD)

Use `DONE | PARTIAL | NOT_DONE`; file presence or command invocation alone is not completion.
- [ ] Selected skills are installed at the intended scope.
- [ ] Destination contains exact skill directory names.
- [ ] Each installed `SKILL.md` remains readable and valid.
- [ ] Copy/symlink mode matches the requested install strategy.
- [ ] No undeclared same-name skill was overwritten.
- [ ] Collision outcomes are recorded per skill.
- [ ] Source version and destination paths are recorded.
- [ ] Installed file counts or hashes are captured where practical.
- [ ] Rollback/removal instructions are emitted.
- [ ] Host restart/reload requirement is stated only when applicable.
- [ ] Dry-run produces an exact proposed operation set without writes.
- [ ] Installation receipt has terminal status for every selected skill.

### Hard blockers / non-negotiables

- Destination cannot be written in APPLY mode.
- A same-name destination exists and collision action is undefined.
- Source validation fails for a selected skill.

## Workflow

1. Inspect the source pack and validate selected skills.
2. Resolve destination from scope; for Codex-compatible local discovery prefer repo `.agents/skills` or user `$HOME/.agents/skills`.
3. Inventory name collisions before any write.
4. Run `scripts/install_pack.py` without `--apply` first when authorization is ambiguous.
5. With explicit authorization, re-run with `--apply` and the chosen collision policy.
6. Verify destination structure and emit the installation receipt.

## Available scripts

- `scripts/install_pack.py` — deterministic helper for this lifecycle stage. Inspect/dry-run before mutating use.

## Outputs

- skill-install-receipt.json
- installed skill paths
- collision ledger
- rollback/removal instructions

## Handoff contract

Return: scope/host, source and destination identities, stage status, evidence, exact mutations, rollback/removal path, executed verification, blockers/unknowns, and the next lifecycle stage.

## Resources

- Read `references/REFERENCE.md` for the operational protocol.
- Read `references/DOR_DOD.md` before execution.
- Read `references/SOURCES.md` when host behavior or installation paths need current verification.
- Use `evals/evals.json` for trigger/output evals.
- Use `assets/finding-template.json` for standalone structured findings.
