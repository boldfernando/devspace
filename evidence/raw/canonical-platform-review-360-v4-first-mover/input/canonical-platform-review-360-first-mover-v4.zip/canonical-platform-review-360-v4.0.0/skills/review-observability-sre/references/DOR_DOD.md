# Review Observability and SRE — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Service/runtime inventory is available.**
  - Evidence: Critical components and dependencies to observe are known.
- [ ] **DOR-02 — Telemetry backends/config are accessible.**
  - Evidence: Logs, metrics, traces, events, or collector configuration can be inspected.
- [ ] **DOR-03 — Critical user/system journeys are identified.**
  - Evidence: Observability is tested against meaningful outcomes.
- [ ] **DOR-04 — Privacy/redaction requirements are known.**
  - Evidence: PII/secrets are not introduced into telemetry.
- [ ] **DOR-05 — Health/readiness semantics are defined or reviewable.**
  - Evidence: Operator-visible service state can be assessed.
- [ ] **DOR-06 — SLO/SLA expectations are known or absence is explicit.**
  - Evidence: Alerting can be tied to reliability targets.
- [ ] **DOR-07 — Trace/correlation propagation can be exercised.**
  - Evidence: Cross-service request identity can be evaluated.
- [ ] **DOR-08 — Incident/on-call context is available where relevant.**
  - Evidence: Alerts/runbooks can be judged for actionability.

### DoR blockers

- No access to telemetry or runtime evidence for claims about operational visibility.
- Requested instrumentation would expose prohibited sensitive data.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Telemetry signal inventory exists.**
  - Evidence/acceptance: Logs, metrics, traces, events, errors, and business telemetry are mapped by component.
- [ ] **DOD-02 — Correlation works across critical boundaries.**
  - Evidence/acceptance: Request/trace/correlation identifiers allow end-to-end debugging or gap is explicit.
- [ ] **DOD-03 — Golden signals are measurable.**
  - Evidence/acceptance: Latency, traffic, errors, saturation exist for critical services where appropriate.
- [ ] **DOD-04 — Health/readiness endpoints are meaningful.**
  - Evidence/acceptance: They reflect dependency/readiness state without leaking sensitive detail.
- [ ] **DOD-05 — Alert quality is assessed.**
  - Evidence/acceptance: Alerts are actionable, deduplicated, severity-ranked, and tied to owner/runbook.
- [ ] **DOD-06 — SLO/error-budget posture is defined or gap recorded.**
  - Evidence/acceptance: Reliability goals can guide release and incident decisions.
- [ ] **DOD-07 — Critical business outcomes are observable.**
  - Evidence/acceptance: Conversion/simulation/checkout/provider failure or equivalent domain events can be measured.
- [ ] **DOD-08 — Telemetry privacy/cost is controlled.**
  - Evidence/acceptance: Sensitive data and high-cardinality/cost explosions are addressed.
- [ ] **DOD-09 — One critical incident path is traceable.**
  - Evidence/acceptance: Evidence shows an operator can move from symptom to root-cause signals.
- [ ] **DOD-10 — Applied instrumentation changes are verified.**
  - Evidence/acceptance: Signals appear correctly in the target backend when execution is authorized.
- [ ] **DOD-11 — Operational blind spots are prioritized.**
  - Evidence/acceptance: Missing critical telemetry outranks logging volume improvements.
- [ ] **DOD-12 — SRE gate state is issued.**
  - Evidence/acceptance: Unknown incident visibility is not mislabeled GREEN.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
