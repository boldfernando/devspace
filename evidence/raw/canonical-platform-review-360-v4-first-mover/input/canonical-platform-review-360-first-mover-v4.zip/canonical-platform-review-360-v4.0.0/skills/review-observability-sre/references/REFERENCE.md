# Review Observability and SRE Reference Rubric

## Objective

Make critical user/business transactions diagnosable and operational health measurable with coherent telemetry and actionable alerts.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Critical path traceable
- Health != shallow process alive only
- Alerts tied to action/runbook
- Sensitive data handling reviewed

## Outputs expected

- OBSERVABILITY_MAP.json
- SIGNAL_GAPS.json
- SLO_SLI_MATRIX.json
- ALERT_REVIEW.json
- OBSERVABILITY_PLAN.md

## Gate interpretation

- Critical services observable
- Release health signals available
- High-severity alerts actionable

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
