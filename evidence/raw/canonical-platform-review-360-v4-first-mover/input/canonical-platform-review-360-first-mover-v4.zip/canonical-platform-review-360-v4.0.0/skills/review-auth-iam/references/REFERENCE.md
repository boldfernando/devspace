# Review Authentication and IAM Reference Rubric

## Objective

Verify that every sensitive resource action is authorized under explicit identity and tenancy rules.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- UI hiding is never counted as authorization
- Cross-tenant/resource access tests exist
- Privileged actions have explicit checks
- Session/token assumptions documented

## Outputs expected

- IAM_MATRIX.json
- AUTHZ_COVERAGE.json
- SESSION_FINDINGS.json
- IAM_REMEDIATION_PLAN.md

## Gate interpretation

- No unresolved critical authorization bypass
- Tenant isolation verified
- Privileged action coverage adequate

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
