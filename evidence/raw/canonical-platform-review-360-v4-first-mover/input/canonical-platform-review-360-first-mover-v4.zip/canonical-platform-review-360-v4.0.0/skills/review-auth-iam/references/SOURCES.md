# Primary and Authoritative Sources

Verify applicability and current version before relying on a source.

- [Agent Skills Specification](https://agentskills.io/specification)
- [Agent Skills Best Practices](https://agentskills.io/skill-creation/best-practices)
- [Agent Skills Scripts Guide](https://agentskills.io/skill-creation/using-scripts)
- [Agent Skills Description Optimization](https://agentskills.io/skill-creation/optimizing-descriptions)
- [Agent Skills Evaluation Guide](https://agentskills.io/skill-creation/evaluating-skills)
- [OpenAI Build Skills](https://developers.openai.com/codex/build-skills)
- [OpenAI Agents SDK Guide](https://developers.openai.com/api/docs/guides/agents)
- [OpenAI Agent Definitions](https://developers.openai.com/api/docs/guides/agents/define-agents)
- [OpenAI Agent Orchestration](https://developers.openai.com/api/docs/guides/agents/orchestration)
- [OpenAI Guardrails and Human Review](https://developers.openai.com/api/docs/guides/agents/guardrails-approvals)
- [OpenAI Agent Evals](https://developers.openai.com/api/docs/guides/agent-evals)
- [OpenAI Sandbox Agents](https://developers.openai.com/api/docs/guides/agents/sandboxes)
- [OpenAI Agents SDK Python](https://github.com/openai/openai-agents-python)
- [OpenAI Agents SDK TypeScript](https://github.com/openai/openai-agents-js)
- [OWASP ASVS](https://owasp.org/www-project-application-security-verification-standard/)
- [OWASP API Security Top 10](https://owasp.org/API-Security/)
- [OAuth 2.0 Security BCP RFC 9700](https://www.rfc-editor.org/rfc/rfc9700)
- [OpenID Connect Core](https://openid.net/specs/openid-connect-core-1_0.html)
