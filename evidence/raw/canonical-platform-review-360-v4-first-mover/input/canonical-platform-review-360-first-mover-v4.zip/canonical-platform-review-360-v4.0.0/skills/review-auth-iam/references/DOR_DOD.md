# Review Authentication and IAM — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Identity providers/auth mechanisms are identified.**
  - Evidence: Session/JWT/OAuth/OIDC/API key/service identity paths are known.
- [ ] **DOR-02 — Actors/roles are enumerated.**
  - Evidence: Human, admin, service, agent, tenant roles and anonymous users are bounded.
- [ ] **DOR-03 — Critical resources/actions are enumerated.**
  - Evidence: CRUD, approve/reject/export/share/admin and domain actions are in scope.
- [ ] **DOR-04 — Ownership/membership/tenant model is known.**
  - Evidence: Resource relationships needed for authz can be evaluated.
- [ ] **DOR-05 — Server-side enforcement points are inspectable.**
  - Evidence: Middleware/procedures/policies/DB filters can be traced.
- [ ] **DOR-06 — Safe test identities/data are available when dynamic tests are authorized.**
  - Evidence: Authorization testing does not use uncontrolled production accounts.
- [ ] **DOR-07 — Session/token configuration is accessible.**
  - Evidence: Expiry, refresh, revocation, cookie/security settings can be reviewed.
- [ ] **DOR-08 — Privileged flows are identified.**
  - Evidence: Privileged, impersonation, approval, export, regulated, and destructive actions are prioritized.

### DoR blockers

- Critical resource authorization cannot be evaluated because actors/resources are unidentified.
- Dynamic authorization testing would require unauthorized access to real user data/accounts.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Actor × Resource × Action × Context matrix exists.**
  - Evidence/acceptance: Expected authorization decision is explicit for critical combinations.
- [ ] **DOD-02 — Authentication controls are assessed.**
  - Evidence/acceptance: Login/session/token lifecycle and credential handling are evidenced.
- [ ] **DOD-03 — Server-side authorization is verified.**
  - Evidence/acceptance: UI hiding alone is never accepted as enforcement.
- [ ] **DOD-04 — Ownership/membership checks are verified.**
  - Evidence/acceptance: ID-based object access cannot bypass relationship constraints.
- [ ] **DOD-05 — Tenant isolation is tested or statically proven.**
  - Evidence/acceptance: Cross-tenant reads/writes/admin paths are covered.
- [ ] **DOD-06 — Privilege escalation paths are reviewed.**
  - Evidence/acceptance: Role changes, admin endpoints, support flows, and indirect object actions are checked.
- [ ] **DOD-07 — Session/token invalidation is assessed.**
  - Evidence/acceptance: Logout, expiry, rotation/revocation and stolen-token risk are explicit.
- [ ] **DOD-08 — Service/agent identities follow least privilege.**
  - Evidence/acceptance: Machine credentials and scopes are bounded and observable.
- [ ] **DOD-09 — Sensitive actions have appropriate re-auth/approval controls.**
  - Evidence/acceptance: High-impact flows are not treated like ordinary reads.
- [ ] **DOD-10 — Authorization regressions have automated tests.**
  - Evidence/acceptance: Critical matrix rows become executable tests where feasible.
- [ ] **DOD-11 — P0/P1 auth findings have reproducible evidence.**
  - Evidence/acceptance: Exploitability is demonstrated safely without overclaiming.
- [ ] **DOD-12 — IAM gate state is issued.**
  - Evidence/acceptance: Unknown critical authorization surfaces prevent false PASS.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
