# Initialize Skill Runtime — Operational Protocol

Create a reproducible execution baseline that tells later skills exactly what pack, workspace, mode, permissions, tools, and evidence snapshot they are operating on.

## Canonical lifecycle

`PACKAGE → INSTALL → INTEGRATE → INITIALIZE → EXECUTE → VERIFY`

## Stage boundaries

- **INSTALL** makes skill directories available at an explicit discovery scope.
- **INTEGRATE** proves host discovery, precedence, trust, metadata, and dependencies.
- **INITIALIZE** freezes runtime identity, permissions, tools, and run state.
- **EXECUTE** activates selected skills against the task.
- **VERIFY** proves structural/runtime health and preserves failures/unknowns.

## Client interoperability

The Agent Skills specification defines what lives inside a skill, not a mandatory filesystem location. Cross-client implementations commonly scan `.agents/skills`. Codex currently scans repository `.agents/skills`, user `$HOME/.agents/skills`, admin `/etc/codex/skills`, and bundled system skills.

## Activation

- ChatGPT skill surfaces can activate via `@` selection when available.
- Codex CLI/IDE can list with `/skills` and explicitly mention a skill with `$skill-name`.
- Non-interactive Codex automation can use `codex exec`; it is read-only by default. Use `--sandbox workspace-write` only for authorized APPLY execution.

## Safety

Never conflate host authentication with authorization to change a repository. Use least privilege, explicit sandbox scope, collision detection, and reversible writes.
