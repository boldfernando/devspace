# Initialize Skill Runtime — DoR / DoD

Use this as an execution gate. Each criterion must be evidence-backed, `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Installed skill root is readable.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-02 — Integration status is not failed for the requested skills.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-03 — Workspace/repository identity is resolvable.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-04 — Execution mode is explicit.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-05 — Sandbox/permission policy is known.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-06 — Tool availability can be probed safely.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-07 — Secret-handling policy is defined.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-08 — State/output path is safe.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-09 — Clock/timestamp source is available.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-10 — Prior state collision/overwrite policy is known.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.

### DoR blockers

- Execution mode or permission boundary is unknown for a mutating run.
- Required skill integration is failed.
- State destination would overwrite unrelated or protected data.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Pack version and selected skill versions are recorded.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-02 — Repository/workspace path and Git identity are recorded when applicable.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-03 — Execution mode and permission boundary are recorded.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-04 — Available/missing tools are inventoried.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-05 — Required dependency readiness is recorded.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-06 — Requested skill set is frozen for the run or marked dynamic.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-07 — Run ID and timestamp are generated.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-08 — State is emitted as JSON.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-09 — Persisted state is written only when `--write`/authorization is present.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-10 — Prior state is not silently overwritten.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-11 — Unknown runtime capabilities are explicit.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-12 — Initialization does not perform the domain review itself.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.

## Handoff evidence

- Record source pack/version, target scope/path, host/client, run ID, mode, and authorization boundary.
- Link every FAIL/UNKNOWN criterion to a corrective next action.
- For APPLY, record exact changed paths, rollback/removal method, and post-change verification.
- Do not mark an unexecuted activation or eval as PASS.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available.
