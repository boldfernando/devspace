#!/usr/bin/env python3
from pathlib import Path
import argparse, json, shutil, subprocess, uuid
from datetime import datetime, timezone

def run(cmd,cwd):
    try: return subprocess.check_output(cmd,cwd=cwd,text=True,stderr=subprocess.DEVNULL).strip()
    except Exception: return None

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--pack-root',default=str(Path(__file__).resolve().parents[3]))
    ap.add_argument('--workspace',default='.')
    ap.add_argument('--mode',choices=['READ_ONLY','PLAN','APPLY','VERIFY','RELEASE_GATE'],default='READ_ONLY')
    ap.add_argument('--output',default='.skill-runtime/state.json')
    ap.add_argument('--write',action='store_true')
    args=ap.parse_args()
    pack=Path(args.pack_root).resolve(); ws=Path(args.workspace).resolve()
    reg=json.loads((pack/'skill-registry.json').read_text(encoding='utf-8')) if (pack/'skill-registry.json').exists() else {}
    tools={x:bool(shutil.which(x)) for x in ['git','python','python3','codex','node','npm','pnpm','yarn','docker','jq','rg']}
    state={'run_id':str(uuid.uuid4()),'initialized_at':datetime.now(timezone.utc).isoformat(),'pack':reg.get('pack'),'pack_version':reg.get('version'),'skill_count':len(reg.get('skills',[])),'workspace':str(ws),'mode':args.mode,'git':{'root':run(['git','rev-parse','--show-toplevel'],ws),'head':run(['git','rev-parse','HEAD'],ws),'branch':run(['git','branch','--show-current'],ws)},'tools':tools}
    text=json.dumps(state,indent=2)
    print(text)
    if args.write:
        out=(ws/args.output).resolve() if not Path(args.output).is_absolute() else Path(args.output)
        out.parent.mkdir(parents=True,exist_ok=True); out.write_text(text+'\n',encoding='utf-8')
if __name__=='__main__': main()
