---
name: initialize-skill-runtime
description: "Use this skill when an installed and integrated skill system needs an execution baseline before tasks run. Validate the pack, capture repository/runtime identity, resolve available tools and permissions, create an execution ledger, and initialize state without starting domain review work prematurely."
metadata:
  version: "3.0.0"
  order: "OP03"
  family: skill-system-lifecycle
---

# Initialize Skill Runtime

## Objective

Create a reproducible execution baseline that tells later skills exactly what pack, workspace, mode, permissions, tools, and evidence snapshot they are operating on.

## Use this skill when

- A skill system is about to execute against a repository or workspace.
- A run needs durable state, provenance, and authorization boundaries.
- CI or an agent runtime needs a machine-readable initialization record.

## Do not use this skill when

- The request is only to install files and no execution is planned.
- A prior runtime state is current, valid, and explicitly reused.

## Required inputs

- Installed skill root or registry
- Target workspace/repository
- Execution mode
- Authorization/sandbox policy
- Available host tools and credentials by name, never secret value
- Run output directory or state destination

If an input is unavailable, continue only when execution remains safe and mark the affected state `UNKNOWN`; never fabricate a path, host capability, credential, or authorization.

## Operating rules

- Detect before mutate.
- Default to least privilege and dry-run/READ_ONLY when authorization is ambiguous.
- Preserve project-level trust boundaries; repository skills can contain instructions and must not be silently trusted in a custom client.
- Never expose secret values in logs, receipts, state files, or prompts.
- Do not silently overwrite same-name skills.
- Installation is not integration; integration is not initialization; initialization is not execution; execution is not verification.
- Every mutating stage needs rollback/removal instructions.
- Every executed child skill retains its own DoR/DoD and evidence contract.

## Definition of Ready (DoR)

Evaluate this gate before expensive, active, or mutating work. Use `READY | CONDITIONAL | NOT_READY`.
- [ ] Installed skill root is readable.
- [ ] Integration status is not failed for the requested skills.
- [ ] Workspace/repository identity is resolvable.
- [ ] Execution mode is explicit.
- [ ] Sandbox/permission policy is known.
- [ ] Tool availability can be probed safely.
- [ ] Secret-handling policy is defined.
- [ ] State/output path is safe.
- [ ] Clock/timestamp source is available.
- [ ] Prior state collision/overwrite policy is known.

Detailed evidence expectations: `references/DOR_DOD.md`.

## Definition of Done (DoD)

Use `DONE | PARTIAL | NOT_DONE`; file presence or command invocation alone is not completion.
- [ ] Pack version and selected skill versions are recorded.
- [ ] Repository/workspace path and Git identity are recorded when applicable.
- [ ] Execution mode and permission boundary are recorded.
- [ ] Available/missing tools are inventoried.
- [ ] Required dependency readiness is recorded.
- [ ] Requested skill set is frozen for the run or marked dynamic.
- [ ] Run ID and timestamp are generated.
- [ ] State is emitted as JSON.
- [ ] Persisted state is written only when `--write`/authorization is present.
- [ ] Prior state is not silently overwritten.
- [ ] Unknown runtime capabilities are explicit.
- [ ] Initialization does not perform the domain review itself.

### Hard blockers / non-negotiables

- Execution mode or permission boundary is unknown for a mutating run.
- Required skill integration is failed.
- State destination would overwrite unrelated or protected data.

## Workflow

1. Validate the installed pack and registry.
2. Inspect repository identity and Git state without mutation.
3. Probe host/runtime executables needed for the chosen execution path.
4. Run `scripts/init_runtime.py`; default to stdout-only, use `--write` only when authorized.
5. Hand the resulting state record to `execute-skill-workflow`.

## Available scripts

- `scripts/init_runtime.py` — deterministic helper for this lifecycle stage. Inspect/dry-run before mutating use.

## Outputs

- skill-runtime-state.json
- tool/dependency matrix
- run identifier
- execution baseline

## Handoff contract

Return: scope/host, source and destination identities, stage status, evidence, exact mutations, rollback/removal path, executed verification, blockers/unknowns, and the next lifecycle stage.

## Resources

- Read `references/REFERENCE.md` for the operational protocol.
- Read `references/DOR_DOD.md` before execution.
- Read `references/SOURCES.md` when host behavior or installation paths need current verification.
- Use `evals/evals.json` for trigger/output evals.
- Use `assets/finding-template.json` for standalone structured findings.
