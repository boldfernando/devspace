# Review Product JTBD Reference Rubric

## Objective

Map product intent to implemented capabilities and measurable outcomes so engineering priorities are grounded in actual user and business value.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- No invented persona or requirement
- Every critical JTBD maps to evidence or UNKNOWN
- AS-IS and TO-BE are separate
- Metrics are tied to observable events

## Outputs expected

- JTBD_MATRIX.json
- USE_CASE_MATRIX.json
- AS_IS_JOURNEYS.md
- TO_BE_JOURNEYS.md
- CAPABILITY_GAPS.json

## Gate interpretation

- Critical journeys identified
- Business rules traceable
- Outcome metrics defined

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
