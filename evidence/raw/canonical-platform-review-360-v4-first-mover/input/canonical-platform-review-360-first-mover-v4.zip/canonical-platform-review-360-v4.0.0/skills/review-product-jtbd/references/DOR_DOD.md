# Review Product JTBD — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Product scope and decision are explicit.**
  - Evidence: Feature/platform area and reason for review are recorded.
- [ ] **DOR-02 — Primary users/actors are identifiable.**
  - Evidence: Personas, roles, system actors, or unknowns are documented.
- [ ] **DOR-03 — Critical outcomes or business goals are available.**
  - Evidence: KPIs/OKRs/expected outcomes or proxy objectives are known.
- [ ] **DOR-04 — Current user/system journeys can be observed.**
  - Evidence: UI, docs, analytics, code flows, tickets, or interviews provide AS-IS evidence.
- [ ] **DOR-05 — Business rules have an authority source.**
  - Evidence: Code, contracts, policy docs, or domain owner source is identifiable.
- [ ] **DOR-06 — Known constraints are documented.**
  - Evidence: Regulatory, operational, security, financial, accessibility, or channel constraints are in scope.
- [ ] **DOR-07 — Analytics/qualitative evidence is bounded.**
  - Evidence: Available telemetry/feedback can be used without assuming missing data.
- [ ] **DOR-08 — TO-BE is distinguishable from AS-IS.**
  - Evidence: Aspirations are not treated as implemented behavior.

### DoR blockers

- No identifiable user/system outcome, making product value claims speculative.
- Only TO-BE marketing claims exist with no observable AS-IS evidence.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — JTBD matrix is complete for critical actors.**
  - Evidence/acceptance: Each priority actor has job, trigger, desired outcome, obstacles, and evidence.
- [ ] **DOD-02 — Use cases are mapped end-to-end.**
  - Evidence/acceptance: Inputs, actions, outputs, business rules, failure paths, and outcomes are represented.
- [ ] **DOD-03 — AS-IS and TO-BE journeys are separated.**
  - Evidence/acceptance: Current behavior and target behavior are independently documented.
- [ ] **DOD-04 — Critical path pain points are evidence-backed.**
  - Evidence/acceptance: Friction/abandonment is tied to observed behavior, telemetry, or explicit uncertainty.
- [ ] **DOD-05 — Business-rule gaps are identified.**
  - Evidence/acceptance: Missing, contradictory, duplicated, or unenforced rules are recorded.
- [ ] **DOD-06 — Outcome/KPI linkage exists.**
  - Evidence/acceptance: Proposed changes state measurable leading/lagging indicators.
- [ ] **DOD-07 — Technical capabilities trace to user value.**
  - Evidence/acceptance: Capabilities are not prioritized solely by implementation novelty.
- [ ] **DOD-08 — Non-goals and out-of-scope cases are explicit.**
  - Evidence/acceptance: Scope creep is constrained.
- [ ] **DOD-09 — Product risks and assumptions are explicit.**
  - Evidence/acceptance: Unvalidated hypotheses are labeled and assigned validation actions.
- [ ] **DOD-10 — Priority ordering is defensible.**
  - Evidence/acceptance: Impact, risk, reach, dependency, or strategic rationale is recorded.
- [ ] **DOD-11 — Acceptance signals exist for priority improvements.**
  - Evidence/acceptance: Success can be verified after implementation.
- [ ] **DOD-12 — Handoff can drive downstream UX/engineering review.**
  - Evidence/acceptance: Artifacts are concrete enough for other skills to consume.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
