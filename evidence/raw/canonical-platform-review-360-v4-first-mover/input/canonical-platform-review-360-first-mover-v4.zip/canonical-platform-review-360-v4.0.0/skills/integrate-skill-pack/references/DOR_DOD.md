# Integrate Skill Pack — DoR / DoD

Use this as an execution gate. Each criterion must be evidence-backed, `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — At least one installed or mounted skill path is available.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-02 — Host/client discovery model is known or can be inspected.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-03 — Project trust boundary is explicit for repository-loaded skills.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-04 — Skill names and descriptions can be parsed.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-05 — Potential user/repo/admin scopes can be enumerated safely.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-06 — Declared tool dependencies can be inspected without exposing secrets.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-07 — No config mutation is required merely to diagnose discovery.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.
- [ ] **DOR-08 — Output integration matrix location is available.**
  - Evidence: Record the concrete path, host capability, permission, registry entry, command result, or explicit authorization that proves this criterion.

### DoR blockers

- The host discovery roots cannot be determined and no custom path is supplied.
- Untrusted project skills would be activated without an explicit trust decision.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — All intended discovery roots are enumerated.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-02 — Installed skill names are parsed from frontmatter.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-03 — Name collisions and precedence are reported.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-04 — Project-level trust risk is assessed.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-05 — `agents/openai.yaml` is parsed where present.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-06 — Declared tool/MCP dependencies are inventoried.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-07 — Missing or failing dependencies remain explicit.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-08 — Host visibility is verified when the host offers a catalog command/UI.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-09 — No unnecessary duplicate skill installation was introduced.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-10 — Any required config change is minimal, reversible, and separately authorized.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-11 — Integration matrix maps skill → source → scope → effective visibility.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.
- [ ] **DOD-12 — Next activation step is explicit.**
  - Evidence/acceptance: Attach the installation/integration/runtime/execution record or executed verification proving this criterion.

## Handoff evidence

- Record source pack/version, target scope/path, host/client, run ID, mode, and authorization boundary.
- Link every FAIL/UNKNOWN criterion to a corrective next action.
- For APPLY, record exact changed paths, rollback/removal method, and post-change verification.
- Do not mark an unexecuted activation or eval as PASS.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available.
