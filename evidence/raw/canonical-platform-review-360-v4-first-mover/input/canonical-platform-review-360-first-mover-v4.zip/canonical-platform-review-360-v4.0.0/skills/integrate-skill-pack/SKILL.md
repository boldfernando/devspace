---
name: integrate-skill-pack
description: "Use this skill when installed Agent Skills must be integrated with their host or project: verify discovery paths, precedence, name collisions, `agents/openai.yaml`, declared dependencies, trust boundaries, and runtime visibility. Do not add host configuration unless it is necessary and explicitly authorized."
metadata:
  version: "3.0.0"
  order: "OP02"
  family: skill-system-lifecycle
---

# Integrate Skill Pack

## Objective

Prove that installed skills are discoverable and usable by the intended host without hidden precedence, trust, or dependency failures.

## Use this skill when

- Skills were installed but do not appear in the client selector/catalog.
- A repository has multiple skill scopes or possible name collisions.
- OpenAI metadata/dependencies or another client integration must be checked.
- A custom agent implementation needs the standard discover → parse → catalog → activate lifecycle.

## Do not use this skill when

- No skills have been installed or made available to the target host.
- Only skill content quality is under review, not runtime integration.

## Required inputs

- Target repository/workspace or host home
- Expected scope(s)
- Installed skill names or source registry
- Host/client identity when known
- Trust and dependency policy

If an input is unavailable, continue only when execution remains safe and mark the affected state `UNKNOWN`; never fabricate a path, host capability, credential, or authorization.

## Operating rules

- Detect before mutate.
- Default to least privilege and dry-run/READ_ONLY when authorization is ambiguous.
- Preserve project-level trust boundaries; repository skills can contain instructions and must not be silently trusted in a custom client.
- Never expose secret values in logs, receipts, state files, or prompts.
- Do not silently overwrite same-name skills.
- Installation is not integration; integration is not initialization; initialization is not execution; execution is not verification.
- Every mutating stage needs rollback/removal instructions.
- Every executed child skill retains its own DoR/DoD and evidence contract.

## Definition of Ready (DoR)

Evaluate this gate before expensive, active, or mutating work. Use `READY | CONDITIONAL | NOT_READY`.
- [ ] At least one installed or mounted skill path is available.
- [ ] Host/client discovery model is known or can be inspected.
- [ ] Project trust boundary is explicit for repository-loaded skills.
- [ ] Skill names and descriptions can be parsed.
- [ ] Potential user/repo/admin scopes can be enumerated safely.
- [ ] Declared tool dependencies can be inspected without exposing secrets.
- [ ] No config mutation is required merely to diagnose discovery.
- [ ] Output integration matrix location is available.

Detailed evidence expectations: `references/DOR_DOD.md`.

## Definition of Done (DoD)

Use `DONE | PARTIAL | NOT_DONE`; file presence or command invocation alone is not completion.
- [ ] All intended discovery roots are enumerated.
- [ ] Installed skill names are parsed from frontmatter.
- [ ] Name collisions and precedence are reported.
- [ ] Project-level trust risk is assessed.
- [ ] `agents/openai.yaml` is parsed where present.
- [ ] Declared tool/MCP dependencies are inventoried.
- [ ] Missing or failing dependencies remain explicit.
- [ ] Host visibility is verified when the host offers a catalog command/UI.
- [ ] No unnecessary duplicate skill installation was introduced.
- [ ] Any required config change is minimal, reversible, and separately authorized.
- [ ] Integration matrix maps skill → source → scope → effective visibility.
- [ ] Next activation step is explicit.

### Hard blockers / non-negotiables

- The host discovery roots cannot be determined and no custom path is supplied.
- Untrusted project skills would be activated without an explicit trust decision.

## Workflow

1. Run `scripts/inspect_integration.py` against the repository/user scopes.
2. Apply deterministic precedence: project scope should override user scope in custom clients; for Codex, report duplicate names rather than assuming merge semantics.
3. Parse `agents/openai.yaml` and dependency declarations.
4. Verify visibility with host-native catalog mechanisms when available, such as `/skills` in Codex CLI/IDE.
5. Only if required, propose the smallest host configuration change and keep APPLY behind authorization.

## Available scripts

- `scripts/inspect_integration.py` — deterministic helper for this lifecycle stage. Inspect/dry-run before mutating use.

## Outputs

- skill-integration-matrix.json
- collision/precedence report
- dependency matrix
- host visibility status

## Handoff contract

Return: scope/host, source and destination identities, stage status, evidence, exact mutations, rollback/removal path, executed verification, blockers/unknowns, and the next lifecycle stage.

## Resources

- Read `references/REFERENCE.md` for the operational protocol.
- Read `references/DOR_DOD.md` before execution.
- Read `references/SOURCES.md` when host behavior or installation paths need current verification.
- Use `evals/evals.json` for trigger/output evals.
- Use `assets/finding-template.json` for standalone structured findings.
