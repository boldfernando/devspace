# Review Resilience and Errors — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Dependency map exists for scoped flows.**
  - Evidence: Internal/external calls, queues, storage, and critical providers are identified.
- [ ] **DOR-02 — Current error handling is inspectable.**
  - Evidence: Error classes/codes/middleware/UI mapping/logging paths are available.
- [ ] **DOR-03 — Timeout/retry configuration is discoverable.**
  - Evidence: Client, server, queue, DB, and provider policies can be compared.
- [ ] **DOR-04 — Expected availability/SLO behavior is known.**
  - Evidence: Graceful degradation can be judged against product expectations.
- [ ] **DOR-05 — Failure testing authorization is explicit.**
  - Evidence: Fault injection/chaos/provider simulation runs only in safe targets.
- [ ] **DOR-06 — Idempotency-sensitive operations are identified.**
  - Evidence: Payments/orders/webhooks/approvals or irreversible actions are prioritized.
- [ ] **DOR-07 — Queue/dead-letter semantics are inspectable where applicable.**
  - Evidence: Retry lifecycle can be traced.
- [ ] **DOR-08 — User-safe versus diagnostic error channels are distinct or reviewable.**
  - Evidence: Sensitive details are not intentionally surfaced to users.

### DoR blockers

- Requested fault injection is not authorized for the target.
- Critical irreversible actions lack any safe test/sandbox path.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Error taxonomy/contract is documented.**
  - Evidence/acceptance: Stable codes/categories/retryability/correlation semantics exist or gaps are explicit.
- [ ] **DOD-02 — Timeout hierarchy is coherent.**
  - Evidence/acceptance: Upstream/downstream timeouts avoid indefinite waits and cascading failure.
- [ ] **DOD-03 — Retry ownership is singular and bounded.**
  - Evidence/acceptance: Backoff/jitter/max attempts prevent retry amplification.
- [ ] **DOD-04 — Idempotency is verified for critical operations.**
  - Evidence/acceptance: Retries/replays do not duplicate irreversible side effects.
- [ ] **DOD-05 — Circuit breaker/degradation strategy is assessed.**
  - Evidence/acceptance: Critical provider outages have explicit fail-open/fail-closed/degraded behavior.
- [ ] **DOD-06 — Queue/DLQ handling is reviewed.**
  - Evidence/acceptance: Poison messages, replay, deduplication, and operator recovery are defined.
- [ ] **DOD-07 — User error messages are safe/actionable.**
  - Evidence/acceptance: No secret/stack leakage; users receive clear next action where possible.
- [ ] **DOD-08 — Correlation and diagnostic context are preserved.**
  - Evidence/acceptance: Operators can trace failure without exposing sensitive data.
- [ ] **DOD-09 — Failure paths are tested where authorized.**
  - Evidence/acceptance: Timeout/provider/downstream failure is exercised or marked UNKNOWN.
- [ ] **DOD-10 — Recovery/runbook expectations are documented.**
  - Evidence/acceptance: Operational response for critical failures is actionable.
- [ ] **DOD-11 — Applied changes pass regression/failure verification.**
  - Evidence/acceptance: A resilience fix does not only pass happy-path tests.
- [ ] **DOD-12 — Residual single points/cascading risks are prioritized.**
  - Evidence/acceptance: Release-affecting failure modes are explicit.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
