# Review Resilience and Errors Reference Rubric

## Objective

Make failure behavior predictable, bounded, observable, and recoverable across local and external dependencies.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- No infinite/unbounded retry
- Timeouts exist at external boundaries
- Sensitive details not leaked to users
- Correlation data survives error propagation

## Outputs expected

- ERROR_TAXONOMY.json
- RETRY_TIMEOUT_MAP.json
- RESILIENCE_FINDINGS.json
- RECOVERY_TEST_PLAN.md

## Gate interpretation

- Critical provider failures degrade safely
- Retry storms prevented
- Errors observable and actionable

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
