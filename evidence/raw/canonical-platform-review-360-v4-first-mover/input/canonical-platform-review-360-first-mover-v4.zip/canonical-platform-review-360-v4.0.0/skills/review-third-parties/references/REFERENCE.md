# Review Third-Party Integrations Reference Rubric

## Objective

Inventory and harden external dependencies so failures, cost, permissions, and replacement risk are visible and bounded.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- No secret values copied into report
- Provider assumptions source-linked and dated
- Fallback does not silently corrupt behavior
- Webhook authenticity/idempotency reviewed

## Outputs expected

- PROVIDER_REGISTER.json
- THIRD_PARTY_RISK.json
- DEPRECATION_REGISTER.json
- EXIT_STRATEGY.md

## Gate interpretation

- Critical providers owned
- Quotas/failures observable
- High-risk deprecations planned

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
