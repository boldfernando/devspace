# Review Third-Party Integrations — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Third-party inventory can be derived.**
  - Evidence: Dependencies, env names, SDKs, webhooks, manifests, docs, or runtime calls identify providers.
- [ ] **DOR-02 — Provider ownership/purpose is discoverable.**
  - Evidence: Why each critical provider exists and who owns it can be established or marked UNKNOWN.
- [ ] **DOR-03 — Data-flow context is available.**
  - Evidence: Data sent/received and sensitivity classes can be reviewed without exposing values.
- [ ] **DOR-04 — Authentication/permission model is inspectable.**
  - Evidence: Keys/OAuth/scopes/service accounts are identified by name/scope, not secret value.
- [ ] **DOR-05 — Rate limit/quota/SLA evidence is available for critical providers.**
  - Evidence: Official contracts/docs or runtime behavior can be checked.
- [ ] **DOR-06 — Cost/billing relevance is known.**
  - Evidence: High-variable-cost providers are prioritized.
- [ ] **DOR-07 — Fallback/degraded behavior can be traced.**
  - Evidence: Critical dependency failure semantics are reviewable.
- [ ] **DOR-08 — Integration test/sandbox policy is known.**
  - Evidence: Tests avoid triggering real charges/side effects unintentionally.

### DoR blockers

- A critical provider cannot be identified but the product depends on it for a scoped journey.
- Testing would incur unauthorized charges or external side effects.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Provider register is complete for scoped critical dependencies.**
  - Evidence/acceptance: Provider, purpose, owner, surface, environment, and version/SDK are recorded.
- [ ] **DOD-02 — Data/auth/permission contract is documented.**
  - Evidence/acceptance: Shared data, scopes, credentials, and trust boundary are explicit.
- [ ] **DOD-03 — Rate limits/quotas/timeouts are documented.**
  - Evidence/acceptance: Runtime behavior respects provider constraints.
- [ ] **DOD-04 — Retry/idempotency/webhook semantics are assessed.**
  - Evidence/acceptance: Duplicate/replay/ordering behavior is safe for mutations/events.
- [ ] **DOD-05 — Failure/fallback/degraded mode is explicit.**
  - Evidence/acceptance: Primary/secondary/fail-open/fail-closed behavior matches product risk.
- [ ] **DOD-06 — Observability is sufficient.**
  - Evidence/acceptance: Provider latency/error/rate-limit/usage can be attributed.
- [ ] **DOD-07 — SLA/support dependency is understood.**
  - Evidence/acceptance: Critical business continuity assumptions are not implicit.
- [ ] **DOD-08 — Cost exposure is assessed.**
  - Evidence/acceptance: Usage-based cost drivers and abuse/runaway risks are visible.
- [ ] **DOD-09 — Privacy/data residency/contractual issues are surfaced.**
  - Evidence/acceptance: Relevant regulatory/vendor constraints are documented.
- [ ] **DOD-10 — Exit/replace strategy exists for critical lock-in.**
  - Evidence/acceptance: Data export, abstraction, or migration constraints are explicit.
- [ ] **DOD-11 — Critical integrations have safe tests.**
  - Evidence/acceptance: Sandbox/mock/contract tests verify behavior without uncontrolled side effects.
- [ ] **DOD-12 — Third-party gate state is issued.**
  - Evidence/acceptance: Unsupported critical provider dependency can block release as appropriate.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
