# Review Web Performance — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Representative build/environment is available.**
  - Evidence: Measurements use a known build and are not silently taken from an unrelated dev mode.
- [ ] **DOR-02 — Priority routes/journeys are defined.**
  - Evidence: Performance work is tied to user-critical surfaces.
- [ ] **DOR-03 — Measurement profile is explicit.**
  - Evidence: Device, viewport, CPU/network throttling, cache state, and geography where relevant are recorded.
- [ ] **DOR-04 — Lab versus field telemetry is separated.**
  - Evidence: Lighthouse/synthetic and RUM/CrUX/production evidence are not conflated.
- [ ] **DOR-05 — Performance budgets/SLOs exist or targets are agreed.**
  - Evidence: There is a threshold for deciding improvement.
- [ ] **DOR-06 — Repeated measurements are feasible.**
  - Evidence: Before/after results can control obvious variance.
- [ ] **DOR-07 — Load testing is authorized for the selected target.**
  - Evidence: No stress/spike/soak tests run against unapproved systems.
- [ ] **DOR-08 — Backend/provider effects can be distinguished.**
  - Evidence: Network and server timing evidence is available when latency attribution matters.

### DoR blockers

- No representative surface/build can be measured.
- Requested load/active testing lacks explicit target authorization.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Baseline metrics are captured reproducibly.**
  - Evidence/acceptance: Core Web Vitals/lab timing and measurement conditions are recorded.
- [ ] **DOD-02 — Network waterfall is analyzed.**
  - Evidence/acceptance: Blocking, duplicate, oversized, slow, and third-party requests are identified.
- [ ] **DOD-03 — Bundle/asset costs are quantified.**
  - Evidence/acceptance: JS/CSS/images/fonts and route chunks are measured before optimization.
- [ ] **DOD-04 — Rendering bottlenecks are evidenced.**
  - Evidence/acceptance: Main-thread, hydration, layout, paint, or long-task costs are tied to traces/profiles.
- [ ] **DOD-05 — Caching/compression/CDN behavior is assessed.**
  - Evidence/acceptance: Misses, invalidation, cache headers, compression, and asset delivery are understood.
- [ ] **DOD-06 — Server/API contribution is quantified.**
  - Evidence/acceptance: TTFB/backend/provider latency is separated from client work where possible.
- [ ] **DOD-07 — Load/concurrency behavior is measured only when authorized.**
  - Evidence/acceptance: Results include workload model and target safety constraints.
- [ ] **DOD-08 — Optimizations have before/after evidence.**
  - Evidence/acceptance: Claimed gains are not based on code inspection alone.
- [ ] **DOD-09 — Regressions/variance are controlled.**
  - Evidence/acceptance: Multiple runs or field confirmation reduce false wins.
- [ ] **DOD-10 — Budgets are enforced or gap is explicit.**
  - Evidence/acceptance: CI/runtime guardrails are proposed or implemented where justified.
- [ ] **DOD-11 — Cost/UX tradeoffs are documented.**
  - Evidence/acceptance: Performance wins that increase cost or degrade functionality are explicit.
- [ ] **DOD-12 — Performance gate state is issued.**
  - Evidence/acceptance: Blocking metrics and residual hotspots are clear.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
