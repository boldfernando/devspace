# Review Web Performance Reference Rubric

## Objective

Measure user-facing performance and capacity bottlenecks, then prioritize evidence-backed optimizations by impact and cost.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Lab vs field clearly labeled
- Environment and test conditions recorded
- No destructive load test on production without authorization
- Before/after evidence for applied optimizations

## Outputs expected

- PERFORMANCE_BASELINE.json
- WATERFALL_FINDINGS.json
- BUNDLE_FINDINGS.json
- LOAD_RESULTS.json
- PERFORMANCE_PLAN.md

## Gate interpretation

- Performance budget met or exception documented
- No critical regression
- Capacity test scope authorized

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
