# Discover Codebase Reference Rubric

## Objective

Build a factual inventory of the repository and runtime surfaces so later reviews operate on the code that actually exists.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Every claimed framework has source/manifests evidence
- Generated/vendor code is tagged separately
- Entrypoints and deployables are explicit
- Unknown external services remain UNKNOWN until verified

## Outputs expected

- STACK.json
- REPO_MAP.json
- RUNTIME_MAP.json
- DEPENDENCY_GRAPH.json
- SURFACE_INVENTORY.json

## Gate interpretation

- Repository root known
- Package-manager authority known
- Deployable surfaces enumerated
- Critical unknowns recorded

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
