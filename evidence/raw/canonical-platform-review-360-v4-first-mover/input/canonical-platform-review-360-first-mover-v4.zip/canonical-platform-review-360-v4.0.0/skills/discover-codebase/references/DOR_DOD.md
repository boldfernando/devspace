# Discover Codebase — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Repository/workspace root is identifiable.**
  - Evidence: A readable path, archive, checkout, or mounted workspace is available.
- [ ] **DOR-02 — Discovery is authorized as read-only.**
  - Evidence: Filesystem inspection, manifest parsing, and bounded command execution are permitted.
- [ ] **DOR-03 — Exclusion boundaries are known.**
  - Evidence: Vendor caches, generated output, secrets, giant datasets, or prohibited directories are identified where applicable.
- [ ] **DOR-04 — Top-level manifests/configuration are readable.**
  - Evidence: Package, workspace, container, CI, IaC, or runtime manifests can be inspected if present.
- [ ] **DOR-05 — Nested repositories/worktrees/submodules are considered.**
  - Evidence: Discovery will not silently flatten multiple provenance boundaries.
- [ ] **DOR-06 — Runtime/deployment evidence is distinguished from source.**
  - Evidence: The task records whether it is code-only or includes deployed/runtime surfaces.
- [ ] **DOR-07 — Sensitive material handling is defined.**
  - Evidence: Discovery records secret names/locations, never secret values.
- [ ] **DOR-08 — Output artifact location is available.**
  - Evidence: Inventory JSON/Markdown can be written outside product state.
- [ ] **DOR-09 — Baseline timestamp/source identity is recorded.**
  - Evidence: Discovery can be tied to a specific checkout/evidence snapshot.
- [ ] **DOR-10 — Unknown technology detection is allowed.**
  - Evidence: Unrecognized manifests or surfaces can be flagged for follow-up rather than guessed.

### DoR blockers

- Workspace/repository cannot be read.
- Discovery would require exposing secrets or prohibited data without a safe redaction path.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Languages and package ecosystems are inventoried.**
  - Evidence/acceptance: Detected languages, package managers, lockfiles, and workspace authorities are recorded.
- [ ] **DOD-02 — Repository topology is materialized.**
  - Evidence/acceptance: Monolith/monorepo, apps/packages/services, nested repos, worktrees, and submodules are represented.
- [ ] **DOD-03 — Frontend and backend runtimes are identified.**
  - Evidence/acceptance: Frameworks, entrypoints, ports/commands when evidenced, and server/client boundaries are recorded.
- [ ] **DOD-04 — API and integration surfaces are inventoried.**
  - Evidence/acceptance: REST/RPC/GraphQL/events/webhooks/WebSocket/SSE/MCP/agent interfaces are found or explicitly absent/UNKNOWN.
- [ ] **DOD-05 — Data surfaces are inventoried.**
  - Evidence/acceptance: Databases, ORM/query layers, migrations, caches, queues, object stores, search/vector stores are mapped.
- [ ] **DOD-06 — AI/agent surfaces are inventoried.**
  - Evidence/acceptance: LLM providers, agents, tools, MCP/A2A, prompt/config locations are recorded when present.
- [ ] **DOD-07 — CI/CD/container/IaC surfaces are inventoried.**
  - Evidence/acceptance: Workflow files, Docker/OCI, deployment and infrastructure definitions are mapped.
- [ ] **DOD-08 — Test and observability tooling is inventoried.**
  - Evidence/acceptance: Test frameworks, telemetry/logging/monitoring libraries/configurations are recorded.
- [ ] **DOD-09 — Authority and drift candidates are highlighted.**
  - Evidence/acceptance: Competing lockfiles, duplicate configs, stale generated artifacts, or parallel implementations are flagged.
- [ ] **DOD-10 — Unknowns are explicit.**
  - Evidence/acceptance: Unresolved framework/runtime ownership is marked UNKNOWN with next evidence needed.
- [ ] **DOD-11 — Machine-readable inventory artifacts are emitted.**
  - Evidence/acceptance: STACK/REPO/RUNTIME/SURFACE outputs or equivalent contain source pointers.
- [ ] **DOD-12 — No product state was mutated.**
  - Evidence/acceptance: Discovery itself remains read-only unless separately authorized.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
