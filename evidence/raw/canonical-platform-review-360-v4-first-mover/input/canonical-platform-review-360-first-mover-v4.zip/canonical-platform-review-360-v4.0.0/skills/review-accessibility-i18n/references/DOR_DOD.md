# Review Accessibility and Internationalization — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — Target pages/components/journeys are identified.**
  - Evidence: Accessibility review is bounded to meaningful user surfaces.
- [ ] **DOR-02 — Accessibility target is known.**
  - Evidence: WCAG 2.2 AA or stricter project requirement is recorded.
- [ ] **DOR-03 — Runnable/inspectable UI is available.**
  - Evidence: Browser or source/component evidence can be used.
- [ ] **DOR-04 — Supported browsers/input modes are known.**
  - Evidence: Keyboard, touch, pointer, zoom/reflow expectations are bounded.
- [ ] **DOR-05 — Assistive-technology/manual test capability is available or limitation noted.**
  - Evidence: Automated scanners are not treated as complete coverage.
- [ ] **DOR-06 — Supported locales/regions are known.**
  - Evidence: Language, currency, date/number/timezone behavior can be assessed.
- [ ] **DOR-07 — Translation catalogs/message extraction are accessible.**
  - Evidence: Hard-coded/localized strings can be reviewed.
- [ ] **DOR-08 — Critical transactional forms/errors are prioritized.**
  - Evidence: Accessibility of high-impact flows receives first attention.

### DoR blockers

- No observable UI/source surface for accessibility claims.
- The project’s required locale/accessibility scope is entirely unknown and cannot be bounded.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Automated accessibility checks are executed where feasible.**
  - Evidence/acceptance: axe/linter/browser tooling results are captured and triaged.
- [ ] **DOD-02 — Keyboard navigation/focus is manually assessed.**
  - Evidence/acceptance: Order, visibility, traps, dialogs, menus, and skip behavior are checked.
- [ ] **DOD-03 — Semantic structure/names/relationships are assessed.**
  - Evidence/acceptance: Headings, landmarks, labels, roles, descriptions, and error associations are correct.
- [ ] **DOD-04 — Contrast/non-color communication is assessed.**
  - Evidence/acceptance: Content/state does not rely on imperceptible color-only cues.
- [ ] **DOD-05 — Zoom/reflow/responsive accessibility is assessed.**
  - Evidence/acceptance: Priority tasks remain usable at required magnification/reflow.
- [ ] **DOD-06 — Motion/timing/input considerations are assessed.**
  - Evidence/acceptance: Reduced motion, target size, timeouts, and pointer alternatives are handled where applicable.
- [ ] **DOD-07 — Assistive-technology compatibility is sampled.**
  - Evidence/acceptance: Critical journeys receive screen-reader/AT checks when capability exists.
- [ ] **DOD-08 — Locale formatting is correct.**
  - Evidence/acceptance: Dates, numbers, currencies, units, timezone, and pluralization use locale-aware logic.
- [ ] **DOD-09 — Translation completeness/text expansion is assessed.**
  - Evidence/acceptance: Missing keys, clipped translations, concatenated strings, and fallback behavior are recorded.
- [ ] **DOD-10 — Critical defects have reproducible steps.**
  - Evidence/acceptance: Findings map to WCAG criteria where helpful and affected component/route.
- [ ] **DOD-11 — Applied fixes are regression-tested.**
  - Evidence/acceptance: Automated and manual critical-path checks rerun.
- [ ] **DOD-12 — A11y/i18n gate state is issued.**
  - Evidence/acceptance: Known critical barriers cannot be hidden by a high automated score.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
