# Review Accessibility and Internationalization Reference Rubric

## Objective

Verify that critical journeys remain operable and understandable across accessibility needs and supported locales/regions.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- WCAG level explicit
- Automated PASS never substitutes for manual checks
- Critical forms keyboard-operable
- Locale formatting deterministic

## Outputs expected

- A11Y_FINDINGS.json
- WCAG_MATRIX.json
- I18N_INVENTORY.json
- LOCALE_TEST_PLAN.md

## Gate interpretation

- No critical keyboard/focus blocker
- WCAG 2.2 AA posture documented
- Supported locale flows verified

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
