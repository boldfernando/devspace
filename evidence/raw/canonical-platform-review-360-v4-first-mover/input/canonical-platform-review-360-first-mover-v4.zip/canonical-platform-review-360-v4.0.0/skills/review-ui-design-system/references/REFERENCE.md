# Review UI Design System Reference Rubric

## Objective

Assess the UI as a system of reusable primitives and states, then identify the smallest changes that improve consistency, accessibility, and maintainability.

## Evidence hierarchy

Prefer executed behavior/tests and runtime state over documentation. Project-specific artifacts outrank generic best-practice prose. Re-verify time-sensitive external claims.

## Required review dimensions

- Brand/token authority preserved
- Focus and error states visible
- Responsive evidence captured
- No new duplicate component layer proposed without cause

## Outputs expected

- UI_INVENTORY.json
- DESIGN_SYSTEM_DRIFT.json
- RESPONSIVE_FINDINGS.json
- UI_REMEDIATION_PLAN.md

## Gate interpretation

- Critical components have complete states
- No severe responsive breakage
- Design-system authority identified

## Severity guidance

- **P0**: active exploit/data loss/system-integrity or catastrophic release blocker.
- **P1**: critical business/security/release blocker with high materiality.
- **P2**: material reliability, performance, UX, data, or maintainability risk.
- **P3**: bounded improvement/debt with no immediate critical impact.
- **P4**: optimization, experiment, or future enhancement.

## Confidence guidance

- **HIGH**: directly reproduced or strongly corroborated by authoritative evidence.
- **MEDIUM**: credible static/indirect evidence with a remaining verification gap.
- **LOW**: hypothesis or incomplete evidence; keep as UNKNOWN/needs verification where appropriate.
