# Review UI Design System — DoR / DoD

Use this checklist as an execution gate, not as ceremonial documentation. Each item must be backed by evidence, explicitly `UNKNOWN`, or justified `NOT_APPLICABLE`.

## Definition of Ready (DoR)

**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01 — UI is inspectable.**
  - Evidence: Running app, Storybook/component explorer, screenshots, or source components are available.
- [ ] **DOR-02 — Design/token authority is identifiable.**
  - Evidence: Existing design system, CSS variables, theme config, component library, or brand guide is known.
- [ ] **DOR-03 — Target viewport/device classes are defined.**
  - Evidence: At minimum mobile/desktop or product-supported breakpoints are known.
- [ ] **DOR-04 — Critical UI surfaces are prioritized.**
  - Evidence: Review is bounded to routes/components with highest user or risk impact.
- [ ] **DOR-05 — Interaction states can be exercised or inspected.**
  - Evidence: Loading, empty, error, success, disabled, focus, hover, destructive states can be evaluated.
- [ ] **DOR-06 — Accessibility baseline is known.**
  - Evidence: WCAG target or project accessibility requirement is recorded.
- [ ] **DOR-07 — Brand constraints are explicit.**
  - Evidence: Improvements will not silently replace the visual language.
- [ ] **DOR-08 — Visual-regression capability is known.**
  - Evidence: Screenshot/baseline tooling is available or gap is recorded.

### DoR blockers

- No visual/source evidence for the UI under review.
- Requested APPLY conflicts with an explicit design/brand authority and no override exists.

## Definition of Done (DoD)

**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01 — Component inventory and ownership are mapped.**
  - Evidence/acceptance: Canonical components and duplicate/parallel implementations are identified.
- [ ] **DOD-02 — Design tokens are assessed.**
  - Evidence/acceptance: Color, typography, spacing, radii, elevation, motion, and semantic tokens are consistent or gaps recorded.
- [ ] **DOD-03 — State coverage is assessed.**
  - Evidence/acceptance: Interactive components cover required loading/error/empty/focus/disabled/destructive states.
- [ ] **DOD-04 — Responsive behavior is verified.**
  - Evidence/acceptance: Priority surfaces are checked at supported viewport classes without major clipping/overflow.
- [ ] **DOD-05 — Visual hierarchy and density are evaluated.**
  - Evidence/acceptance: Information priority and action prominence match user tasks.
- [ ] **DOD-06 — Consistency drift is documented.**
  - Evidence/acceptance: One-off styles, conflicting primitives, and divergent patterns are located.
- [ ] **DOD-07 — Accessibility-critical visual issues are captured.**
  - Evidence/acceptance: Contrast, focus visibility, touch targets, and state communication are included.
- [ ] **DOD-08 — Consolidation plan preserves existing authority.**
  - Evidence/acceptance: Recommendations extend/refactor the current system before introducing a parallel system.
- [ ] **DOD-09 — Applied UI changes have regression evidence.**
  - Evidence/acceptance: Before/after or automated visual checks exist when changes are authorized.
- [ ] **DOD-10 — No brand-breaking change is mislabeled as optimization.**
  - Evidence/acceptance: Intentional brand differences remain documented.
- [ ] **DOD-11 — Priority findings include component/route evidence.**
  - Evidence/acceptance: Findings are actionable rather than generic aesthetic opinions.
- [ ] **DOD-12 — UI gate status is issued.**
  - Evidence/acceptance: Blocking vs non-blocking design-system debt is explicit.

## Evidence and handoff requirements

- Record the exact repository commit, runtime/environment, artifact version, regulatory effective date, or evidence snapshot used as baseline.
- Link every failed or unknown criterion to the corresponding finding/evidence entry.
- Do not mark an unexecuted test/check as PASS.
- If APPLY occurred, include change provenance, rollback, and post-change verification.
- Return residual risks and next evidence needed for every `UNKNOWN` affecting a material gate.

## Machine-readable record

Use `contracts/dor-dod.schema.json` from the pack root when available. A standalone installation should preserve the same fields and status semantics.
