param(
  [ValidateSet("user","repo","admin")][string]$Scope = "user",
  [string]$Repo = ".",
  [ValidateSet("fail","skip","replace")][string]$Collision = "fail"
)
$ErrorActionPreference = "Stop"
$Script = Join-Path $PSScriptRoot "skills\install-skill-pack\scripts\install_pack.py"
python $Script --scope $Scope --repo $Repo --collision $Collision --apply
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
