#!/usr/bin/env python3
from pathlib import Path
import json,re,sys
ROOT=Path(__file__).resolve().parents[1]; errs=[]; warns=[]; skills=[]
cfg=json.load(open(ROOT/'profiles.json'))
roots=[]
for p in cfg['profiles'].values(): roots += p.get('roots',[])
roots=list(dict.fromkeys(roots))
for rel in roots:
 sr=ROOT/rel
 if not sr.exists(): errs.append(f'missing root {rel}'); continue
 for d in sorted(sr.iterdir()):
  if not d.is_dir() or not (d/'SKILL.md').exists(): continue
  key=(rel,d.name)
  if key in skills: continue
  skills.append(key); t=(d/'SKILL.md').read_text(encoding='utf-8')
  if not t.startswith('---\n'): errs.append(f'{d}: missing frontmatter')
  m=re.search(r'^name:\s*([^\n]+)',t,re.M)
  if not m or m.group(1).strip().strip('"')!=d.name: errs.append(f'{d}: name mismatch')
  dm=re.search(r'^description:\s*["\']?(.*?)["\']?$',t,re.M)
  if not dm or len(dm.group(1).strip('"\''))>1024: errs.append(f'{d}: description missing/too long')
  for req in ['references/DOR_DOD.md','references/SOURCES.md','evals/evals.json','agents/openai.yaml']:
   if not (d/req).exists(): errs.append(f'{d}: missing {req}')
for p in ROOT.rglob('*.json'):
 try: json.load(open(p,encoding='utf-8'))
 except Exception as e: errs.append(f'{p}: JSON {e}')
# Canonicality and H2A provenance
for p in list(ROOT.rglob('*.md')):
 t=p.read_text(encoding='utf-8').lower()
 for bad in ['yello solar','aneel','brazilian formatting','customer/financial/energy','pii/financial/energy']:
  if bad in t: errs.append(f'{p}: non-canonical residue {bad}')
h2a=(ROOT/'protocols/H2A_PROFILE_SPEC.md').read_text(encoding='utf-8').lower()
if 'not a google standard' not in h2a: errs.append('H2A profile must explicitly disclaim Google-standard status')
print(json.dumps({'skills':len(skills),'roots':roots,'errors':errs,'warnings':warns},indent=2)); sys.exit(1 if errs else 0)
