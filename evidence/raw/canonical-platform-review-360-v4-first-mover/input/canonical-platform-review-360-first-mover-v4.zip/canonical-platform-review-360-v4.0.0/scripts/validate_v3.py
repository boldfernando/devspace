#!/usr/bin/env python3
from pathlib import Path
import json, re, sys
ROOT=Path(__file__).resolve().parents[1]
errs=[]; warns=[]; n=0
for sr in [ROOT/'skills', ROOT/'extensions/github-intelligence/skills']:
    for d in sorted(sr.iterdir() if sr.exists() else []):
        if not d.is_dir() or not (d/'SKILL.md').exists():
            continue
        n += 1
        t=(d/'SKILL.md').read_text(encoding='utf-8')
        if not t.startswith('---\n'):
            errs.append(f'{d}: missing frontmatter')
        m=re.search(r'^name:\s*([^\n]+)', t, re.M)
        if not m or m.group(1).strip().strip('"') != d.name:
            errs.append(f'{d}: name mismatch')
        for req in ['references/DOR_DOD.md','references/SOURCES.md','evals/evals.json','agents/openai.yaml']:
            if not (d/req).exists():
                errs.append(f'{d}: missing {req}')
for p in ROOT.rglob('*.json'):
    try:
        json.load(open(p,encoding='utf-8'))
    except Exception as e:
        errs.append(f'{p}: JSON {e}')
for p in list((ROOT/'skills').rglob('*.md')) + list((ROOT/'extensions').rglob('*.md')):
    t=p.read_text(encoding='utf-8').lower()
    for bad in ['yello solar','aneel','brazilian formatting','customer/financial/energy','pii/financial/energy']:
        if bad in t:
            errs.append(f'{p}: non-canonical residue {bad}')
print(json.dumps({'skills':n,'errors':errs,'warnings':warns},indent=2))
sys.exit(1 if errs else 0)
