#!/usr/bin/env python3
from pathlib import Path
import argparse,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
def main():
 ap=argparse.ArgumentParser(description='Install bounded skill profiles to control discovery surface.')
 ap.add_argument('--profile',required=True); ap.add_argument('--scope',choices=['repo','user','admin','custom'],default='repo'); ap.add_argument('--repo',default='.'); ap.add_argument('--dest'); ap.add_argument('--collision',choices=['fail','skip','replace'],default='fail'); ap.add_argument('--apply',action='store_true'); ap.add_argument('--allow-large-discovery-surface',action='store_true'); a=ap.parse_args()
 cfg=json.load(open(ROOT/'profiles.json')); p=cfg['profiles'].get(a.profile)
 if not p: raise SystemExit(f'unknown profile {a.profile}')
 if a.profile in {'full','first-mover-fabric'} and not a.allow_large_discovery_surface: raise SystemExit(f'{a.profile} profile intentionally blocked by default; pass --allow-large-discovery-surface')
 installed=[]
 for rel in p['roots']:
  src=ROOT/rel; names=[n for n in p['skills'] if (src/n/'SKILL.md').exists()]
  if not names: continue
  cmd=[sys.executable,str(ROOT/'skills/install-skill-pack/scripts/install_pack.py'),'--source',str(src),'--scope',a.scope,'--repo',a.repo,'--collision',a.collision,'--skills',*names]
  if a.dest: cmd += ['--dest',a.dest]
  if a.apply: cmd += ['--apply']
  print('+',' '.join(cmd)); subprocess.run(cmd,check=True); installed += names
 print(json.dumps({'profile':a.profile,'skills':installed,'count':len(installed),'applied':a.apply},indent=2))
if __name__=='__main__': main()
