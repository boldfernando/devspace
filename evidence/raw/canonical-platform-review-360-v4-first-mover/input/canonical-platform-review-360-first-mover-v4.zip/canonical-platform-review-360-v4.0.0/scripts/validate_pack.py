#!/usr/bin/env python3
from pathlib import Path
import json,re,sys

root=Path(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]).resolve()
errors=[]; warnings=[]
name_re=re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")

try:
    import yaml
except Exception:
    yaml=None
    warnings.append("PyYAML unavailable: YAML files receive structural checks only")

skills_root=root/'skills'
if not skills_root.exists():
    print(json.dumps({'root':str(root),'skills':0,'errors':['missing skills/ directory'],'warnings':warnings},indent=2))
    sys.exit(1)

for d in sorted(skills_root.iterdir()):
    if not d.is_dir():
        continue
    p=d/'SKILL.md'
    if not p.exists():
        errors.append(f"{d.name}: missing SKILL.md")
        continue
    text=p.read_text(encoding='utf-8')
    m=re.match(r"^---\n(.*?)\n---\n",text,re.S)
    if not m:
        errors.append(f"{d.name}: invalid/missing YAML frontmatter")
        continue
    fm=m.group(1)
    if yaml:
        try:
            parsed=yaml.safe_load(fm)
            if not isinstance(parsed,dict):
                errors.append(f"{d.name}: frontmatter must be a YAML mapping")
                parsed={}
        except Exception as e:
            errors.append(f"{d.name}: invalid YAML frontmatter: {e}")
            parsed={}
        name=str(parsed.get('name','')).strip()
        desc=str(parsed.get('description','')).strip()
    else:
        nm=re.search(r"^name:\s*(.+)$",fm,re.M); ds=re.search(r"^description:\s*(.+)$",fm,re.M)
        name=nm.group(1).strip() if nm else ''
        desc=ds.group(1).strip() if ds else ''
        if re.search(r"^metadata:\s*$\n(?: {4,}\S)",fm,re.M):
            errors.append(f"{d.name}: suspicious metadata indentation")
    if not name: errors.append(f"{d.name}: missing name")
    if name != d.name: errors.append(f"{d.name}: name does not match directory ({name})")
    if not name_re.match(name) or len(name)>64: errors.append(f"{d.name}: invalid name")
    if not desc or len(desc)>1024: errors.append(f"{d.name}: invalid description length {len(desc)}")
    if len(text.splitlines())>500: warnings.append(f"{d.name}: SKILL.md exceeds 500-line recommendation")
    if '## Definition of Ready (DoR)' not in text: errors.append(f"{d.name}: missing Definition of Ready")
    if '## Definition of Done (DoD)' not in text: errors.append(f"{d.name}: missing Definition of Done")
    if not (d/'references'/'DOR_DOD.md').exists(): errors.append(f"{d.name}: missing references/DOR_DOD.md")
    ev=d/'evals'/'evals.json'
    if not ev.exists(): errors.append(f"{d.name}: missing evals/evals.json")
    else:
        try:
            data=json.loads(ev.read_text(encoding='utf-8'))
            if data.get('skill_name') != d.name: errors.append(f"{d.name}: eval skill_name mismatch")
            if len(data.get('evals',[]))<2: errors.append(f"{d.name}: fewer than 2 evals")
        except Exception as e: errors.append(f"{d.name}: invalid eval JSON: {e}")
    oy=d/'agents'/'openai.yaml'
    if not oy.exists():
        warnings.append(f"{d.name}: missing optional agents/openai.yaml")
    elif yaml:
        try:
            data=yaml.safe_load(oy.read_text(encoding='utf-8'))
            if not isinstance(data,dict): errors.append(f"{d.name}: agents/openai.yaml must be a mapping")
        except Exception as e: errors.append(f"{d.name}: invalid agents/openai.yaml: {e}")

for p in root.rglob('*.json'):
    if p.name=='MANIFEST.sha256.json':
        continue
    try: json.loads(p.read_text(encoding='utf-8'))
    except Exception as e: errors.append(f"{p.relative_to(root)}: invalid JSON: {e}")

required_protocols=['SKILL_AUTHORING_PROTOCOL.md','AGENT_AUTHORING_PROTOCOL.md','DOR_DOD_PROTOCOL.md','CANONICAL_TEMPLATE_PROTOCOL.md','SKILL_SYSTEM_LIFECYCLE_PROTOCOL.md']
for name in required_protocols:
    if not (root/'protocols'/name).exists(): errors.append(f"protocols/{name}: missing")

# Canonical-template structural guard.
if not (skills_root/'review-domain-rules-compliance'/'SKILL.md').exists():
    errors.append('canonical domain rules/compliance specialist is missing')

print(json.dumps({'root':str(root),'skills':len([d for d in skills_root.iterdir() if d.is_dir()]),'errors':errors,'warnings':warnings},indent=2))
sys.exit(1 if errors else 0)
