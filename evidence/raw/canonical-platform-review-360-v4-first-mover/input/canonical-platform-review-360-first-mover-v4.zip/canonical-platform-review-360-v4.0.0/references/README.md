# Canonical Source Registry

References are classified by authority. Normative standards, official vendor docs, project sources of truth, regulatory primary sources, tool docs and secondary guidance are not interchangeable. Load provider/framework adapters only after discovery establishes applicability.
