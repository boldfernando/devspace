# Domain rubric

Reduce context rot/cost while preserving decision-critical evidence.

## Core checks

- Do not truncate authority/safety constraints
- Prefer references over duplicating large artifacts
- Keep provenance for summaries
- Classify required context
- Deduplicate and summarize non-critical history
- Mount task-specific skills/references
- Measure token/context efficiency