---
name: optimize-context-budget
description: "Optimize what context each agent receives using task-local evidence, summaries, artifact references and progressive disclosure."
metadata:
  version: "4.0.0"
  order: "I02"
  family: adaptive-intelligence
---

# Optimize Context Budget

## Objective

Reduce context rot/cost while preserving decision-critical evidence.

## Operating rules

- Do not truncate authority/safety constraints
- Prefer references over duplicating large artifacts
- Keep provenance for summaries

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Classify required context
2. Deduplicate and summarize non-critical history
3. Mount task-specific skills/references
4. Measure token/context efficiency

## Preferred tools

- router.py
- Eval runners/graders
- Trace/evidence store
- Host model registry when available

## Outputs

- `context-plan.json`
- `context-efficiency.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
