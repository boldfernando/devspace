---
name: route-task-by-capability
description: "Select the best eligible agent/model/tool profile for a task using capability fit, verified history, risk, latency, cost and conflict pressure."
metadata:
  version: "4.0.0"
  order: "I00"
  family: adaptive-intelligence
---

# Route Task by Capability

## Objective

Turn routing into an inspectable decision instead of arbitrary model choice.

## Operating rules

- Hard safety/authority constraints precede optimization
- Historical success must be verification-based
- Always retain fallback candidates

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Classify task requirements/risk
2. Filter ineligible candidates
3. Score capability/quality/cost/latency
4. Select primary + fallbacks and record reasons

## Preferred tools

- router.py
- Eval runners/graders
- Trace/evidence store
- Host model registry when available

## Outputs

- `adaptive-routing-decision.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
