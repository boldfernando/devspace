# Domain rubric

Turn routing into an inspectable decision instead of arbitrary model choice.

## Core checks

- Hard safety/authority constraints precede optimization
- Historical success must be verification-based
- Always retain fallback candidates
- Classify task requirements/risk
- Filter ineligible candidates
- Score capability/quality/cost/latency
- Select primary + fallbacks and record reasons