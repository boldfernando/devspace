---
name: calibrate-agent-confidence
description: "Calibrate confidence against evidence completeness, verifier outcomes and historical error rather than model self-report alone."
metadata:
  version: "4.0.0"
  order: "I01"
  family: adaptive-intelligence
---

# Calibrate Agent Confidence

## Objective

Prevent confident language from becoming a release signal.

## Operating rules

- Self-reported confidence is weak evidence
- UNKNOWN survives insufficient evidence
- Confidence thresholds vary by risk class

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Collect evidence/verifier features
2. Compare claimed vs observed outcomes
3. Calibrate score/band
4. Route low confidence to more evidence or human gate

## Preferred tools

- router.py
- Eval runners/graders
- Trace/evidence store
- Host model registry when available

## Outputs

- `confidence-calibration.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
