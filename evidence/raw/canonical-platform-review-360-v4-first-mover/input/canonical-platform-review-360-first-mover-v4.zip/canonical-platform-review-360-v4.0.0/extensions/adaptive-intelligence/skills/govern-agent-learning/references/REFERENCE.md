# Domain rubric

Allow adaptive improvement without silent self-modification.

## Core checks

- No autonomous production self-rewrite
- Every promoted change is versioned/reversible
- Require evidence of improvement and no critical regression
- Collect candidate improvement
- Run relevant eval suite
- Assess regression/risk/cost
- Request approval if required
- Version/promote or reject with evidence