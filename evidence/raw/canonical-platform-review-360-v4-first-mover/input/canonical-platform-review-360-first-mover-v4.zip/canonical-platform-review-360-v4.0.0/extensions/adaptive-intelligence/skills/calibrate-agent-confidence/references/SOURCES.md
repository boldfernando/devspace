# Sources

- protocols/ADAPTIVE_INTELLIGENCE_PROTOCOL.md
- https://developers.openai.com/api/docs/guides/agent-evals
- https://developers.googleblog.com/build-long-running-ai-agents-that-pause-resume-and-never-lose-context-with-adk/
- https://google.github.io/agents-cli/guide/use-cases/