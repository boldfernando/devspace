---
name: evolve-agent-evals
description: "Turn production failures, human corrections, routing mistakes and regressions into versioned eval candidates and replayable fixtures."
metadata:
  version: "4.0.0"
  order: "I03"
  family: adaptive-intelligence
---

# Evolve Agent Evals

## Objective

Make system quality improve from evidence rather than anecdotal prompt edits.

## Operating rules

- Failed runs become fixtures, not hidden noise
- Eval promotion requires review
- Separate training/learning proposals from production policy

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Mine failure/correction events
2. Generate minimal reproducible eval case
3. Add grader/assertions
4. Run baseline vs candidate
5. Propose promotion when statistically/qualitatively justified

## Preferred tools

- router.py
- Eval runners/graders
- Trace/evidence store
- Host model registry when available

## Outputs

- `eval-candidates.json`
- `eval-comparison.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
