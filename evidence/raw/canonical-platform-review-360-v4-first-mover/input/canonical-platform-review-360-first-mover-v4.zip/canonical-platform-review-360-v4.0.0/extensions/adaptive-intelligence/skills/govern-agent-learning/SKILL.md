---
name: govern-agent-learning
description: "Govern promotion of learned patterns, prompts, skills, routing policies and reference updates through evidence, evals and approval."
metadata:
  version: "4.0.0"
  order: "I04"
  family: adaptive-intelligence
---

# Govern Agent Learning

## Objective

Allow adaptive improvement without silent self-modification.

## Operating rules

- No autonomous production self-rewrite
- Every promoted change is versioned/reversible
- Require evidence of improvement and no critical regression

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Collect candidate improvement
2. Run relevant eval suite
3. Assess regression/risk/cost
4. Request approval if required
5. Version/promote or reject with evidence

## Preferred tools

- router.py
- Eval runners/graders
- Trace/evidence store
- Host model registry when available

## Outputs

- `learning-proposal.json`
- `learning-decision.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
