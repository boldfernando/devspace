#!/usr/bin/env python3
"""Deterministic candidate router. Inputs are JSON task + JSON candidates; policy is inspectable."""
import argparse,json
from pathlib import Path
RISK={'LOW':0,'MEDIUM':1,'HIGH':2,'CRITICAL':3}
def score(task,c):
 s=0; reasons=[]
 req=set(task.get('skills',[])); have=set(c.get('skills',[])); fit=len(req & have)/(len(req) or 1); s+=fit*50; reasons.append(f'skill_fit={fit:.2f}')
 if c.get('available',True): s+=10
 vr=float(c.get('verified_success_rate',0.5)); s+=vr*25; reasons.append(f'verified_success_rate={vr:.2f}')
 if RISK.get(task.get('risk_class','MEDIUM'),1)>RISK.get(c.get('risk_ceiling','MEDIUM'),1): s-=100; reasons.append('risk_ceiling_exceeded')
 cost=float(c.get('relative_cost',1.0)); s-=min(cost,10)*2
 latency=float(c.get('relative_latency',1.0)); s-=min(latency,10)
 return s,reasons
def main():
 p=argparse.ArgumentParser(); p.add_argument('task');p.add_argument('candidates');a=p.parse_args();t=json.loads(Path(a.task).read_text()); cs=json.loads(Path(a.candidates).read_text())
 ranked=[]
 for c in cs:
  s,r=score(t,c); ranked.append({'candidate':c['id'],'score':round(s,3),'reasons':r})
 ranked.sort(key=lambda x:(-x['score'],x['candidate'])); print(json.dumps({'task_id':t['task_id'],'ranked':ranked,'selected':ranked[0]['candidate'] if ranked else None},indent=2))
if __name__=='__main__':main()
