# Domain rubric

Prevent confident language from becoming a release signal.

## Core checks

- Self-reported confidence is weak evidence
- UNKNOWN survives insufficient evidence
- Confidence thresholds vary by risk class
- Collect evidence/verifier features
- Compare claimed vs observed outcomes
- Calibrate score/band
- Route low confidence to more evidence or human gate