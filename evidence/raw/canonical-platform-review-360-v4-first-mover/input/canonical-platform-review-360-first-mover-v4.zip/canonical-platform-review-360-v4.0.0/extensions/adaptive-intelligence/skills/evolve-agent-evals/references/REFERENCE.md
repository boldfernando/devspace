# Domain rubric

Make system quality improve from evidence rather than anecdotal prompt edits.

## Core checks

- Failed runs become fixtures, not hidden noise
- Eval promotion requires review
- Separate training/learning proposals from production policy
- Mine failure/correction events
- Generate minimal reproducible eval case
- Add grader/assertions
- Run baseline vs candidate
- Propose promotion when statistically/qualitatively justified