# Definition of Ready / Definition of Done

## DoR

- [ ] Scope, authority, identifiers and dependency state are explicit.
- [ ] Required resources are available or safely classed UNKNOWN.
- [ ] Side-effect policy is known before execution.
- [ ] Concurrency/ownership constraints are evaluable.

## DoD

- [ ] Result is linked to task, agent, trace and evidence.
- [ ] Verification ran for material claims.
- [ ] Conflicts, failures and residual risks are recorded.
- [ ] Downstream gate can decide without reconstructing hidden context.
