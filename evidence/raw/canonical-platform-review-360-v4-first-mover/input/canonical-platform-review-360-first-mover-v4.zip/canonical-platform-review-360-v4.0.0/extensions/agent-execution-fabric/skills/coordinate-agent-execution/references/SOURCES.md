# Sources

- https://opentelemetry.io/docs/specs/semconv/
- https://git-scm.com/docs/git-worktree
- https://docs.github.com/en/issues/tracking-your-work-with-issues/using-issues/browsing-sub-issues