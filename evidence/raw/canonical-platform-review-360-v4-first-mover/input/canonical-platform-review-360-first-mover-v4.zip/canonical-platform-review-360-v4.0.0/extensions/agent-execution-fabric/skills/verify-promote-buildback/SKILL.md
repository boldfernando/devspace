---
name: verify-promote-buildback
description: "Independently verify a buildback and authorize promotion, rollback or replan. Use at final change gates."
metadata:
  version: "4.0.0"
  order: "E04"
  family: agent-execution-fabric
---

# Verify & Promote Buildback

## Objective

Separate builder authority from release authority and require evidence graph completion.

## Operating rules

- Builder cannot self-certify release
- Promotion requires expected baseline/integration lineage
- Failed verification cannot be averaged away
- Rollback/replan is a valid outcome

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Re-run required verification
2. Check evidence completeness and residual risks
3. Evaluate release policy
4. Promote, rollback, block or request replan

## Preferred tools

- fabricctl.py
- Git worktrees or equivalent isolated workspaces
- Host-native subagent runtime
- Project-native verification tools

## Outputs

- `buildback-verification.json`
- `promotion-decision.json`
- `release-evidence.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
