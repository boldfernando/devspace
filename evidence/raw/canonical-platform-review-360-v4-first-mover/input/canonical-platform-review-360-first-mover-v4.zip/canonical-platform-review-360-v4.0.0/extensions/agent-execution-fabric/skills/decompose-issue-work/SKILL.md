---
name: decompose-issue-work
description: "Decompose issues/sub-issues into dependency-aware tasks with declared resource claims. Use before parallel agent execution."
metadata:
  version: "4.0.0"
  order: "E01"
  family: agent-execution-fabric
---

# Decompose Issue Work

## Objective

Turn issue intent into schedulable tasks with dependencies, read/write/semantic claims, DoR/DoD and verifier expectations.

## Operating rules

- Keep tasks independently verifiable
- Declare semantic resources even when files differ
- Use UNKNOWN for hidden dependencies
- Do not make every micro-step a GitHub issue

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Read issue/sub-issue/dependency context
2. Generate bounded tasks
3. Declare dependencies and resource claims
4. Validate acyclic graph and acceptance criteria

## Preferred tools

- fabricctl.py
- Git worktrees or equivalent isolated workspaces
- Host-native subagent runtime
- Project-native verification tools

## Outputs

- `tasks.json`
- `task-dag.json`
- `resource-conflict-graph.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
