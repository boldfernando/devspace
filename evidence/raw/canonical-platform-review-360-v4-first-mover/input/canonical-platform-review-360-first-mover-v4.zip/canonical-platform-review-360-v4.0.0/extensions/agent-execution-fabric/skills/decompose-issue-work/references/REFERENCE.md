# Domain rubric

Turn issue intent into schedulable tasks with dependencies, read/write/semantic claims, DoR/DoD and verifier expectations.

## Core checks

- Keep tasks independently verifiable
- Declare semantic resources even when files differ
- Use UNKNOWN for hidden dependencies
- Do not make every micro-step a GitHub issue
- Read issue/sub-issue/dependency context
- Generate bounded tasks
- Declare dependencies and resource claims
- Validate acyclic graph and acceptance criteria