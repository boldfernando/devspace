---
name: reconcile-buildback
description: "Reconcile patches, artifacts and task results into an integration candidate while detecting stale bases and semantic conflicts."
metadata:
  version: "4.0.0"
  order: "E03"
  family: agent-execution-fabric
---

# Reconcile Buildback

## Objective

Produce an integration candidate without allowing workers to merge directly into the target branch.

## Operating rules

- Check base SHA freshness
- Require completed task DoD before integration
- Run cross-task conflict analysis
- Keep conflict resolution separately reviewable

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Collect verified task outputs
2. Check patch/workspace lineage
3. Detect file and semantic conflicts
4. Integrate into buildback branch/queue
5. Run cross-task regression plan

## Preferred tools

- fabricctl.py
- Git worktrees or equivalent isolated workspaces
- Host-native subagent runtime
- Project-native verification tools

## Outputs

- `merge-plan.json`
- `integration-candidate.json`
- `conflict-report.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
