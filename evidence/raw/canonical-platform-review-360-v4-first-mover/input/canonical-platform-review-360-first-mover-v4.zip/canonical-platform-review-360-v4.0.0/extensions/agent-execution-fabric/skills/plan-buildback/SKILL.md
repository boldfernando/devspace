---
name: plan-buildback
description: "Plan a transaction-scoped buildback from immutable baseline through verified promotion. Use when an issue/change set must be executed by multiple agents without losing lineage."
metadata:
  version: "4.0.0"
  order: "E00"
  family: agent-execution-fabric
---

# Plan Buildback

## Objective

Create the buildback envelope, baseline, target, issue graph, policy, risk and rollback boundaries.

## Operating rules

- Pin baseline SHA before mutation
- Model buildback as transaction envelope, not chat history
- Separate issue graph, task DAG, resource conflicts and approval graph
- Do not grant workers promotion authority

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Load mission/issues and immutable baseline
2. Derive buildback scope and states
3. Define integration target, rollback and verification policy
4. Emit buildback + work graph

## Preferred tools

- fabricctl.py
- Git worktrees or equivalent isolated workspaces
- Host-native subagent runtime
- Project-native verification tools

## Outputs

- `buildback.json`
- `work-graph.json`
- `gate-plan.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
