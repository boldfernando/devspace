# Domain rubric

Run the deterministic traffic-control layer around specialist agents.

## Core checks

- No mutable task without agent address
- No write without lease
- Writes use isolated worktree/transactional workspace
- Lease ownership has TTL/heartbeat
- Parallelism is limited by conflict-free width, budget and host capacity
- Compute ready tasks and conflict-free waves
- Assign addressed agent instances
- Acquire leases and create workspaces
- Monitor heartbeat/events and reschedule safely
- Release resources on terminal state