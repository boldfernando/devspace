#!/usr/bin/env python3
"""Reference deterministic planner/address/lease/event helper. Stdlib only."""
from __future__ import annotations
import argparse, json, uuid, time
from pathlib import Path
from datetime import datetime, timezone, timedelta

def load(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def dump(x): print(json.dumps(x,indent=2,ensure_ascii=False))
def conflict(a,b):
    # same resource + at least one mutation-like mode
    mutate={'write','semantic-write','environment','migration','contract'}
    for x in a.get('claims',[]):
      for y in b.get('claims',[]):
        if x['resource']==y['resource'] and (x['mode'] in mutate or y['mode'] in mutate): return True
    return False

def waves(doc):
    tasks={t['task_id']:t for t in doc['tasks']}; done=set(); result=[]
    while len(done)<len(tasks):
      ready=[t for t in tasks.values() if t['task_id'] not in done and set(t.get('dependencies',[]))<=done]
      if not ready: raise SystemExit('cycle or unresolved dependency')
      wave=[]
      for t in sorted(ready,key=lambda x:x['task_id']):
        if all(not conflict(t,w) for w in wave): wave.append(t)
      result.append([t['task_id'] for t in wave]); done.update(t['task_id'] for t in wave)
    return result

def address(a):
    parts=[a.repo,a.buildback,a.issue,a.task,a.role,str(a.attempt)]
    safe=[str(x).strip('/').replace(' ','-') for x in parts]
    return 'agent://'+'/'.join(safe)

def leases_path(p): return Path(p)
def read_state(p):
    q=leases_path(p)
    if not q.exists(): return {'leases':[]}
    return json.loads(q.read_text())
def save_state(p,s): leases_path(p).write_text(json.dumps(s,indent=2)+"\n")
def prune(s):
    now=datetime.now(timezone.utc)
    s['leases']=[l for l in s['leases'] if datetime.fromisoformat(l['expires_at'])>now]
def cmd_lease(a):
    s=read_state(a.state); prune(s)
    if a.action=='list': dump(s); return
    if a.action=='acquire':
      incoming={'resource':a.resource,'mode':a.mode}
      mutate={'EXCLUSIVE_WRITE','SEMANTIC_WRITE','ENVIRONMENT_LOCK','MIGRATION_LOCK','CONTRACT_LOCK'}
      for l in s['leases']:
        if l['resource']==a.resource and (a.mode in mutate or l['mode'] in mutate):
          raise SystemExit(f'conflict: {a.resource} owned by {l["owner"]}')
      now=datetime.now(timezone.utc); exp=now+timedelta(seconds=a.ttl)
      l={'lease_id':'lease_'+uuid.uuid4().hex[:16],'resource':a.resource,'mode':a.mode,'owner':a.owner,'acquired_at':now.isoformat(),'heartbeat_at':now.isoformat(),'expires_at':exp.isoformat()}
      s['leases'].append(l); save_state(a.state,s); dump(l); return
    match=[l for l in s['leases'] if l['lease_id']==a.lease_id]
    if not match: raise SystemExit('lease not found')
    l=match[0]
    if a.action=='heartbeat':
      now=datetime.now(timezone.utc); l['heartbeat_at']=now.isoformat(); l['expires_at']=(now+timedelta(seconds=a.ttl)).isoformat()
    elif a.action=='release': s['leases']=[x for x in s['leases'] if x['lease_id']!=a.lease_id]
    save_state(a.state,s); dump(s)

def cmd_event(a):
    e={'event_id':'evt_'+uuid.uuid4().hex[:16],'event_type':a.type,'timestamp':datetime.now(timezone.utc).isoformat(),'mission_id':a.mission,'buildback_id':a.buildback,'issue_id':a.issue,'task_id':a.task,'agent_address':a.agent,'trace_id':a.trace,'payload':json.loads(a.payload or '{}')}
    p=Path(a.journal); p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('a',encoding='utf-8') as f:f.write(json.dumps(e,ensure_ascii=False)+'\n')
    dump(e)

def main():
 p=argparse.ArgumentParser(); sp=p.add_subparsers(dest='cmd',required=True)
 q=sp.add_parser('plan'); q.add_argument('graph')
 q=sp.add_parser('address');
 for x in ['repo','buildback','issue','task','role']: q.add_argument('--'+x,required=True)
 q.add_argument('--attempt',type=int,default=1)
 q=sp.add_parser('lease'); q.add_argument('action',choices=['acquire','heartbeat','release','list']); q.add_argument('--state',default='.agent-fabric-leases.json'); q.add_argument('--resource'); q.add_argument('--mode',default='EXCLUSIVE_WRITE'); q.add_argument('--owner'); q.add_argument('--lease-id'); q.add_argument('--ttl',type=int,default=120)
 q=sp.add_parser('event'); q.add_argument('--journal',default='.agent-fabric-events.jsonl'); q.add_argument('--type',required=True); q.add_argument('--mission'); q.add_argument('--buildback',required=True); q.add_argument('--issue'); q.add_argument('--task'); q.add_argument('--agent'); q.add_argument('--trace'); q.add_argument('--payload')
 a=p.parse_args()
 if a.cmd=='plan': dump({'waves':waves(load(a.graph))})
 elif a.cmd=='address': print(address(a))
 elif a.cmd=='lease': cmd_lease(a)
 elif a.cmd=='event': cmd_event(a)
if __name__=='__main__':main()
