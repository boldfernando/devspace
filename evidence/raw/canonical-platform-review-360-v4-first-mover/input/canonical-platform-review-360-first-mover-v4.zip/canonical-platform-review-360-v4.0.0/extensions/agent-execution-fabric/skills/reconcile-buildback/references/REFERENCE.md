# Domain rubric

Produce an integration candidate without allowing workers to merge directly into the target branch.

## Core checks

- Check base SHA freshness
- Require completed task DoD before integration
- Run cross-task conflict analysis
- Keep conflict resolution separately reviewable
- Collect verified task outputs
- Check patch/workspace lineage
- Detect file and semantic conflicts
- Integrate into buildback branch/queue
- Run cross-task regression plan