# Domain rubric

Separate builder authority from release authority and require evidence graph completion.

## Core checks

- Builder cannot self-certify release
- Promotion requires expected baseline/integration lineage
- Failed verification cannot be averaged away
- Rollback/replan is a valid outcome
- Re-run required verification
- Check evidence completeness and residual risks
- Evaluate release policy
- Promote, rollback, block or request replan