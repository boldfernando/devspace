---
name: coordinate-agent-execution
description: "Coordinate addressed subagents with leases, isolated workspaces, heartbeats and conflict-aware scheduling. Use for concurrent execution."
metadata:
  version: "4.0.0"
  order: "E02"
  family: agent-execution-fabric
---

# Coordinate Agent Execution

## Objective

Run the deterministic traffic-control layer around specialist agents.

## Operating rules

- No mutable task without agent address
- No write without lease
- Writes use isolated worktree/transactional workspace
- Lease ownership has TTL/heartbeat
- Parallelism is limited by conflict-free width, budget and host capacity

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Compute ready tasks and conflict-free waves
2. Assign addressed agent instances
3. Acquire leases and create workspaces
4. Monitor heartbeat/events and reschedule safely
5. Release resources on terminal state

## Preferred tools

- fabricctl.py
- Git worktrees or equivalent isolated workspaces
- Host-native subagent runtime
- Project-native verification tools

## Outputs

- `execution-topology.json`
- `agent-directory.json`
- `lease-table.json`
- `event-journal.jsonl`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
