# Domain rubric

Create the buildback envelope, baseline, target, issue graph, policy, risk and rollback boundaries.

## Core checks

- Pin baseline SHA before mutation
- Model buildback as transaction envelope, not chat history
- Separate issue graph, task DAG, resource conflicts and approval graph
- Do not grant workers promotion authority
- Load mission/issues and immutable baseline
- Derive buildback scope and states
- Define integration target, rollback and verification policy
- Emit buildback + work graph