---
name: present-human-gate
description: "Present H2A approval/elicitation/acceptance gates as structured, least-ambiguity interfaces using A2UI/AG-UI where available."
metadata:
  version: "4.0.0"
  order: "U02"
  family: agent-ui-interop
---

# Present Human Gate

## Objective

Reduce human approval errors by presenting exact action, evidence, diff, scope and consequences.

## Operating rules

- Default-deny destructive choices
- Display authority scope and expiry
- Do not hide residual risk behind friendly copy

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Load H2A gate payload
2. Select safe UI template/components
3. Render decision controls
4. Return signed/host-confirmed decision event

## Preferred tools

- A2UI renderer/client catalog
- AG-UI SDK/connector
- Accessibility and browser test tooling

## Outputs

- `human-gate-view.json`
- `human-decision-event.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
