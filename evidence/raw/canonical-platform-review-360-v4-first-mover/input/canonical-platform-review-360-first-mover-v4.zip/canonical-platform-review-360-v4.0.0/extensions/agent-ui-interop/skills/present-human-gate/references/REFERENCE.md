# Domain rubric

Reduce human approval errors by presenting exact action, evidence, diff, scope and consequences.

## Core checks

- Default-deny destructive choices
- Display authority scope and expiry
- Do not hide residual risk behind friendly copy
- Load H2A gate payload
- Select safe UI template/components
- Render decision controls
- Return signed/host-confirmed decision event