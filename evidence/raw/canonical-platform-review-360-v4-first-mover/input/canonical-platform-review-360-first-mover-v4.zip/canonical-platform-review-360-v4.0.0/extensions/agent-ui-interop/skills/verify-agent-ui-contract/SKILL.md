---
name: verify-agent-ui-contract
description: "Verify A2UI/AG-UI payload, event ordering, state recovery, accessibility and trust-boundary behavior."
metadata:
  version: "4.0.0"
  order: "U03"
  family: agent-ui-interop
---

# Verify Agent UI Contract

## Objective

Prove agent UI interoperability without conflating pretty rendering with correctness.

## Operating rules

- Test malformed/out-of-order payloads
- Verify component allowlist behavior
- Verify approval actions bind to correct task

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Run schema/event fixtures
2. Test recovery and incremental update
3. Test human-gate correlation
4. Emit interoperability grade

## Preferred tools

- A2UI renderer/client catalog
- AG-UI SDK/connector
- Accessibility and browser test tooling

## Outputs

- `agent-ui-verification.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
