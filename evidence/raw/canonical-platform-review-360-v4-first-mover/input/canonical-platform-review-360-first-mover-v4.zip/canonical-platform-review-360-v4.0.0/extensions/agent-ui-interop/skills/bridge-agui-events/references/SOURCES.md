# Sources

- https://developers.googleblog.com/en/a2ui-v0-9-generative-ui/
- https://github.com/ag-ui-protocol/ag-ui/
- https://developers.googleblog.com/en/a2ui-and-mcp-apps/