---
name: render-a2ui-interface
description: "Render safe declarative agent-generated UI through an approved client component catalog."
metadata:
  version: "4.0.0"
  order: "U00"
  family: agent-ui-interop
---

# Render A2UI Interface

## Objective

Use A2UI as UI intent, keeping execution and styling/security control on the client.

## Operating rules

- Never treat agent-generated arbitrary code as A2UI
- Client catalog controls allowed components
- Validate payload/version before rendering

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Select approved component catalog
2. Map agent intent/data to A2UI
3. Stream/update declaratively
4. Capture render/interaction evidence

## Preferred tools

- A2UI renderer/client catalog
- AG-UI SDK/connector
- Accessibility and browser test tooling

## Outputs

- `a2ui-view.json`
- `ui-evidence.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
