# Domain rubric

Provide observable bidirectional interaction without coupling core execution to a frontend framework.

## Core checks

- Preserve run/thread lineage
- Handle out-of-order/delta recovery defensively
- Keep raw/custom events namespaced
- Map canonical run/task events
- Stream lifecycle/state/tool events
- Synchronize snapshots/deltas
- Correlate user actions back to task/trace