---
name: bridge-agui-events
description: "Bridge agent lifecycle, text, tool, state and activity events to user-facing applications using AG-UI-compatible semantics."
metadata:
  version: "4.0.0"
  order: "U01"
  family: agent-ui-interop
---

# Bridge AG-UI Events

## Objective

Provide observable bidirectional interaction without coupling core execution to a frontend framework.

## Operating rules

- Preserve run/thread lineage
- Handle out-of-order/delta recovery defensively
- Keep raw/custom events namespaced

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Map canonical run/task events
2. Stream lifecycle/state/tool events
3. Synchronize snapshots/deltas
4. Correlate user actions back to task/trace

## Preferred tools

- A2UI renderer/client catalog
- AG-UI SDK/connector
- Accessibility and browser test tooling

## Outputs

- `agui-event-map.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
