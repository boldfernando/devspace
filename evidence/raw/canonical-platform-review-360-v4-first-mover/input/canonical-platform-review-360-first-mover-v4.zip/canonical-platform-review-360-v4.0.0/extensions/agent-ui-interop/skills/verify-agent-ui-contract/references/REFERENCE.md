# Domain rubric

Prove agent UI interoperability without conflating pretty rendering with correctness.

## Core checks

- Test malformed/out-of-order payloads
- Verify component allowlist behavior
- Verify approval actions bind to correct task
- Run schema/event fixtures
- Test recovery and incremental update
- Test human-gate correlation
- Emit interoperability grade