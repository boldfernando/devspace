# Domain rubric

Use A2UI as UI intent, keeping execution and styling/security control on the client.

## Core checks

- Never treat agent-generated arbitrary code as A2UI
- Client catalog controls allowed components
- Validate payload/version before rendering
- Select approved component catalog
- Map agent intent/data to A2UI
- Stream/update declaratively
- Capture render/interaction evidence