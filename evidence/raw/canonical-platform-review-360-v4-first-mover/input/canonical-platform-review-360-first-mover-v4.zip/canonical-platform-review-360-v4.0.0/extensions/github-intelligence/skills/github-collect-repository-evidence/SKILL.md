---
name: github-collect-repository-evidence
description: "Collect reproducible, read-oriented repository evidence: default branch, exact commit SHA, refs, tree, high-value files, workflows, issues/PR metadata, dependency/SBOM and attestation signals when available. Pin every material claim to a baseline."
metadata:
  version: "3.0.0"
  order: "G02"
  family: github-intelligence-360
---

# Collect GitHub Repository Evidence

## Objective

Collect reproducible, read-oriented repository evidence: default branch, exact commit SHA, refs, tree, high-value files, workflows, issues/PR metadata, dependency/SBOM and attestation signals when available. Pin every material claim to a baseline.

## Operating rules

- Default to `READ_ONLY`.
- Evidence before inference.
- Pin material repository claims to an immutable commit SHA when repository evidence is collected.
- `Trending`, stars, forks, README quality, scanner presence, or CI presence are discovery signals, not assurance.
- `TOOL PRESENT != TOOL EXECUTED ON TARGET SHA != CLEAN RESULT != RISK ACCEPTED`.
- Preserve `UNKNOWN` when required evidence is unavailable.
- Record `Source → Version → Hash → Provenance` for material artifacts.
- Never mutate remote repositories, issues, PRs, releases, Actions, secrets or settings unless separately authorized.

## Definition of Ready (DoR)

- [ ] Repository identity is known
- [ ] Read access is authorized
- [ ] Collector identity/version is recordable
- [ ] Target branch/SHA policy is defined
- [ ] Rate-limit/batch policy is bounded

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Exact target SHA is captured or UNKNOWN reason recorded
- [ ] Tree/refs/high-value files are inventoried
- [ ] Issues/PR/workflow evidence is bounded and timestamped
- [ ] SBOM/attestation availability is recorded
- [ ] Artifacts are hashed
- [ ] Collector failures are UNKNOWN, never PASS
- [ ] No GitHub mutation APIs were invoked


## Workflow

1. Establish scope, authorization, temporal baseline and source policy.
2. Collect only the evidence required for the current evidence level.
3. Normalize outputs using the pack contracts when available.
4. Separate observation, inference, recommendation, mutation and verification.
5. Return findings, artifacts/hashes, UNKNOWNs, residual risks and the next gate.

## Preferred tools

- Git / GitHub CLI / GitHub REST or GraphQL APIs
- Filesystem and structured parsers
- Project-native build/test tools after repository discovery
- SAST/SCA/secrets/IaC scanners only when authorized, versioned and applicable
- OpenTelemetry or equivalent runtime evidence only when runtime access exists

## Outputs

Use repository-evidence, source-provenance, canonical-pattern and existing finding/evidence contracts when available.

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
