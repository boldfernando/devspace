# Sources

Use current primary/official sources and record retrieval date/version when material:

- GitHub CLI `gh api`: https://cli.github.com/manual/gh_api
- GitHub CLI skills lifecycle: https://cli.github.com/manual/gh_skill_install ; https://cli.github.com/manual/gh_skill_preview ; https://cli.github.com/manual/gh_skill_search ; https://cli.github.com/manual/gh_skill_update
- GitHub dependency graph SBOM: https://docs.github.com/en/rest/dependency-graph/sboms
- GitHub artifact attestations: https://docs.github.com/en/actions/how-tos/secure-your-work/use-artifact-attestations/use-artifact-attestations
- Agent Skills Specification: https://agentskills.io/specification
- OpenTelemetry: https://opentelemetry.io/docs/
- SLSA 1.2: https://slsa.dev/spec/v1.2/
- CycloneDX 1.7: https://cyclonedx.org/docs/1.7/json/

GitHub-specific references are adapters. They do not replace vendor-neutral contracts.
