# Canonical GitHub Intelligence 360 Extension

Version 3.0.0. Optional GitHub-specific extension kept outside the core `skills/` discovery root. Install deliberately via `scripts/install_profile.py --profile github-intelligence`.

`Seed → Universe → SHA Evidence → Engineering Patterns → Provenance → Adopt/Adapt/Avoid → Draft Skill`
