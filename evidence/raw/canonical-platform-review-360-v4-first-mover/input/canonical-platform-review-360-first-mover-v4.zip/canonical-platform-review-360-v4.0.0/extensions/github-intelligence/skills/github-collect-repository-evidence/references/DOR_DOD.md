# Collect GitHub Repository Evidence — DoR / DoD

## Definition of Ready
**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01** — Repository identity is known
- [ ] **DOR-02** — Read access is authorized
- [ ] **DOR-03** — Collector identity/version is recordable
- [ ] **DOR-04** — Target branch/SHA policy is defined
- [ ] **DOR-05** — Rate-limit/batch policy is bounded

## Definition of Done
**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01** — Exact target SHA is captured or UNKNOWN reason recorded
- [ ] **DOD-02** — Tree/refs/high-value files are inventoried
- [ ] **DOD-03** — Issues/PR/workflow evidence is bounded and timestamped
- [ ] **DOD-04** — SBOM/attestation availability is recorded
- [ ] **DOD-05** — Artifacts are hashed
- [ ] **DOD-06** — Collector failures are UNKNOWN, never PASS
- [ ] **DOD-07** — No GitHub mutation APIs were invoked

## Evidence rule
Every PASS/DONE claim links to captured evidence; missing evidence remains UNKNOWN/PARTIAL.
