---
name: github-discover-repository-universe
description: "Turn HTML snapshots, catalogs, GitHub search/API results, organization listings, topics, Trending pages, developer signals, and explicit repository lists into a deduplicated repository universe with source provenance. Discovery evidence is not a quality score."
metadata:
  version: "3.0.0"
  order: "G01"
  family: github-intelligence-360
---

# Discover GitHub Repository Universe

## Objective

Turn HTML snapshots, catalogs, GitHub search/API results, organization listings, topics, Trending pages, developer signals, and explicit repository lists into a deduplicated repository universe with source provenance. Discovery evidence is not a quality score.

## Operating rules

- Default to `READ_ONLY`.
- Evidence before inference.
- Pin material repository claims to an immutable commit SHA when repository evidence is collected.
- `Trending`, stars, forks, README quality, scanner presence, or CI presence are discovery signals, not assurance.
- `TOOL PRESENT != TOOL EXECUTED ON TARGET SHA != CLEAN RESULT != RISK ACCEPTED`.
- Preserve `UNKNOWN` when required evidence is unavailable.
- Record `Source → Version → Hash → Provenance` for material artifacts.
- Never mutate remote repositories, issues, PRs, releases, Actions, secrets or settings unless separately authorized.

## Definition of Ready (DoR)

- [ ] At least one seed/source is readable
- [ ] Capture timestamp/source identity can be recorded
- [ ] Repository identity normalization rules are defined
- [ ] Private sources are authorized before use

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] owner/repo identities are deduplicated
- [ ] Each repository retains source pointers and capture context
- [ ] Temporal windows/languages/topics are preserved when known
- [ ] Invalid/non-repository URLs are excluded
- [ ] Freshness limitations are explicit
- [ ] Machine-readable repository inventory is emitted


## Workflow

1. Establish scope, authorization, temporal baseline and source policy.
2. Collect only the evidence required for the current evidence level.
3. Normalize outputs using the pack contracts when available.
4. Separate observation, inference, recommendation, mutation and verification.
5. Return findings, artifacts/hashes, UNKNOWNs, residual risks and the next gate.

## Preferred tools

- Git / GitHub CLI / GitHub REST or GraphQL APIs
- Filesystem and structured parsers
- Project-native build/test tools after repository discovery
- SAST/SCA/secrets/IaC scanners only when authorized, versioned and applicable
- OpenTelemetry or equivalent runtime evidence only when runtime access exists

## Outputs

Use repository-evidence, source-provenance, canonical-pattern and existing finding/evidence contracts when available.

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
