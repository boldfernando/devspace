---
name: github-distill-canonical-patterns
description: "Convert repository evidence into canonical engineering intelligence using ADOPT, ADAPT, AVOID or REFERENCE. Preserve applicability, counter-evidence, source/version/hash/provenance, and map accepted patterns to Actors, Agents, Skills, Tools, Building Blocks and Gates."
metadata:
  version: "3.0.0"
  order: "G05"
  family: github-intelligence-360
---

# Distill Canonical Patterns

## Objective

Convert repository evidence into canonical engineering intelligence using ADOPT, ADAPT, AVOID or REFERENCE. Preserve applicability, counter-evidence, source/version/hash/provenance, and map accepted patterns to Actors, Agents, Skills, Tools, Building Blocks and Gates.

## Operating rules

- Default to `READ_ONLY`.
- Evidence before inference.
- Pin material repository claims to an immutable commit SHA when repository evidence is collected.
- `Trending`, stars, forks, README quality, scanner presence, or CI presence are discovery signals, not assurance.
- `TOOL PRESENT != TOOL EXECUTED ON TARGET SHA != CLEAN RESULT != RISK ACCEPTED`.
- Preserve `UNKNOWN` when required evidence is unavailable.
- Record `Source → Version → Hash → Provenance` for material artifacts.
- Never mutate remote repositories, issues, PRs, releases, Actions, secrets or settings unless separately authorized.

## Definition of Ready (DoR)

- [ ] Pattern evidence is available
- [ ] Direct evidence and inference are separable
- [ ] Canonical neutrality rules are loaded
- [ ] Adoption authority is identified

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Every recommendation is ADOPT/ADAPT/AVOID/REFERENCE
- [ ] Applicability and confidence are explicit
- [ ] Vendor-specific behavior remains an adapter
- [ ] Patterns map to building blocks/capabilities
- [ ] Conflicts/counterexamples are preserved
- [ ] No pattern is promoted solely because of popularity


## Workflow

1. Establish scope, authorization, temporal baseline and source policy.
2. Collect only the evidence required for the current evidence level.
3. Normalize outputs using the pack contracts when available.
4. Separate observation, inference, recommendation, mutation and verification.
5. Return findings, artifacts/hashes, UNKNOWNs, residual risks and the next gate.

## Preferred tools

- Git / GitHub CLI / GitHub REST or GraphQL APIs
- Filesystem and structured parsers
- Project-native build/test tools after repository discovery
- SAST/SCA/secrets/IaC scanners only when authorized, versioned and applicable
- OpenTelemetry or equivalent runtime evidence only when runtime access exists

## Outputs

Use repository-evidence, source-provenance, canonical-pattern and existing finding/evidence contracts when available.

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
