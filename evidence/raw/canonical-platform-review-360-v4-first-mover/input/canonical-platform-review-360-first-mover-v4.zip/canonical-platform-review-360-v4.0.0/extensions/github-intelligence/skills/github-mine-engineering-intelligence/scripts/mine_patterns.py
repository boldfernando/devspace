#!/usr/bin/env python3
from pathlib import Path
import argparse, json
SIGNALS={
    'agents':['agents.md','agent','agents/'],
    'skills':['skill.md','skills/','.agents/'],
    'mcp':['mcp','model context protocol'],
    'specs':['spec','specification','adr'],
    'observability':['opentelemetry','otel','traceparent','metrics'],
    'security':['security.md','semgrep','trivy','gitleaks','codeql'],
    'ci':['.github/workflows','pipeline'],
    'provenance':['attestation','sbom','slsa','cyclonedx','spdx'],
}
def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('root')
    ap.add_argument('--out', default='pattern-signals.json')
    a=ap.parse_args()
    root=Path(a.root)
    paths=[str(p.relative_to(root)).lower() for p in root.rglob('*') if p.is_file()][:200000]
    blob='\n'.join(paths)
    out={}
    for k,terms in SIGNALS.items():
        out[k]={'hits':[t for t in terms if t in blob], 'present':any(t in blob for t in terms)}
    Path(a.out).write_text(json.dumps({'evidence_level':'path_signal_only','signals':out},indent=2)+'\n')
if __name__=='__main__':
    main()
