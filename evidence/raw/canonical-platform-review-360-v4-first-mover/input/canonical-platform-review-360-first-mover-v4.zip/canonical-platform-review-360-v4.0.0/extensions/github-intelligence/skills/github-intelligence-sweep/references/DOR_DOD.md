# GitHub Intelligence Sweep — DoR / DoD

## Definition of Ready
**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01** — Research scope and seed/source policy are explicit
- [ ] **DOR-02** — GitHub/public-access boundary is known
- [ ] **DOR-03** — READ_ONLY is the default
- [ ] **DOR-04** — Output/evidence location is available
- [ ] **DOR-05** — UNKNOWN semantics are accepted

## Definition of Done
**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01** — Repository universe is materialized and deduplicated
- [ ] **DOD-02** — Evidence levels are explicit
- [ ] **DOD-03** — Applicable specialist skills were selected by archetype
- [ ] **DOD-04** — Patterns separate direct evidence from inference
- [ ] **DOD-05** — Adopt/Adapt/Avoid recommendations include applicability and confidence
- [ ] **DOD-06** — Provenance references are recorded
- [ ] **DOD-07** — No remote repository was mutated

## Evidence rule
Every PASS/DONE claim links to captured evidence; missing evidence remains UNKNOWN/PARTIAL.
