# Promote Pattern to Skill — Rubric

Evaluate scope, immutable baseline, source authority, provenance, evidence level, unknowns, archetype applicability, cross-repository support, counter-evidence, output hashes and gate status. Pattern recurrence is not correctness; metadata is not static assurance; static evidence is not runtime assurance.
