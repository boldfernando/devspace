# Verify GitHub Provenance & Supply Chain — DoR / DoD

## Definition of Ready
**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01** — Target SHA/artifact identity is known or explicitly UNKNOWN
- [ ] **DOR-02** — Verification is read-only
- [ ] **DOR-03** — Relevant provenance sources are accessible
- [ ] **DOR-04** — Expected trust policy is defined

## Definition of Done
**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01** — Source SHA and artifact digest are correlated where possible
- [ ] **DOD-02** — SBOM source/version is recorded
- [ ] **DOD-03** — Attestations/signers/workflow identity are verified or UNKNOWN
- [ ] **DOD-04** — Submodule/gitlink SHAs are captured when present
- [ ] **DOD-05** — Scanner/ruleset versions are pinned for generated evidence
- [ ] **DOD-06** — Residual provenance gaps are explicit

## Evidence rule
Every PASS/DONE claim links to captured evidence; missing evidence remains UNKNOWN/PARTIAL.
