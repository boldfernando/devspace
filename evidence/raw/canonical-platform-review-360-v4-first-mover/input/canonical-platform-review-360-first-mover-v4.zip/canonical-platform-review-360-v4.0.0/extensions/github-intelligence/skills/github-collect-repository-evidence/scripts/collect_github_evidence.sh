#!/usr/bin/env bash
set -euo pipefail
repo="${1:?usage: collect_github_evidence.sh owner/repo [outdir]}"
out="${2:-evidence/${repo//\//__}}"
mkdir -p "$out"
command -v gh >/dev/null || { echo '{"status":"UNKNOWN","reason":"gh not installed"}' > "$out/status.json"; exit 2; }
gh api "repos/$repo" > "$out/repository.json"
default_branch=$(python3 -c 'import json; print(json.load(open("'"$out/repository.json"'"))["default_branch"])')
gh api "repos/$repo/commits/$default_branch" > "$out/head.json"
gh api "repos/$repo/git/trees/$default_branch?recursive=1" > "$out/tree.json" || true
gh api "repos/$repo/branches?per_page=100" --paginate > "$out/branches.json" || true
gh api "repos/$repo/tags?per_page=100" --paginate > "$out/tags.json" || true
gh api "repos/$repo/actions/workflows?per_page=100" > "$out/workflows.json" || true
gh api "repos/$repo/issues?state=all&per_page=100" --paginate > "$out/issues_and_prs.json" || true
gh api -H 'Accept: application/vnd.github+json' "repos/$repo/dependency-graph/sbom" > "$out/sbom.spdx.json" 2>"$out/sbom.error" || true
python3 - "$out" <<'PYINNER'
import hashlib,json,pathlib,sys,datetime
root=pathlib.Path(sys.argv[1]); items=[]
for p in sorted(root.iterdir()):
 if p.is_file(): items.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(root/'MANIFEST.sha256.json').write_text(json.dumps({'captured_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifacts':items},indent=2)+'\n')
PYINNER
