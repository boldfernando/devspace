---
name: github-verify-provenance-supply-chain
description: "Verify repository and artifact provenance signals using immutable Git identity, dependency graph/SBOM evidence, attestations, signatures, submodule/gitlink pins and vendor-neutral supply-chain standards. Tool/config presence alone is not verification."
metadata:
  version: "3.0.0"
  order: "G04"
  family: github-intelligence-360
---

# Verify GitHub Provenance & Supply Chain

## Objective

Verify repository and artifact provenance signals using immutable Git identity, dependency graph/SBOM evidence, attestations, signatures, submodule/gitlink pins and vendor-neutral supply-chain standards. Tool/config presence alone is not verification.

## Operating rules

- Default to `READ_ONLY`.
- Evidence before inference.
- Pin material repository claims to an immutable commit SHA when repository evidence is collected.
- `Trending`, stars, forks, README quality, scanner presence, or CI presence are discovery signals, not assurance.
- `TOOL PRESENT != TOOL EXECUTED ON TARGET SHA != CLEAN RESULT != RISK ACCEPTED`.
- Preserve `UNKNOWN` when required evidence is unavailable.
- Record `Source → Version → Hash → Provenance` for material artifacts.
- Never mutate remote repositories, issues, PRs, releases, Actions, secrets or settings unless separately authorized.

## Definition of Ready (DoR)

- [ ] Target SHA/artifact identity is known or explicitly UNKNOWN
- [ ] Verification is read-only
- [ ] Relevant provenance sources are accessible
- [ ] Expected trust policy is defined

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Source SHA and artifact digest are correlated where possible
- [ ] SBOM source/version is recorded
- [ ] Attestations/signers/workflow identity are verified or UNKNOWN
- [ ] Submodule/gitlink SHAs are captured when present
- [ ] Scanner/ruleset versions are pinned for generated evidence
- [ ] Residual provenance gaps are explicit


## Workflow

1. Establish scope, authorization, temporal baseline and source policy.
2. Collect only the evidence required for the current evidence level.
3. Normalize outputs using the pack contracts when available.
4. Separate observation, inference, recommendation, mutation and verification.
5. Return findings, artifacts/hashes, UNKNOWNs, residual risks and the next gate.

## Preferred tools

- Git / GitHub CLI / GitHub REST or GraphQL APIs
- Filesystem and structured parsers
- Project-native build/test tools after repository discovery
- SAST/SCA/secrets/IaC scanners only when authorized, versioned and applicable
- OpenTelemetry or equivalent runtime evidence only when runtime access exists

## Outputs

Use repository-evidence, source-provenance, canonical-pattern and existing finding/evidence contracts when available.

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
