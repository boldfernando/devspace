# Mine GitHub Engineering Intelligence — DoR / DoD

## Definition of Ready
**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01** — A repository/evidence corpus exists
- [ ] **DOR-02** — Archetype labels or discovery evidence exist
- [ ] **DOR-03** — Material claims can point to source artifacts
- [ ] **DOR-04** — Inference labeling is enabled

## Definition of Done
**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01** — Patterns have IDs and evidence pointers
- [ ] **DOD-02** — Pattern frequency is distinguished from desirability
- [ ] **DOD-03** — Anti-patterns are captured
- [ ] **DOD-04** — Agentic and conventional engineering signals are both considered
- [ ] **DOD-05** — Framework/vendor-specific patterns are tagged conditional
- [ ] **DOD-06** — Confidence and counter-evidence are recorded

## Evidence rule
Every PASS/DONE claim links to captured evidence; missing evidence remains UNKNOWN/PARTIAL.
