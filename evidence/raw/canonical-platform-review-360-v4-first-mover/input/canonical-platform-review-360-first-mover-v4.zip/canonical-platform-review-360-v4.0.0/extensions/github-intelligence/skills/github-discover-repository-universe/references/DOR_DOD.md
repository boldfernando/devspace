# Discover GitHub Repository Universe — DoR / DoD

## Definition of Ready
**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01** — At least one seed/source is readable
- [ ] **DOR-02** — Capture timestamp/source identity can be recorded
- [ ] **DOR-03** — Repository identity normalization rules are defined
- [ ] **DOR-04** — Private sources are authorized before use

## Definition of Done
**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01** — owner/repo identities are deduplicated
- [ ] **DOD-02** — Each repository retains source pointers and capture context
- [ ] **DOD-03** — Temporal windows/languages/topics are preserved when known
- [ ] **DOD-04** — Invalid/non-repository URLs are excluded
- [ ] **DOD-05** — Freshness limitations are explicit
- [ ] **DOD-06** — Machine-readable repository inventory is emitted

## Evidence rule
Every PASS/DONE claim links to captured evidence; missing evidence remains UNKNOWN/PARTIAL.
