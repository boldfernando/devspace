#!/usr/bin/env python3
from pathlib import Path
import argparse, json, re
from bs4 import BeautifulSoup

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('paths',nargs='+'); ap.add_argument('--out',default='repositories.json'); a=ap.parse_args()
    repos={}
    for raw in a.paths:
        p=Path(raw); soup=BeautifulSoup(p.read_text(errors='ignore'),'html.parser')
        for h in soup.select('article.Box-row h2.h3 a[href]'):
            u=h.get('href',''); m=re.match(r'https://github\.com/([^/]+)/([^/?#]+)',u)
            if m: repos[f'{m.group(1)}/{m.group(2)}']={'repository':f'{m.group(1)}/{m.group(2)}','url':u,'source':str(p),'evidence_level':'seed_metadata_only'}
    Path(a.out).write_text(json.dumps({'repositories':sorted(repos.values(),key=lambda x:x['repository'].lower())},indent=2)+'\n')
if __name__=='__main__': main()
