# Promote Pattern to Skill — DoR / DoD

## Definition of Ready
**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01** — Pattern stance is ADOPT or approved ADAPT
- [ ] **DOR-02** — Evidence/provenance is sufficient
- [ ] **DOR-03** — Skill boundary and trigger are distinct
- [ ] **DOR-04** — No equivalent canonical skill already owns the behavior
- [ ] **DOR-05** — Human/Actor authority for promotion is known

## Definition of Done
**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01** — Draft follows Agent Skills structure
- [ ] **DOD-02** — Description is concise and routing-distinct
- [ ] **DOD-03** — DoR/DoD are evidence-based
- [ ] **DOD-04** — References have authority classes/versions
- [ ] **DOD-05** — Evals include positive, negative, ambiguous and failure cases
- [ ] **DOD-06** — Scripts are safe/read-only by default
- [ ] **DOD-07** — Draft is validated but not auto-installed

## Evidence rule
Every PASS/DONE claim links to captured evidence; missing evidence remains UNKNOWN/PARTIAL.
