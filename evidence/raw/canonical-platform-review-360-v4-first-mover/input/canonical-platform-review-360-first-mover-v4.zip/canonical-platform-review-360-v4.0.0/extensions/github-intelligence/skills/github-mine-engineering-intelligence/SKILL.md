---
name: github-mine-engineering-intelligence
description: "Mine cross-repository engineering patterns across architecture, agents, skills, tools, workflows, memory/context, MCP, evals, observability, security, CI/CD, governance, human approvals and developer ergonomics. Require multi-repository evidence before declaring a recurring pattern."
metadata:
  version: "3.0.0"
  order: "G03"
  family: github-intelligence-360
---

# Mine GitHub Engineering Intelligence

## Objective

Mine cross-repository engineering patterns across architecture, agents, skills, tools, workflows, memory/context, MCP, evals, observability, security, CI/CD, governance, human approvals and developer ergonomics. Require multi-repository evidence before declaring a recurring pattern.

## Operating rules

- Default to `READ_ONLY`.
- Evidence before inference.
- Pin material repository claims to an immutable commit SHA when repository evidence is collected.
- `Trending`, stars, forks, README quality, scanner presence, or CI presence are discovery signals, not assurance.
- `TOOL PRESENT != TOOL EXECUTED ON TARGET SHA != CLEAN RESULT != RISK ACCEPTED`.
- Preserve `UNKNOWN` when required evidence is unavailable.
- Record `Source → Version → Hash → Provenance` for material artifacts.
- Never mutate remote repositories, issues, PRs, releases, Actions, secrets or settings unless separately authorized.

## Definition of Ready (DoR)

- [ ] A repository/evidence corpus exists
- [ ] Archetype labels or discovery evidence exist
- [ ] Material claims can point to source artifacts
- [ ] Inference labeling is enabled

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Patterns have IDs and evidence pointers
- [ ] Pattern frequency is distinguished from desirability
- [ ] Anti-patterns are captured
- [ ] Agentic and conventional engineering signals are both considered
- [ ] Framework/vendor-specific patterns are tagged conditional
- [ ] Confidence and counter-evidence are recorded


## Workflow

1. Establish scope, authorization, temporal baseline and source policy.
2. Collect only the evidence required for the current evidence level.
3. Normalize outputs using the pack contracts when available.
4. Separate observation, inference, recommendation, mutation and verification.
5. Return findings, artifacts/hashes, UNKNOWNs, residual risks and the next gate.

## Preferred tools

- Git / GitHub CLI / GitHub REST or GraphQL APIs
- Filesystem and structured parsers
- Project-native build/test tools after repository discovery
- SAST/SCA/secrets/IaC scanners only when authorized, versioned and applicable
- OpenTelemetry or equivalent runtime evidence only when runtime access exists

## Outputs

Use repository-evidence, source-provenance, canonical-pattern and existing finding/evidence contracts when available.

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
