---
name: github-intelligence-sweep
description: "Orchestrate a read-only seed-to-evidence-to-pattern GitHub intelligence sweep. Use for repository-universe research, architecture mining, agent/skill ecosystem analysis, provenance review, and evidence-backed Adopt/Adapt/Avoid synthesis. Do not equate Trending or stars with assurance."
metadata:
  version: "3.0.0"
  order: "G00"
  family: github-intelligence-360
---

# GitHub Intelligence Sweep

## Objective

Orchestrate a read-only seed-to-evidence-to-pattern GitHub intelligence sweep. Use for repository-universe research, architecture mining, agent/skill ecosystem analysis, provenance review, and evidence-backed Adopt/Adapt/Avoid synthesis. Do not equate Trending or stars with assurance.

## Operating rules

- Default to `READ_ONLY`.
- Evidence before inference.
- Pin material repository claims to an immutable commit SHA when repository evidence is collected.
- `Trending`, stars, forks, README quality, scanner presence, or CI presence are discovery signals, not assurance.
- `TOOL PRESENT != TOOL EXECUTED ON TARGET SHA != CLEAN RESULT != RISK ACCEPTED`.
- Preserve `UNKNOWN` when required evidence is unavailable.
- Record `Source → Version → Hash → Provenance` for material artifacts.
- Never mutate remote repositories, issues, PRs, releases, Actions, secrets or settings unless separately authorized.

## Definition of Ready (DoR)

- [ ] Research scope and seed/source policy are explicit
- [ ] GitHub/public-access boundary is known
- [ ] READ_ONLY is the default
- [ ] Output/evidence location is available
- [ ] UNKNOWN semantics are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Repository universe is materialized and deduplicated
- [ ] Evidence levels are explicit
- [ ] Applicable specialist skills were selected by archetype
- [ ] Patterns separate direct evidence from inference
- [ ] Adopt/Adapt/Avoid recommendations include applicability and confidence
- [ ] Provenance references are recorded
- [ ] No remote repository was mutated


## Workflow

1. Establish scope, authorization, temporal baseline and source policy.
2. Collect only the evidence required for the current evidence level.
3. Normalize outputs using the pack contracts when available.
4. Separate observation, inference, recommendation, mutation and verification.
5. Return findings, artifacts/hashes, UNKNOWNs, residual risks and the next gate.

## Specialist dispatch

Delegate to: `github-discover-repository-universe`, `github-collect-repository-evidence`, `github-mine-engineering-intelligence`, `github-verify-provenance-supply-chain`, `github-distill-canonical-patterns`.

## Preferred tools

- Git / GitHub CLI / GitHub REST or GraphQL APIs
- Filesystem and structured parsers
- Project-native build/test tools after repository discovery
- SAST/SCA/secrets/IaC scanners only when authorized, versioned and applicable
- OpenTelemetry or equivalent runtime evidence only when runtime access exists

## Outputs

Use repository-evidence, source-provenance, canonical-pattern and existing finding/evidence contracts when available.

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
