# Distill Canonical Patterns — DoR / DoD

## Definition of Ready
**Decision:** `READY | CONDITIONAL | NOT_READY`

- [ ] **DOR-01** — Pattern evidence is available
- [ ] **DOR-02** — Direct evidence and inference are separable
- [ ] **DOR-03** — Canonical neutrality rules are loaded
- [ ] **DOR-04** — Adoption authority is identified

## Definition of Done
**Decision:** `DONE | PARTIAL | NOT_DONE`

- [ ] **DOD-01** — Every recommendation is ADOPT/ADAPT/AVOID/REFERENCE
- [ ] **DOD-02** — Applicability and confidence are explicit
- [ ] **DOD-03** — Vendor-specific behavior remains an adapter
- [ ] **DOD-04** — Patterns map to building blocks/capabilities
- [ ] **DOD-05** — Conflicts/counterexamples are preserved
- [ ] **DOD-06** — No pattern is promoted solely because of popularity

## Evidence rule
Every PASS/DONE claim links to captured evidence; missing evidence remains UNKNOWN/PARTIAL.
