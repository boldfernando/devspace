---
name: github-promote-pattern-to-skill
description: "Turn a validated canonical pattern into a draft Agent Skill package with SKILL.md, references, DoR/DoD, evals, scripts only where deterministic value exists, and provenance back to the source evidence. Drafting never implies installation or activation."
metadata:
  version: "3.0.0"
  order: "G06"
  family: github-intelligence-360
---

# Promote Pattern to Skill

## Objective

Turn a validated canonical pattern into a draft Agent Skill package with SKILL.md, references, DoR/DoD, evals, scripts only where deterministic value exists, and provenance back to the source evidence. Drafting never implies installation or activation.

## Operating rules

- Default to `READ_ONLY`.
- Evidence before inference.
- Pin material repository claims to an immutable commit SHA when repository evidence is collected.
- `Trending`, stars, forks, README quality, scanner presence, or CI presence are discovery signals, not assurance.
- `TOOL PRESENT != TOOL EXECUTED ON TARGET SHA != CLEAN RESULT != RISK ACCEPTED`.
- Preserve `UNKNOWN` when required evidence is unavailable.
- Record `Source → Version → Hash → Provenance` for material artifacts.
- Never mutate remote repositories, issues, PRs, releases, Actions, secrets or settings unless separately authorized.

## Definition of Ready (DoR)

- [ ] Pattern stance is ADOPT or approved ADAPT
- [ ] Evidence/provenance is sufficient
- [ ] Skill boundary and trigger are distinct
- [ ] No equivalent canonical skill already owns the behavior
- [ ] Human/Actor authority for promotion is known

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Draft follows Agent Skills structure
- [ ] Description is concise and routing-distinct
- [ ] DoR/DoD are evidence-based
- [ ] References have authority classes/versions
- [ ] Evals include positive, negative, ambiguous and failure cases
- [ ] Scripts are safe/read-only by default
- [ ] Draft is validated but not auto-installed


## Workflow

1. Establish scope, authorization, temporal baseline and source policy.
2. Collect only the evidence required for the current evidence level.
3. Normalize outputs using the pack contracts when available.
4. Separate observation, inference, recommendation, mutation and verification.
5. Return findings, artifacts/hashes, UNKNOWNs, residual risks and the next gate.

## Preferred tools

- Git / GitHub CLI / GitHub REST or GraphQL APIs
- Filesystem and structured parsers
- Project-native build/test tools after repository discovery
- SAST/SCA/secrets/IaC scanners only when authorized, versioned and applicable
- OpenTelemetry or equivalent runtime evidence only when runtime access exists

## Outputs

Use repository-evidence, source-provenance, canonical-pattern and existing finding/evidence contracts when available.

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
