# Domain rubric

Close the human accountability loop without confusing acceptance with correctness.

## Core checks

- Technical verifier and human acceptance are distinct gates
- Revocation is future-facing when effects are irreversible
- Rejected work retains evidence for learning
- Present verified outcome and residual risk
- Capture acceptance/rejection/revocation
- Update buildback/issue state
- Emit audit event and next action