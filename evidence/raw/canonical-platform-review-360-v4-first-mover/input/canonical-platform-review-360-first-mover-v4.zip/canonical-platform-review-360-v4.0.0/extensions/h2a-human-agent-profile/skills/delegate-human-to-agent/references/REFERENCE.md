# Domain rubric

Make human-to-agent delegation scoped, auditable and revocable.

## Core checks

- Delegation cannot widen parent authority
- Descendant agents inherit only explicitly transitive scope
- Every delegation has correlation/trace identity
- Validate authority grant
- Bind task and agent address
- Apply constraints and approval policy
- Emit delegation and acknowledgment requirement