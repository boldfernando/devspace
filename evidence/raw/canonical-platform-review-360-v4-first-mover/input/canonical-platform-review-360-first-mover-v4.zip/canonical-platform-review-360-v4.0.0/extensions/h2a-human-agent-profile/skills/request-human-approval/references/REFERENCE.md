# Domain rubric

Turn human-in-the-loop into a typed gate rather than a vague conversational pause.

## Core checks

- Approval request describes exact pending effect
- No approval laundering across sibling tasks
- Expired/revoked approvals cannot authorize writes
- Freeze pending action
- Summarize evidence/diff/risk/rollback
- Render structured approval request
- Record decision and resume/block accordingly