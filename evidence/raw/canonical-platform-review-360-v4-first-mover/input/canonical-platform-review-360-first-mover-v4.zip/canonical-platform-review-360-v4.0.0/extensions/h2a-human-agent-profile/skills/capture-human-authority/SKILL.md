---
name: capture-human-authority
description: "Capture human identity, delegated authority, action/resource scope, risk ceiling, expiry and revocation semantics before agent side effects."
metadata:
  version: "4.0.0"
  order: "H00"
  family: h2a-human-agent-profile
---

# Capture Human Authority

## Objective

Convert conversational intent into an explicit machine-readable authority grant.

## Operating rules

- Absence of permission is not permission
- Scope actions and resources independently
- Keep authorization separate from acceptance
- Mark this profile experimental, not Google-official

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Identify accountable actor
2. Normalize allowed actions/resources/constraints
3. Set risk/expiry/revocation policy
4. Emit authority grant and unresolved ambiguities

## Preferred tools

- h2actl.py
- Host-native confirmation UI
- A2UI/AG-UI adapters when present

## Outputs

- `h2a-authority-grant.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
