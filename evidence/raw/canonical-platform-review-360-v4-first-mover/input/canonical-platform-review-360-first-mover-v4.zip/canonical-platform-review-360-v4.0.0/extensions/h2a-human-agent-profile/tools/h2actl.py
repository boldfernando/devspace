#!/usr/bin/env python3
"""Experimental H2A state/envelope validator. Not an official Google protocol."""
import argparse,json
from pathlib import Path
TRANS={
'DRAFT':{'AUTHORIZED','CANCELLED'},'AUTHORIZED':{'DELEGATED','REVOKED','EXPIRED'},'DELEGATED':{'ACKNOWLEDGED','REVOKED','EXPIRED'},
'ACKNOWLEDGED':{'EXECUTING','REVOKED','EXPIRED'},'EXECUTING':{'NEEDS_INPUT','APPROVAL_REQUIRED','VERIFYING','FAILED','REVOKED'},
'NEEDS_INPUT':{'EXECUTING','CANCELLED','EXPIRED'},'APPROVAL_REQUIRED':{'EXECUTING','REJECTED','REVOKED','EXPIRED'},
'VERIFYING':{'ACCEPTED','REJECTED','FAILED'},'ACCEPTED':set(),'REJECTED':set(),'REVOKED':set(),'EXPIRED':set(),'FAILED':set(),'CANCELLED':set()}
def main():
 p=argparse.ArgumentParser(); sp=p.add_subparsers(dest='cmd',required=True)
 q=sp.add_parser('validate');q.add_argument('file')
 q=sp.add_parser('transition');q.add_argument('current');q.add_argument('target')
 a=p.parse_args()
 if a.cmd=='transition':
  ok=a.target in TRANS.get(a.current,set()); print(json.dumps({'allowed':ok,'current':a.current,'target':a.target})); raise SystemExit(0 if ok else 2)
 d=json.loads(Path(a.file).read_text()); req=['interaction_id','type','actor_id','task_id','state']; missing=[x for x in req if x not in d]
 print(json.dumps({'valid':not missing and d.get('state') in TRANS,'missing':missing,'experimental_profile':'canonical-h2a-v0.1'},indent=2)); raise SystemExit(0 if not missing else 2)
if __name__=='__main__':main()
