# Sources

- protocols/H2A_PROFILE_SPEC.md
- https://a2a-protocol.org/v1.0.0/
- https://github.com/ag-ui-protocol/ag-ui/
- https://developers.googleblog.com/en/a2ui-v0-9-generative-ui/