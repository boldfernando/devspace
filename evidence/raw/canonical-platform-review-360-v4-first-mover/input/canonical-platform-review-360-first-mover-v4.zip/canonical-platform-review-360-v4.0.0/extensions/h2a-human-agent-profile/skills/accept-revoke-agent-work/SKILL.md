---
name: accept-revoke-agent-work
description: "Record human acceptance, rejection or revocation independently from technical verification and execution authorization."
metadata:
  version: "4.0.0"
  order: "H04"
  family: h2a-human-agent-profile
---

# Accept or Revoke Agent Work

## Objective

Close the human accountability loop without confusing acceptance with correctness.

## Operating rules

- Technical verifier and human acceptance are distinct gates
- Revocation is future-facing when effects are irreversible
- Rejected work retains evidence for learning

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Present verified outcome and residual risk
2. Capture acceptance/rejection/revocation
3. Update buildback/issue state
4. Emit audit event and next action

## Preferred tools

- h2actl.py
- Host-native confirmation UI
- A2UI/AG-UI adapters when present

## Outputs

- `h2a-acceptance.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
