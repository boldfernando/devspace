---
name: request-human-approval
description: "Request explicit human approval for a pending high-impact side effect with sufficient evidence, diff and rollback context."
metadata:
  version: "4.0.0"
  order: "H02"
  family: h2a-human-agent-profile
---

# Request Human Approval

## Objective

Turn human-in-the-loop into a typed gate rather than a vague conversational pause.

## Operating rules

- Approval request describes exact pending effect
- No approval laundering across sibling tasks
- Expired/revoked approvals cannot authorize writes

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Freeze pending action
2. Summarize evidence/diff/risk/rollback
3. Render structured approval request
4. Record decision and resume/block accordingly

## Preferred tools

- h2actl.py
- Host-native confirmation UI
- A2UI/AG-UI adapters when present

## Outputs

- `h2a-approval-request.json`
- `h2a-approval-decision.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
