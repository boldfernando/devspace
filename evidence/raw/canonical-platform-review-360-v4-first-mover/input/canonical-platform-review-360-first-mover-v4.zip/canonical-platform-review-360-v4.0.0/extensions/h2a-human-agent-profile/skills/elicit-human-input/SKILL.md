---
name: elicit-human-input
description: "Elicit missing human information only when it materially blocks safe or correct execution, preserving task state for durable resume."
metadata:
  version: "4.0.0"
  order: "H03"
  family: h2a-human-agent-profile
---

# Elicit Human Input

## Objective

Make human input an event-driven dependency rather than an idle agent loop.

## Operating rules

- Do not ask what repository/runtime evidence can resolve
- Persist resume token/state before waiting
- Limit question to decision-relevant unknowns

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Identify blocking unknown
2. Create typed elicitation payload
3. Pause/dormant task
4. Resume from recorded state when answer arrives

## Preferred tools

- h2actl.py
- Host-native confirmation UI
- A2UI/AG-UI adapters when present

## Outputs

- `h2a-elicitation.json`
- `resume-token.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
