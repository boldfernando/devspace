---
name: delegate-human-to-agent
description: "Create an H2A delegation binding human authority to a specific mission/buildback/task and addressed agent."
metadata:
  version: "4.0.0"
  order: "H01"
  family: h2a-human-agent-profile
---

# Delegate Human to Agent

## Objective

Make human-to-agent delegation scoped, auditable and revocable.

## Operating rules

- Delegation cannot widen parent authority
- Descendant agents inherit only explicitly transitive scope
- Every delegation has correlation/trace identity

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Validate authority grant
2. Bind task and agent address
3. Apply constraints and approval policy
4. Emit delegation and acknowledgment requirement

## Preferred tools

- h2actl.py
- Host-native confirmation UI
- A2UI/AG-UI adapters when present

## Outputs

- `h2a-delegation.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
