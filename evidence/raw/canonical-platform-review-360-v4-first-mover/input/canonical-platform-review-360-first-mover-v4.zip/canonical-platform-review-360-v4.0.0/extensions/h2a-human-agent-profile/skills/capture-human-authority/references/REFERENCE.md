# Domain rubric

Convert conversational intent into an explicit machine-readable authority grant.

## Core checks

- Absence of permission is not permission
- Scope actions and resources independently
- Keep authorization separate from acceptance
- Mark this profile experimental, not Google-official
- Identify accountable actor
- Normalize allowed actions/resources/constraints
- Set risk/expiry/revocation policy
- Emit authority grant and unresolved ambiguities