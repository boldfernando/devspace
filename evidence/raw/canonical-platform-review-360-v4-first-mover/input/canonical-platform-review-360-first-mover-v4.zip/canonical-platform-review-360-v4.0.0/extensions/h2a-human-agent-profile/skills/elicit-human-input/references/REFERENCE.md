# Domain rubric

Make human input an event-driven dependency rather than an idle agent loop.

## Core checks

- Do not ask what repository/runtime evidence can resolve
- Persist resume token/state before waiting
- Limit question to decision-relevant unknowns
- Identify blocking unknown
- Create typed elicitation payload
- Pause/dormant task
- Resume from recorded state when answer arrives