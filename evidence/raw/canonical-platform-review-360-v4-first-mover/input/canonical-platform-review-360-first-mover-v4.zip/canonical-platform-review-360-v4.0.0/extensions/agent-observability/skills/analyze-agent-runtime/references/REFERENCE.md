# Domain rubric

Optimize verified work, not agent busyness.

## Core checks

- Prefer verified throughput over raw parallelism
- Separate queue, model, tool, lease and human latency
- Track prevented conflicts as positive safety signal
- Aggregate traces/events/ledger
- Compute runtime KPIs
- Locate critical path/bottlenecks
- Recommend scheduler/budget/routing changes