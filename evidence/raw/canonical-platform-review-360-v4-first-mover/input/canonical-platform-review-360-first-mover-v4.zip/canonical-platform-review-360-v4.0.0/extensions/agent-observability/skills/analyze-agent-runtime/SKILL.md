---
name: analyze-agent-runtime
description: "Analyze throughput, critical path, conflict pressure, verification yield, latency, token/cost efficiency and human wait time."
metadata:
  version: "4.0.0"
  order: "O02"
  family: agent-observability
---

# Analyze Agent Runtime

## Objective

Optimize verified work, not agent busyness.

## Operating rules

- Prefer verified throughput over raw parallelism
- Separate queue, model, tool, lease and human latency
- Track prevented conflicts as positive safety signal

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Aggregate traces/events/ledger
2. Compute runtime KPIs
3. Locate critical path/bottlenecks
4. Recommend scheduler/budget/routing changes

## Preferred tools

- OpenTelemetry SDK/collector
- otel_mapper.py
- Host trace APIs
- Execution event journal

## Outputs

- `agent-runtime-analysis.json`
- `agent-runtime-scorecard.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
