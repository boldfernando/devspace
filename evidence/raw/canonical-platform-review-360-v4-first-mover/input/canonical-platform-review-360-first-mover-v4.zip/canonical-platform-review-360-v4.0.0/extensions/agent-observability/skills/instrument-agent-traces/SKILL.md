---
name: instrument-agent-traces
description: "Instrument buildbacks, tasks, agents, models, tools, A2A exchanges, H2A gates and verification with correlated traces/events."
metadata:
  version: "4.0.0"
  order: "O00"
  family: agent-observability
---

# Instrument Agent Traces

## Objective

Make every execution hop observable without requiring sensitive content capture.

## Operating rules

- Metadata-first; prompt/response content opt-in
- Low-cardinality identifiers for metric dimensions
- Preserve parent/causation/correlation relationships

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Define trace/group correlation
2. Instrument agent/model/tool/remote/human spans
3. Attach canonical identifiers
4. Export with vendor-neutral OTel where possible

## Preferred tools

- OpenTelemetry SDK/collector
- otel_mapper.py
- Host trace APIs
- Execution event journal

## Outputs

- `telemetry-map.json`
- `trace-policy.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
