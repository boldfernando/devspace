# Sources

- https://opentelemetry.io/docs/specs/semconv/
- https://opentelemetry.io/blog/2026/genai-observability/
- https://developers.googleblog.com/build-long-running-ai-agents-that-pause-resume-and-never-lose-context-with-adk/
- https://google.github.io/agents-cli/guide/observability/