---
name: monitor-agent-liveness
description: "Monitor agent heartbeat, lease expiry, queue wait, blocked state and orphan detection."
metadata:
  version: "4.0.0"
  order: "O01"
  family: agent-observability
---

# Monitor Agent Liveness

## Objective

Detect stuck or dead workers before they become invisible workflow stalls.

## Operating rules

- Liveness is not task correctness
- Expired lease releases require recovery policy
- Orphan detection must not duplicate irreversible writes

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Collect heartbeats/lease state
2. Detect stale/orphaned agents
3. Classify safe retry vs human review
4. Emit liveness events/SLOs

## Preferred tools

- OpenTelemetry SDK/collector
- otel_mapper.py
- Host trace APIs
- Execution event journal

## Outputs

- `agent-health.json`
- `liveness-events.jsonl`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
