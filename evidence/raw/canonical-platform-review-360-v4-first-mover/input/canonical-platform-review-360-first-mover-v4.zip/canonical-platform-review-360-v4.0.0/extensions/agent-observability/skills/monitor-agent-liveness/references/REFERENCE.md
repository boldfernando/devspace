# Domain rubric

Detect stuck or dead workers before they become invisible workflow stalls.

## Core checks

- Liveness is not task correctness
- Expired lease releases require recovery policy
- Orphan detection must not duplicate irreversible writes
- Collect heartbeats/lease state
- Detect stale/orphaned agents
- Classify safe retry vs human review
- Emit liveness events/SLOs