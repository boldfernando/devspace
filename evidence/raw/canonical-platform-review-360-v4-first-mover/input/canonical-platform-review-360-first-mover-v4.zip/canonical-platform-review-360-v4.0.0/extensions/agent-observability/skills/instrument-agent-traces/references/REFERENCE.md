# Domain rubric

Make every execution hop observable without requiring sensitive content capture.

## Core checks

- Metadata-first; prompt/response content opt-in
- Low-cardinality identifiers for metric dimensions
- Preserve parent/causation/correlation relationships
- Define trace/group correlation
- Instrument agent/model/tool/remote/human spans
- Attach canonical identifiers
- Export with vendor-neutral OTel where possible