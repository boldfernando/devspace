#!/usr/bin/env python3
import argparse,json
# Generates a vendor-neutral attribute set suitable for mapping into OTel spans/events.
def main():
 p=argparse.ArgumentParser();
 for x in ['mission','buildback','issue','task','agent','attempt','a2a-task','a2a-context','h2a-delegation']: p.add_argument('--'+x)
 a=p.parse_args(); d={
 'canonical.mission.id':a.mission,'canonical.buildback.id':a.buildback,'canonical.issue.id':a.issue,'canonical.task.id':a.task,
 'canonical.agent.address':a.agent,'canonical.agent.attempt':a.attempt,'a2a.task.id':a.a2a_task,'a2a.context.id':a.a2a_context,'h2a.delegation.id':a.h2a_delegation}
 print(json.dumps({k:v for k,v in d.items() if v is not None},indent=2))
if __name__=='__main__':main()
