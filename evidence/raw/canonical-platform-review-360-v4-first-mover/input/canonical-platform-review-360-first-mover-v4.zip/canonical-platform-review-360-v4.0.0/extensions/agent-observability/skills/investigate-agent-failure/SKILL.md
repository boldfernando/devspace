---
name: investigate-agent-failure
description: "Investigate failed, stale, conflicted or low-quality agent attempts using trace/evidence/lease/workspace lineage."
metadata:
  version: "4.0.0"
  order: "O03"
  family: agent-observability
---

# Investigate Agent Failure

## Objective

Find root cause without losing failed-attempt evidence needed for learning.

## Operating rules

- Do not overwrite failed attempt history
- Separate model failure, tool failure, policy block, conflict and stale baseline
- Retries require cause-aware policy

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Load failed attempt lineage
2. Correlate spans/events/artifacts
3. Classify root cause
4. Recommend retry/replan/escalation/rollback

## Preferred tools

- OpenTelemetry SDK/collector
- otel_mapper.py
- Host trace APIs
- Execution event journal

## Outputs

- `agent-failure-report.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
