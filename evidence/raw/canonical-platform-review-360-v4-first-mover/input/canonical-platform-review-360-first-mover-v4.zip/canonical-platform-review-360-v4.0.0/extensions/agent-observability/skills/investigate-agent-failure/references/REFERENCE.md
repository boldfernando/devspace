# Domain rubric

Find root cause without losing failed-attempt evidence needed for learning.

## Core checks

- Do not overwrite failed attempt history
- Separate model failure, tool failure, policy block, conflict and stale baseline
- Retries require cause-aware policy
- Load failed attempt lineage
- Correlate spans/events/artifacts
- Classify root cause
- Recommend retry/replan/escalation/rollback