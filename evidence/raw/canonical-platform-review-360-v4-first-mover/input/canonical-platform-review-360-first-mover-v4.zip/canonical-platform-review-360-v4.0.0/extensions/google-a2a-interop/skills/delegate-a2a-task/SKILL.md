---
name: delegate-a2a-task
description: "Delegate a bounded canonical task to a remote A2A agent and correlate A2A task/context IDs with the local buildback."
metadata:
  version: "4.0.0"
  order: "A02"
  family: google-a2a-interop
---

# Delegate A2A Task

## Objective

Bridge canonical tasks to A2A without losing local authority, evidence, trace or resource semantics.

## Operating rules

- Remote agent never inherits more authority than delegated
- Preserve local task/buildback identity in correlation metadata
- Treat remote artifacts as unverified until local gate

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Prepare bounded delegation
2. Send via negotiated binding/SDK
3. Subscribe/poll according to capability
4. Collect messages/artifacts/status
5. Map remote result back to local evidence

## Preferred tools

- Official A2A SDK for selected language
- a2actl.py for local evidence normalization
- HTTP/gRPC diagnostics when authorized

## Outputs

- `a2a-delegation.json`
- `a2a-task-evidence.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
