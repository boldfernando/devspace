---
name: negotiate-a2a-capabilities
description: "Negotiate A2A protocol version, binding, modalities, streaming, extensions and security before delegation."
metadata:
  version: "4.0.0"
  order: "A01"
  family: google-a2a-interop
---

# Negotiate A2A Capabilities

## Objective

Prevent optimistic interoperability assumptions between heterogeneous agents.

## Operating rules

- Validate protocol compatibility before work
- Do not assume streaming/push/extensions
- Prefer official SDK/bindings over hand-crafted wire formats

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Compare local requirements with Agent Card
2. Select compatible interface/binding
3. Resolve auth/version/extensions
4. Emit negotiated contract

## Preferred tools

- Official A2A SDK for selected language
- a2actl.py for local evidence normalization
- HTTP/gRPC diagnostics when authorized

## Outputs

- `a2a-negotiation.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
