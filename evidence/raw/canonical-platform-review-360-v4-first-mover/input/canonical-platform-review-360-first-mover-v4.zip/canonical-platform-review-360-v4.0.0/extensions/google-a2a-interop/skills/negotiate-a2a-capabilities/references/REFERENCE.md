# Domain rubric

Prevent optimistic interoperability assumptions between heterogeneous agents.

## Core checks

- Validate protocol compatibility before work
- Do not assume streaming/push/extensions
- Prefer official SDK/bindings over hand-crafted wire formats
- Compare local requirements with Agent Card
- Select compatible interface/binding
- Resolve auth/version/extensions
- Emit negotiated contract