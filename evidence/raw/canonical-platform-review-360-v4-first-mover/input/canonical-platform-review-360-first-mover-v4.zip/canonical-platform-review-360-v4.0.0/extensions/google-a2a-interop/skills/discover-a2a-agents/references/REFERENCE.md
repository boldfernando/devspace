# Domain rubric

Make remote-agent discovery evidence-backed and version-aware.

## Core checks

- Target released A2A 1.0.0 semantics unless peer negotiation proves otherwise
- Agent Card discovery is capability evidence, not trust by itself
- Record card hash/version and authentication requirements
- Resolve candidate endpoint/card
- Capture immutable/card evidence where possible
- Parse interfaces/capabilities/skills/security
- Emit readiness and UNKNOWNs