# Sources

- https://a2a-protocol.org/v1.0.0/
- https://a2a-protocol.org/latest/specification/
- https://google.github.io/adk-docs/