---
name: verify-a2a-interoperation
description: "Verify real A2A interoperability, lifecycle, error behavior, security and artifact exchange across agent boundaries."
metadata:
  version: "4.0.0"
  order: "A03"
  family: google-a2a-interop
---

# Verify A2A Interoperation

## Objective

Prove that discovery and negotiation survive actual execution.

## Operating rules

- Presence of an A2A endpoint is not PASS
- Test version/error/idempotency behavior appropriate to scope
- Do not expose credentials in evidence

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Execute bounded interoperability cases
2. Verify task lifecycle and terminal states
3. Verify streaming/push when declared
4. Check artifacts and error mapping
5. Grade READY/DEGRADED/NOT_READY

## Preferred tools

- Official A2A SDK for selected language
- a2actl.py for local evidence normalization
- HTTP/gRPC diagnostics when authorized

## Outputs

- `a2a-verification.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
