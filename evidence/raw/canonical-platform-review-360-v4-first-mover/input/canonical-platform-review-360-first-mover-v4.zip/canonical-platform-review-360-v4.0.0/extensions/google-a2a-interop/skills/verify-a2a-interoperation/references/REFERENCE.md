# Domain rubric

Prove that discovery and negotiation survive actual execution.

## Core checks

- Presence of an A2A endpoint is not PASS
- Test version/error/idempotency behavior appropriate to scope
- Do not expose credentials in evidence
- Execute bounded interoperability cases
- Verify task lifecycle and terminal states
- Verify streaming/push when declared
- Check artifacts and error mapping
- Grade READY/DEGRADED/NOT_READY