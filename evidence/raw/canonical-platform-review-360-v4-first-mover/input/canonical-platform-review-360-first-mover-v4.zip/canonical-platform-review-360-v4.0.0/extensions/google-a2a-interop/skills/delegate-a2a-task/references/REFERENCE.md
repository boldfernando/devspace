# Domain rubric

Bridge canonical tasks to A2A without losing local authority, evidence, trace or resource semantics.

## Core checks

- Remote agent never inherits more authority than delegated
- Preserve local task/buildback identity in correlation metadata
- Treat remote artifacts as unverified until local gate
- Prepare bounded delegation
- Send via negotiated binding/SDK
- Subscribe/poll according to capability
- Collect messages/artifacts/status
- Map remote result back to local evidence