#!/usr/bin/env python3
"""Small local validator/mapper for A2A interoperability evidence. Does not replace the official SDK/spec."""
import argparse,json,hashlib
from pathlib import Path
def main():
 p=argparse.ArgumentParser(); sp=p.add_subparsers(dest='cmd',required=True)
 q=sp.add_parser('inspect-card');q.add_argument('file')
 q=sp.add_parser('task-envelope');q.add_argument('--task-id',required=True);q.add_argument('--context-id');q.add_argument('--text',required=True)
 a=p.parse_args()
 if a.cmd=='inspect-card':
  raw=Path(a.file).read_bytes(); d=json.loads(raw); req=['name','version']; missing=[x for x in req if x not in d]
  caps=d.get('capabilities',{}); interfaces=d.get('supportedInterfaces') or d.get('interfaces') or []
  print(json.dumps({'valid_minimum':not missing,'missing':missing,'name':d.get('name'),'version':d.get('version'),'capabilities':caps,'interfaces':interfaces,'skills':[x.get('id') for x in d.get('skills',[]) if isinstance(x,dict)],'sha256':hashlib.sha256(raw).hexdigest()},indent=2)); raise SystemExit(0 if not missing else 2)
 # Canonical logical representation; binding-specific serialization should use official SDK.
 print(json.dumps({'protocol':'A2A','target_version':'1.0.0','task_id':a.task_id,'context_id':a.context_id,'message':{'role':'user','parts':[{'type':'text','text':a.text}]},'note':'logical envelope; serialize with an official A2A SDK/binding'},indent=2))
if __name__=='__main__':main()
