---
name: discover-a2a-agents
description: "Discover and fingerprint remote A2A agents, Agent Cards, versions, capabilities, skills, interfaces and security metadata."
metadata:
  version: "4.0.0"
  order: "A00"
  family: google-a2a-interop
---

# Discover A2A Agents

## Objective

Make remote-agent discovery evidence-backed and version-aware.

## Operating rules

- Target released A2A 1.0.0 semantics unless peer negotiation proves otherwise
- Agent Card discovery is capability evidence, not trust by itself
- Record card hash/version and authentication requirements

## Definition of Ready (DoR)

- [ ] Mission/buildback/task identifiers are known when applicable
- [ ] Authorization mode and mutation boundary are explicit
- [ ] Required inputs, dependencies and evidence locations are resolvable
- [ ] Resource/authority claims can be evaluated before side effects
- [ ] UNKNOWN semantics and escalation path are accepted

Detailed evidence semantics: `references/DOR_DOD.md`.

## Definition of Done (DoD)

- [ ] Material actions and decisions are correlated to task/agent/trace identifiers
- [ ] Outputs are machine-readable and linked to evidence
- [ ] Failures, conflicts, approvals and UNKNOWNs are preserved rather than hidden
- [ ] Any mutation has verification and rollback/recovery evidence
- [ ] Next gate and residual risk are explicit

## Workflow

1. Resolve candidate endpoint/card
2. Capture immutable/card evidence where possible
3. Parse interfaces/capabilities/skills/security
4. Emit readiness and UNKNOWNs

## Preferred tools

- Official A2A SDK for selected language
- a2actl.py for local evidence normalization
- HTTP/gRPC diagnostics when authorized

## Outputs

- `a2a-agent-inventory.json`
- `a2a-interop-record.json`

## Resources

- `references/REFERENCE.md`
- `references/SOURCES.md`
- `references/DOR_DOD.md`
- `evals/evals.json`
