#!/usr/bin/env bash
set -euo pipefail
scope="${1:-user}"
repo="${2:-.}"
collision="${COLLISION:-fail}"
case "$scope" in user|repo|admin) ;; *) echo "scope must be user|repo|admin" >&2; exit 2;; esac
python3 "$(cd "$(dirname "$0")" && pwd)/skills/install-skill-pack/scripts/install_pack.py" --scope "$scope" --repo "$repo" --collision "$collision" --apply
