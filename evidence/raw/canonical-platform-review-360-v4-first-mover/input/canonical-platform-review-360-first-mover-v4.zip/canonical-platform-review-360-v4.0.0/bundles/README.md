# v4 Bundles

Each ZIP is an opt-in package. The full Canonical package contains all bundles but profiles keep discovery bounded.

- `agent-execution-fabric`: deterministic scheduling, addressing, leases and buildbacks.
- `google-a2a-interop`: A2A 1.0.0 interoperability.
- `h2a-human-agent-profile`: experimental Canonical H2A profile; **not a Google standard**.
- `agent-ui-interop`: A2UI + AG-UI interaction layer.
- `agent-observability`: OTel-aligned AgentOps.
- `adaptive-intelligence`: routing, confidence, context and gated eval learning.
- `first-mover-agent-fabric`: combined extension suite.
