# BB14 — GitHub Intelligence & Learning Loop

**Accountable Actor:** Research Owner

**Primary Agent:** GitHub Research Manager

**Skills:** github-intelligence-sweep, github-discover-repository-universe, github-collect-repository-evidence, github-mine-engineering-intelligence, github-verify-provenance-supply-chain, github-distill-canonical-patterns, github-promote-pattern-to-skill

**Exit Gate:** `INTELLIGENCE_PROMOTED`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
