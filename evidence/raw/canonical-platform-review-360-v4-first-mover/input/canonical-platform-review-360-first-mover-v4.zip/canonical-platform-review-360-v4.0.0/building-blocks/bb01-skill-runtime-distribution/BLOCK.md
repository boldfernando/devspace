# BB01 — Skill Runtime & Distribution

**Accountable Actor:** Platform Administrator

**Primary Agent:** Skill System Agents

**Skills:** bootstrap-skill-system, install-skill-pack, integrate-skill-pack, initialize-skill-runtime

**Exit Gate:** `RUNTIME_READY`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
