# BB00 — Governance & Control Plane

**Accountable Actor:** Mission Owner

**Primary Agent:** Manager Agent

**Skills:** orchestrate-platform-review-360

**Exit Gate:** `MISSION_ACCEPTED`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
