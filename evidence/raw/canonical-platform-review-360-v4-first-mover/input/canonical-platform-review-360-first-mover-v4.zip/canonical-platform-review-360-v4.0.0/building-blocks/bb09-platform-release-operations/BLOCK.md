# BB09 — Platform, Release & Operations

**Accountable Actor:** Platform/SRE Owner

**Primary Agent:** Platform/SRE/Capacity Agents

**Skills:** review-cicd-release, review-observability-sre, review-scalability-cost

**Exit Gate:** `OPERABILITY_READY`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
