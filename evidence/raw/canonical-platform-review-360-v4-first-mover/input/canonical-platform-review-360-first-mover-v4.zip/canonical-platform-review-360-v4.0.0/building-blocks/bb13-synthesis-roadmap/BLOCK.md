# BB13 — Synthesis & Roadmap

**Accountable Actor:** Leadership

**Primary Agent:** Synthesis Agent

**Skills:** synthesize-roadmap-gates

**Exit Gate:** `NEXT_CYCLE_DECIDED`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
