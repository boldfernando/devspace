# BB15 — Agent Execution Fabric

Actor: **Execution Authority**  
Agent: **Execution Manager + deterministic scheduler**  
Gate: **FABRIC_READY**

Skills:
- `plan-buildback`
- `decompose-issue-work`
- `coordinate-agent-execution`
- `reconcile-buildback`
- `verify-promote-buildback`
