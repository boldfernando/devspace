# BB11 — Execution / APPLY

**Accountable Actor:** Change Owner

**Primary Agent:** Execution Manager

**Skills:** execute-skill-workflow

**Exit Gate:** `CHANGE_VERIFIED`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
