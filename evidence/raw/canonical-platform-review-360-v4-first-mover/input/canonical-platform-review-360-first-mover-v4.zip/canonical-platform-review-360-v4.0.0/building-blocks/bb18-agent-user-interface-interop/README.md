# BB18 — Agent/User Interface Interop

Actor: **Experience Owner**  
Agent: **Interaction Gateway Agent**  
Gate: **INTERACTION_READY**

Skills:
- `render-a2ui-interface`
- `bridge-agui-events`
- `present-human-gate`
- `verify-agent-ui-contract`
