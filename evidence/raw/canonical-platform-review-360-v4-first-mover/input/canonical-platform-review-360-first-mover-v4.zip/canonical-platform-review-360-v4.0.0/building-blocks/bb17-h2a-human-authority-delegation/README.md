# BB17 — H2A Human Authority & Delegation

Actor: **Accountable Human Actor**  
Agent: **Human-Agent Control Agent**  
Gate: **HUMAN_AUTHORITY_VALID**

Skills:
- `capture-human-authority`
- `delegate-human-to-agent`
- `request-human-approval`
- `elicit-human-input`
- `accept-revoke-agent-work`
