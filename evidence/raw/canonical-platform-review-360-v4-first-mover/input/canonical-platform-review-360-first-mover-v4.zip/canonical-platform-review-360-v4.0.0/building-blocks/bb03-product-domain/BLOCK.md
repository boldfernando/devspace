# BB03 — Product & Domain

**Accountable Actor:** Product/Domain Owner

**Primary Agent:** Product/Domain Analyst

**Skills:** review-product-jtbd, review-domain-rules-compliance

**Exit Gate:** `PRODUCT_CONTEXT_READY`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
