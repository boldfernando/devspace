# BB04 — Experience

**Accountable Actor:** Product/Design Owner

**Primary Agent:** Experience Auditor

**Skills:** review-ui-design-system, review-ux-journeys, review-accessibility-i18n

**Exit Gate:** `EXPERIENCE_READY`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
