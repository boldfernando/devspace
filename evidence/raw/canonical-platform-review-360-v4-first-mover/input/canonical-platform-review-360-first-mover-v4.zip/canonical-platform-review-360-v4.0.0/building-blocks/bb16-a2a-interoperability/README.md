# BB16 — A2A Interoperability

Actor: **Integration Owner**  
Agent: **A2A Interop Agent**  
Gate: **A2A_READY**

Skills:
- `discover-a2a-agents`
- `negotiate-a2a-capabilities`
- `delegate-a2a-task`
- `verify-a2a-interoperation`
