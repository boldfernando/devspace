# BB05 — Application Architecture

**Accountable Actor:** Technical Lead

**Primary Agent:** Application Architect

**Skills:** review-frontend-architecture, review-fullstack-integration, review-resilience-errors

**Exit Gate:** `ARCHITECTURE_READY`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
