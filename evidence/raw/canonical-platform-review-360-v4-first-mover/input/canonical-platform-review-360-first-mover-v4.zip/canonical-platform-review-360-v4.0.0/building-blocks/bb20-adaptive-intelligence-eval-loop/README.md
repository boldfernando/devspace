# BB20 — Adaptive Intelligence & Eval Loop

Actor: **AI Quality Owner**  
Agent: **Adaptive Quality Manager**  
Gate: **LEARNING_PROMOTION_GATED**

Skills:
- `route-task-by-capability`
- `calibrate-agent-confidence`
- `optimize-context-budget`
- `evolve-agent-evals`
- `govern-agent-learning`
