# BB02 — Discovery & Immutable Baseline

**Accountable Actor:** Engineering Owner

**Primary Agent:** Repository Cartographer

**Skills:** discover-codebase, reconcile-git-state

**Exit Gate:** `BASELINE_FROZEN`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
