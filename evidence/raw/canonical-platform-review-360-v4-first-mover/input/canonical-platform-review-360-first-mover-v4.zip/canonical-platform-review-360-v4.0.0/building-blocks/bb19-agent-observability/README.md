# BB19 — Agent Observability

Actor: **SRE/AgentOps Owner**  
Agent: **AgentOps Analyst**  
Gate: **AGENTOPS_OBSERVABLE**

Skills:
- `instrument-agent-traces`
- `monitor-agent-liveness`
- `analyze-agent-runtime`
- `investigate-agent-failure`
