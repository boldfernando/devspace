# BB10 — Knowledge & Maintainability

**Accountable Actor:** Engineering Owner

**Primary Agent:** Maintainability Agent

**Skills:** review-docs-code-quality

**Exit Gate:** `MAINTAINABILITY_READY`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
