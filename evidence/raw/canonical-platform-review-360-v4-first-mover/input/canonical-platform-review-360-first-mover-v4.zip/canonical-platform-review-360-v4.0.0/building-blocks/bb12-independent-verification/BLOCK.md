# BB12 — Independent Verification

**Accountable Actor:** Release Authority

**Primary Agent:** Independent Verifier

**Skills:** verify-skill-system

**Exit Gate:** `RELEASE_GATE`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
