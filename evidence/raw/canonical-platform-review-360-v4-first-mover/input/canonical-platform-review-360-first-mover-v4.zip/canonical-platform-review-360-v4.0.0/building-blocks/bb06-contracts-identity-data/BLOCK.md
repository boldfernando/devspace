# BB06 — Contracts, Identity & Data

**Accountable Actor:** API/Data/IAM Owners

**Primary Agent:** Contract/Data/IAM Specialists

**Skills:** review-api-contracts, review-data-database, review-auth-iam

**Exit Gate:** `CONTRACT_DATA_FREEZE`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
