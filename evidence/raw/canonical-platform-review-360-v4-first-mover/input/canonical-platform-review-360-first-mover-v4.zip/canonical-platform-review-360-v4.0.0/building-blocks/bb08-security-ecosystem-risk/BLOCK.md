# BB08 — Security & Ecosystem Risk

**Accountable Actor:** Security Authority

**Primary Agent:** AppSec/Third-party Agents

**Skills:** review-security-devsecops, review-third-parties

**Exit Gate:** `SECURITY_ACCEPTED`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
