# BB07 — Quality & Performance

**Accountable Actor:** Quality Owner

**Primary Agent:** Quality/Performance Agents

**Skills:** review-testing-quality, review-web-performance

**Exit Gate:** `QUALITY_BASELINE`

Every execution records DoR, evidence baseline, tools actually used, references governing material claims, artifacts/hashes, DoD, residual UNKNOWNs and the exit-gate decision. Agent delegation never silently transfers Actor accountability.
