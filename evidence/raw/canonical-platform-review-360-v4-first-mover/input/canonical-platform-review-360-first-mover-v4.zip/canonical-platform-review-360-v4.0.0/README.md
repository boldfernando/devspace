# Canonical Platform Review 360 — Default Agent Skills Template

Version **4.0.0**. Contains **29** core domain-agnostic Agent Skills plus an optional **7-skill GitHub Intelligence 360 extension** plus shared evidence contracts and an optional OpenAI Agents SDK runtime scaffold. This is a default canonical template: it contains no product-, company-, industry-, country-, cloud-, framework-, or vendor-specific business assumptions.

## Canonical scope

The pack is intentionally neutral. Product/domain specifics are supplied at runtime through repository evidence, user scope, connected systems, and current authoritative sources. No example domain is treated as the default architecture.

## What is inside

- `skills/` — each child directory is a standalone skill conforming to the open Agent Skills format.
- `agents/openai.yaml` inside every skill — optional OpenAI metadata/policy for ChatGPT/Codex surfaces.
- `references/` — focused domain rubrics and primary/authoritative source registry per skill.
- `evals/evals.json` — starter skill-trigger/output eval cases.
- `assets/finding-template.json` — standalone structured finding template.
- `contracts/` — shared JSON Schemas for evidence, findings, capabilities, gates, and review report.
- `protocols/` — recovered skill-authoring, agent-authoring, evidence, and APPLY protocols.
- `agent-runtime/python/` — optional manager + specialist OpenAI Agents SDK scaffold.
- `scripts/validate_pack.py` — deterministic format validator.
- `install.ps1` / `install.sh` — local installation helpers.

## Install in Codex / ChatGPT desktop local skills

Current OpenAI guidance uses repository skills under `.agents/skills` and user skills under `$HOME/.agents/skills`.

### Windows PowerShell

```powershell
# user scope
.\install.ps1 -Scope user

# repository scope
.\install.ps1 -Scope repo -Repo C:\path\to\repo
```

Existing skills are not replaced unless `-Collision replace` is explicitly supplied. Replacement uses staging + backup + rollback semantics.

### macOS/Linux

```bash
./install.sh user
./install.sh repo /path/to/repo
COLLISION=replace ./install.sh user   # explicit transactional replacement
```

## Validate

```bash
python scripts/validate_pack.py
```


## Operational skill-system lifecycle

Version 2.1 adds six canonical lifecycle skills that make the pack operational rather than merely installable:

1. `bootstrap-skill-system`
2. `install-skill-pack`
3. `integrate-skill-pack`
4. `initialize-skill-runtime`
5. `execute-skill-workflow`
6. `verify-skill-system`

Canonical runtime chain:

`PACKAGE → VALIDATE → INSTALL → INTEGRATE → INITIALIZE → EXECUTE → VERIFY`

These lifecycle skills are domain-, product-, vendor-, and repository-agnostic. They use least privilege, collision detection, explicit mutation authorization, per-skill DoR/DoD, and rollback boundaries. See `protocols/SKILL_SYSTEM_LIFECYCLE_PROTOCOL.md`.

### Codex automation example

```bash
python skills/execute-skill-workflow/scripts/run_codex_skill.py discover-codebase "Review the current repository in READ_ONLY mode" --workspace . --ephemeral
```

For APPLY, the runner maps the execution to `codex exec --sandbox workspace-write`; READ_ONLY retains Codex's default read-only sandbox.

## Review modes

`READ_ONLY | PLAN | APPLY | VERIFY | RELEASE_GATE`

Default to `READ_ONLY` when authorization is ambiguous.

## Core doctrine

`DISCOVER → BASELINE → REVIEW → MEASURE → DIAGNOSE → RECONCILE → PLAN → APPLY(if authorized) → VERIFY → REGRESSION → GATE → REPORT`

See `protocols/CANONICAL_TEMPLATE_PROTOCOL.md` for neutrality rules, plus `protocols/SKILL_AUTHORING_PROTOCOL.md` and `protocols/AGENT_AUTHORING_PROTOCOL.md` for the recovered current protocols and source links.


## DoR / DoD execution gates

Version 2.1 provides a skill-specific **Definition of Ready** and **Definition of Done** to every skill. The compact gate lives in each `SKILL.md`; expanded evidence criteria live in `references/DOR_DOD.md`.

- DoR: `READY | CONDITIONAL | NOT_READY`
- DoD: `DONE | PARTIAL | NOT_DONE`
- Item evidence: `PASS | FAIL | UNKNOWN | NOT_APPLICABLE`
- Shared machine-readable contract: `contracts/dor-dod.schema.json`
- Shared semantics: `protocols/DOR_DOD_PROTOCOL.md`

A skill may proceed as `CONDITIONAL` when missing evidence does not make execution unsafe, but affected conclusions must remain `UNKNOWN`/`PARTIAL`. A skill is not `DONE` merely because a scanner ran or code changed: material claims require evidence and applied changes require executed verification.

## v3.0.0 — GitHub Intelligence Superpower Layer

This release adds a GitHub research/learning extension without contaminating the canonical core.

- `extensions/github-intelligence/skills/` — 7 opt-in GitHub intelligence skills.
- `research/github-360/` — seed hashes, repository corpus, exemplar matrix and pattern catalog derived from the supplied 2026-08-18 corpus.
- `building-blocks/` — BB00..BB14 lifecycle encapsulation.
- `actors/`, `agents/`, `tools/`, `ontology/` — Actor → Agent → Skill → Tool → Reference → Evidence → Gate → Artifact → Decision.
- `references/source-registry.json` — authority-classified, version-aware sources.
- provenance, repository-evidence and canonical-pattern schemas.
- transaction-safe replacement with backup/rollback.
- high-risk skills require explicit invocation.
- install profiles control discovery budget.

### Recommended profiles

```bash
python scripts/install_profile.py --profile lifecycle --scope repo --repo . --apply
python scripts/install_profile.py --profile review --scope repo --repo . --apply
python scripts/install_profile.py --profile github-intelligence --scope repo --repo . --apply
python scripts/install_profile.py --profile github-review --scope repo --repo . --apply
```

The `full` profile is blocked unless `--allow-large-discovery-surface` is explicitly passed.


## v4.0.0 — First-Mover Agent Fabric

The v4 release adds six **opt-in** packages while keeping the 29-skill canonical core and 7-skill GitHub Intelligence extension intact:

1. `agent-execution-fabric` — deterministic buildback/task DAG, agent addressing, resource leases, isolated writes and reconciliation.
2. `google-a2a-interop` — A2A 1.0.0 discovery, negotiation, delegation and interoperability verification.
3. `h2a-human-agent-profile` — experimental package-defined Human-to-Agent authority/delegation/approval/acceptance profile. **It is not an official Google protocol.**
4. `agent-ui-interop` — A2UI + AG-UI bridge for safe declarative UI and bidirectional human interaction.
5. `agent-observability` — OTel-aligned traces/events/liveness/runtime/failure analysis.
6. `adaptive-intelligence` — capability routing, confidence calibration, context optimization, eval evolution and gated learning.

The high-performance invariant is: `maximize verified useful work / time / risk / cost`, not raw agent count.

### Install bounded v4 profiles

```bash
python scripts/install_profile.py --profile execution-fabric --scope repo --repo . --apply
python scripts/install_profile.py --profile google-a2a-interop --scope repo --repo . --apply
python scripts/install_profile.py --profile h2a-human-agent --scope repo --repo . --apply
python scripts/install_profile.py --profile agent-observability --scope repo --repo . --apply
python scripts/install_profile.py --profile adaptive-intelligence --scope repo --repo . --apply
```

The large `first-mover-fabric` and `full` profiles are blocked by default to protect discovery/context budgets.
