# H2A / A2A / A2UI / AG-UI Investigation — 2026-08-18

## Executive finding

1. The official Google-originated agent interoperability protocol is **A2A (Agent2Agent)**, now an open Linux Foundation standard. The current official specification surface reports released **1.0.0**.
2. Google publishes **A2UI**, with a 2026 v0.9 generation focused on portable, framework-agnostic declarative UI.
3. **AG-UI** is a separate open Agent-User Interaction protocol and explicitly positions itself as complementary to MCP and A2A.
4. This investigation did **not** establish an official Google protocol named H2A. Therefore the package defines H2A only as an **experimental Canonical Human-to-Agent profile**, not as a Google standard.
5. The highest-leverage architecture is layered interoperability: H2A authority semantics + A2A remote delegation + AG-UI bidirectional event interaction + A2UI safe UI intent + deterministic Execution Fabric + OpenTelemetry observability.

## Performance thesis

Increase useful throughput by widening conflict-free parallelism, durable event-driven waiting, routing tasks to eligible specialists, reducing context duplication, and observing critical-path latency. Never trade away authority, verification, provenance or rollback to gain concurrency.

## Sources

- A2A v1.0.0: https://a2a-protocol.org/v1.0.0/
- A2A current specification: https://a2a-protocol.org/latest/specification/
- A2UI v0.9: https://developers.googleblog.com/en/a2ui-v0-9-generative-ui/
- AG-UI project: https://github.com/ag-ui-protocol/ag-ui/
- Google ADK long-running agents: https://developers.googleblog.com/build-long-running-ai-agents-that-pause-resume-and-never-lose-context-with-adk/
- OpenTelemetry semantic conventions: https://opentelemetry.io/docs/specs/semconv/
