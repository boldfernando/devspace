# GitHub Intelligence 360 — Seed-Derived Research Layer

Generated for Canonical Platform Review 360 v3.0.0 from the GitHub HTML/CSV seeds supplied on 2026-08-18.

## Corpus

- Locally reproducible extraction: **512** unique repository identities from the mounted HTML/CSV seeds.
- Deep Research reported a 511-repository combined corpus (160 HTML-seed repositories + 351 supplemental catalog rows). This package preserves the locally reproducible corpus and records the research-reported total separately instead of fabricating identities.
- Catalog entries remain `seed_metadata_only` until a collector pins a commit SHA and captures repository evidence.

## Core conclusion

`Seed → Repository Universe → Immutable SHA Baseline → Code/History/Governance Evidence → Pattern → Adopt/Adapt/Avoid → Building Block → Skill → Eval → Provenance`

`Trending`, stars, forks, README quality and tool presence are discovery signals, not proof of security, quality or production readiness.

## Exemplars highlighted by the research

- `github/gh-aw`: agent/workflow control plane, skills, schemas/specs, observability, governance and cost surfaces.
- `github/spec-kit`: specification-driven development and implementation planning.
- `anthropics/skills`, `google/skills`, `vercel-labs/agent-skills`: skill/plugin packaging and distribution patterns.
- `go-gitea/gitea`, `aquasecurity/trivy`: conventional engineering/security exemplars.

## Evidence doctrine

`TOOL PRESENT != TOOL EXECUTED ON TARGET SHA != CLEAN RESULT != RISK ACCEPTED`
