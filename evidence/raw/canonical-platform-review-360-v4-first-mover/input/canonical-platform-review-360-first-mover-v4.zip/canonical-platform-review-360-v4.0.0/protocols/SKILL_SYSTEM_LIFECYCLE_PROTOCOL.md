# Skill System Lifecycle Protocol

This protocol defines the canonical operational lifecycle for a reusable Agent Skills pack.

## State machine

`PACKAGE → VALIDATE → INSTALL → INTEGRATE → INITIALIZE → EXECUTE → VERIFY → READY/DEGRADED/NOT_READY`

The stages are intentionally separate. A copied directory is not proof of discovery; discovery is not proof of activation; activation is not proof of correct output.

## Installation

Resolve scope explicitly. Agent Skills itself does not mandate a filesystem location. Cross-client implementations commonly use `.agents/skills`. Current Codex local discovery includes repository `.agents/skills`, user `$HOME/.agents/skills`, admin `/etc/codex/skills`, and system-bundled skills. Detect collisions before writes and never replace without an explicit decision.

## Integration

Parse frontmatter, build the catalog, respect project trust boundaries, detect same-name collisions, inspect optional `agents/openai.yaml`, and verify declared dependencies. Custom clients should implement discover → parse → catalog → activate with progressive disclosure.

## Initialization

Create a run identity with pack version, repository/workspace provenance, execution mode, sandbox/permission boundary, tool availability, requested skill set, and output location. Do not run domain work during initialization.

## Execution

Prefer explicit skill activation for automation. In Codex CLI/IDE, `$skill-name` explicitly mentions a skill; `/skills` lists skills. `codex exec` is appropriate for non-interactive automation and runs read-only by default. Raise to `--sandbox workspace-write` only for authorized APPLY work. Preserve each skill's own DoR/DoD. Parallelize read-heavy independent work; serialize or isolate conflicting write-heavy work.

## Verification

Verify structure, installed/source version, visibility, collisions, dependency readiness, activation smoke behavior, and eval health when a runtime/budget is available. Return `READY | DEGRADED | NOT_READY`.

## Sources

- https://agentskills.io/specification
- https://agentskills.io/client-implementation/adding-skills-support
- https://developers.openai.com/codex/skills
- https://developers.openai.com/codex/non-interactive-mode
- https://developers.openai.com/codex/subagents
- https://openai.github.io/openai-agents-python/ref/sandbox/capabilities/skills/
