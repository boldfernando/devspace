# Agent Observability Protocol v4

Correlate every event through `mission_id`, `buildback_id`, `issue_id`, `task_id`, `agent_address`, `attempt`, `trace_id`, and where present `A2A task/context IDs` plus `H2A delegation/approval IDs`.

## Signals

- traces: orchestration, agent run, model call, tool call, A2A exchange, human gate, verification, merge;
- metrics: queue wait, cycle time, lease wait, conflicts prevented, stale bases, retries, verification failures, tokens, cost, critical path;
- events: append-only lifecycle journal;
- logs: structured, correlated, redacted;
- artifacts/evidence: hash-addressed where possible.

Sensitive prompt/response content is opt-in. Metadata-first observability is the default.
