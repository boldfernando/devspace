# GitHub Intelligence & Learning Protocol

## Evidence levels

1. `seed_metadata_only` — HTML/catalog/search discovery identity.
2. `repository_metadata` — API metadata, refs, issues/PR/workflow inventory.
3. `sha_pinned_static` — exact SHA, source/tree, static/build/test/security evidence.
4. `runtime_dynamic` — authorized runtime traces, performance, data/query and operational evidence.

Never promote a claim to a higher level by inference.

## Learning loop

`Seed → Universe → Immutable Baseline → Evidence Graph → Pattern → Adopt/Adapt/Avoid → Building Block → Skill Draft → Eval → Approval → Install → Observe → New Evidence`

A pattern becomes canonical only when scope, applicability, counter-evidence, authority references, provenance and eval behavior are explicit. Popularity is never a promotion criterion.
