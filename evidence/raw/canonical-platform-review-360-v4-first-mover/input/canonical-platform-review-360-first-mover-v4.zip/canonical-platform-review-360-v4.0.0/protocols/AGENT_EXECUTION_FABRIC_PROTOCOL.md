# Agent Execution Fabric Protocol

The fabric is deterministic infrastructure between orchestrators and worker agents.

## Invariants

1. No agent instance without an address.
2. No mutable task without an isolated workspace or equivalent transactional boundary.
3. No write without a resource claim/lease.
4. No lease without TTL and liveness policy.
5. No integration without base-SHA freshness check and verification.
6. No buildback promotion without evidence graph and independent gate.
7. Scheduler/lease/event-journal logic is deterministic code, not an LLM responsibility.

## Canonical agent address

`agent://<repo>/<buildback>/<issue>/<task>/<role>/<attempt>`

## Buildback

A buildback is the transactional envelope from immutable baseline through issue/task decomposition, isolated execution, reconciliation, verification, merge and promotion/rollback.

## Conflict model

The scheduler evaluates both file/path claims and semantic resources. Different files can still conflict when they mutate the same contract, schema, migration chain, environment, release surface or policy object.

## Execution graph

`Issue Graph + Task DAG + Resource Conflict Graph + Approval Graph = Execution Topology`.
