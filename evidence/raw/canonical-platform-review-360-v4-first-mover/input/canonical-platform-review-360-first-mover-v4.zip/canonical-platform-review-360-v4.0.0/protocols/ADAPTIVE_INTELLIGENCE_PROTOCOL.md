# Adaptive Intelligence Protocol

The objective is not maximum autonomy. It is maximum **verified useful work per unit of time/risk/cost**.

Decision loop:

`classify → route → execute → observe → verify → grade → learn → promote only after eval`.

The router scores capability fit, evidence needs, tool availability, risk class, latency/cost budget, historical verification rate and conflict pressure. Model/agent choices remain replaceable. Self-improvement produces proposals and eval candidates; it never silently rewrites production policy or installs skills.
