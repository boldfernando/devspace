# Protocol Positioning v4

## Stable external protocols

- **A2A (Agent2Agent)**: open agent-to-agent interoperability standard, originally developed by Google and now under the Linux Foundation. The v4 package targets A2A **1.0.0** semantics for discovery, tasks, messages, artifacts, streaming, extensions, security and protocol bindings.
- **A2UI (Agent-to-User Interface)**: Google-led open project for safe declarative agent-generated UI. The v4 package tracks the **0.9** generation described by Google in 2026.
- **AG-UI (Agent-User Interaction)**: open event protocol for bidirectional agent/frontend interaction, lifecycle events, state synchronization, tool events and human-in-the-loop interaction.
- **OpenTelemetry**: vendor-neutral observability substrate. v4 maps execution-fabric identifiers onto GenAI/RPC/HTTP conventions while keeping sensitive content opt-in.

## Experimental package profile

**H2A (Human-to-Agent) in this package is NOT claimed to be an official Google protocol.** It is an experimental Canonical interaction profile that defines human authority, delegation, approval, elicitation, revocation, expiry, acceptance and evidence semantics. It can be transported over existing A2A/AG-UI/A2UI-capable systems without redefining their normative wire protocols.

H2A status: `EXPERIMENTAL / package-defined / v0.1`.

## Separation of concerns

- MCP/tool APIs: agent ↔ tools/data.
- A2A: agent ↔ remote agent.
- AG-UI: agent backend ↔ user-facing application event stream.
- A2UI: agent → declarative native UI intent.
- H2A profile: human authority → agent delegation/control/acceptance semantics.
- Execution Fabric: deterministic scheduling, addressing, leases, workspaces and merge coordination.
