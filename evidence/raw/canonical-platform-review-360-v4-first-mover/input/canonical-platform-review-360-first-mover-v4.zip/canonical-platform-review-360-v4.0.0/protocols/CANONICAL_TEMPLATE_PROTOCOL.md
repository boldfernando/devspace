# Canonical Default Template Protocol

## Purpose

Keep the pack reusable across products, organizations, industries, jurisdictions, clouds, frameworks, and repositories.

## Non-negotiables

1. **No hidden domain default.** Do not assume energy, finance, healthcare, commerce, government, or any other business domain.
2. **No hidden jurisdiction.** Applicable legal/regulatory context must be discovered or supplied at runtime.
3. **No hidden stack.** Detect language, framework, database, cloud, package manager, API style, auth, CI/CD, and observability before prescribing tools.
4. **No hidden vendor.** Prefer existing project authority and portable contracts; vendor-specific guidance is conditional.
5. **No hidden lifecycle stage.** Distinguish discovery, implementation, migration, release, incident, audit, and decommissioning contexts.
6. **Evidence first.** Repository/runtime evidence establishes AS-IS; standards and best practices establish comparison criteria, not fictional implementation state.
7. **Specificity is injected, not baked in.** Runtime scope may specialize any skill through inputs, references, connected data, or local policies without mutating the canonical base.
8. **DoR/DoD remain universal in semantics but specialized in evidence.** READY/DONE decisions are scoped to the actual capability and baseline.
9. **Unknown stays UNKNOWN.** Missing domain, authority, runtime, or test evidence cannot become PASS by assumption.
10. **Fork only for durable specialization.** If a domain repeatedly requires its own vocabulary, rules, tools, outputs, and evals, create a derived pack rather than contaminating the canonical template.

## Runtime specialization envelope

Every execution should establish, where relevant:

- organization/product/system scope;
- repository/workspace and commit baseline;
- lifecycle stage and authorization mode;
- stack/runtime/environment;
- users/JTBDs/critical journeys;
- data classification and tenancy model;
- domain rules and applicable authority hierarchy;
- service/provider dependencies;
- SLO/security/accessibility/compliance targets;
- release decision and evidence consumer.

The canonical pack remains unchanged after specialization unless the user explicitly requests a derived template.
