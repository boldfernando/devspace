# APPLY Protocol

Modes: `READ_ONLY`, `PLAN`, `APPLY`, `VERIFY`, `RELEASE_GATE`.

Before mutation:
1. Capture baseline SHA and working-tree state.
2. Confirm authorization and target environment.
3. Record user changes and preserve them.
4. Define the smallest reversible patch and rollback.
5. Choose the narrowest verification that can prove the change.

During mutation:
- Serialize changes that touch shared contracts/schema/migrations.
- Never mix unrelated cleanup with a critical fix.
- Do not mutate production data during a review unless explicitly authorized for that exact operation.

After mutation:
1. Run narrow verification.
2. Run regression checks appropriate to blast radius.
3. Capture new evidence.
4. Report residual risk and any unexecuted checks as UNKNOWN/BLOCKED.
