# Agent Authoring Protocol

This protocol follows current OpenAI Agents SDK guidance.

## Core unit

An agent packages a model, instructions, and optional tools, guardrails, MCP servers, handoffs, structured output, state, and hooks. Start with one focused agent. Add specialists only when capability isolation, policy isolation, prompt clarity, or trace legibility materially improves.

## Orchestration choice

- Use **handoffs** when the specialist should take ownership of the next branch/answer.
- Use **agents as tools** when a manager should retain ownership of the final answer and call bounded specialists.

Canonical Platform Review 360 defaults to manager-style orchestration because the 360 orchestrator must reconcile evidence and own the final release decision.

## Build procedure

1. Define the job, input/output contract, evidence requirements, and side-effect boundary.
2. Create one agent with clear static instructions and the minimum tools needed.
3. Add specialists only when their instructions/tools/policy are meaningfully different.
4. Add guardrails for automatic input/output/tool validation.
5. Add human approvals before sensitive side effects such as edits, shell commands, destructive operations, or sensitive MCP actions.
6. Choose state intentionally: stateless, session-backed, or resumable workflow state.
7. Enable tracing and inspect tool calls, handoffs, guardrails, and custom spans.
8. Add evals using realistic cases, graders/assertions, and regression scenarios.
9. Use SandboxAgent when the result depends on filesystem work, commands, packages, persistent workspace artifacts, or resumable sandbox state.
10. For SandboxAgent skill loading, use the built-in Skills capability rather than manually mounting `.agents/skills`.

## Safety boundary

The model may propose actions. Tool permissions, approvals, environment isolation, and authorization determine whether actions may execute. Never encode secrets in prompts or skill files.

## Sources

- https://developers.openai.com/api/docs/guides/agents
- https://developers.openai.com/api/docs/guides/agents/define-agents
- https://developers.openai.com/api/docs/guides/agents/orchestration
- https://developers.openai.com/api/docs/guides/agents/guardrails-approvals
- https://developers.openai.com/api/docs/guides/agents/running-agents
- https://developers.openai.com/api/docs/guides/agents/sandboxes
- https://developers.openai.com/api/docs/guides/agent-evals
- https://github.com/openai/openai-agents-python
- https://github.com/openai/openai-agents-js
