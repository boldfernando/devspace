# Evidence Protocol

## Rule

Evidence precedes inference. Missing evidence is `UNKNOWN`, not `PASS` and not automatically `FAIL`.

## Precedence

1. Executed runtime behavior and tests
2. Runtime/database/infrastructure state
3. Versioned source and contracts
4. CI artifacts and deployment metadata
5. Project documentation/runbooks
6. Official technology/standard/regulatory sources
7. Secondary sources

## Required fields

Use `contracts/evidence.schema.json` and `contracts/finding.schema.json`.

Every material finding should state observation, expected state, actual state, impact, evidence, confidence, recommendation, verification, and rollback when a change is applied.

## Time sensitivity

External rules, provider docs, pricing, quotas, regulations, security advisories, and platform behavior must include retrieval/effective date or be re-verified when material.
