# Definition of Ready and Definition of Done Protocol

This protocol standardizes execution gates across the Canonical Platform Review 360 skill pack. It is intentionally evidence-driven: checklist items are not declarations of intent; they require an evidence pointer, an explicit UNKNOWN, or a justified NOT_APPLICABLE.

## Definition of Ready (DoR)

DoR answers: **Is this skill sufficiently prepared to start meaningful work without creating avoidable risk, ambiguity, or waste?**

Statuses:

- `READY`: all mandatory readiness criteria are satisfied; non-critical gaps are understood.
- `CONDITIONAL`: work may proceed only in bounded/read-only scope; missing prerequisites constrain conclusions to `UNKNOWN`/`PARTIAL`.
- `NOT_READY`: a blocker prevents safe or meaningful execution.

Rules:

1. DoR is checked before expensive scans, mutation, active tests, or environment changes.
2. Missing evidence is not auto-failure if the skill can proceed safely; it becomes `CONDITIONAL` and the affected conclusion remains `UNKNOWN`.
3. Authorization, destructive-action safety, secret handling, and target identity are hard gates where applicable.
4. A DoR decision must record the baseline and timestamp because repository, runtime, remote, regulatory, and provider states drift.

## Definition of Done (DoD)

DoD answers: **Has the skill produced the evidence, verification, outputs, and handoff needed for downstream decisions?**

Statuses:

- `DONE`: all mandatory completion criteria are satisfied and no unresolved blocker invalidates the result.
- `PARTIAL`: useful work was completed but scoped evidence/verification is missing; affected gates remain `PARTIAL`/`UNKNOWN`.
- `NOT_DONE`: one or more mandatory completion criteria or critical blockers remain unresolved.

Rules:

1. DoD is outcome- and evidence-based. “Code changed”, “scanner ran”, or “document written” is not sufficient.
2. Every material claim must point to evidence; every applied change needs verification; every high-risk mutation needs rollback.
3. Unexecuted tests are never `PASS`. Skipped or inaccessible surfaces are explicitly represented.
4. Handoffs include residual risks, blockers, unknowns, gate state, and the exact baseline evaluated.

## Mandatory record

For every skill execution, record:

```json
{
  "skill": "skill-name",
  "baseline": "commit/environment/evidence snapshot",
  "dor_status": "READY|CONDITIONAL|NOT_READY",
  "dor_blockers": [],
  "dod_status": "DONE|PARTIAL|NOT_DONE",
  "dod_blockers": [],
  "evidence": [],
  "verification": [],
  "residual_risks": [],
  "completed_at": "ISO-8601"
}
```
