# Skill Authoring Protocol

This protocol follows the open Agent Skills specification and the current OpenAI skill authoring guidance.

## Canonical structure

A skill is a directory containing `SKILL.md`. Optional directories are `scripts/`, `references/`, and `assets/`. OpenAI surfaces additionally support optional `agents/openai.yaml` for presentation, invocation policy, and declared tool dependencies.

## Frontmatter contract

`SKILL.md` starts with YAML frontmatter. `name` and `description` are required. The name must be 1-64 lowercase alphanumeric/hyphen characters, cannot begin/end with a hyphen, cannot contain consecutive hyphens, and must match the parent directory. `description` must be non-empty, at most 1024 characters, and should say what the skill does and when it should be used.

## Progressive disclosure

Keep discovery metadata concise. The host initially sees name/description, then loads full `SKILL.md` only when selected. Keep the main instructions focused and move detailed references into one-level-deep `references/` files. The open specification recommends under 500 lines for `SKILL.md`.

## Authoring procedure

1. Choose one focused reusable job and define explicit non-goals.
2. Collect project-specific source material first: code, runbooks, contracts, incident history, tests, review comments, and real failures.
3. Write a concise trigger description around user intent, including should-trigger and should-not-trigger boundaries.
4. Define explicit inputs, outputs, evidence rules, failure modes, and done criteria.
5. Prefer instructions to scripts. Add deterministic scripts only when a command sequence is fragile, repetitive, or benefits from structured output.
6. Use relative file references from the skill root. Avoid deep reference chains.
7. Add 2-3 realistic eval cases initially, including at least one boundary/negative case. Compare with-skill against baseline/previous version.
8. Run the validation harness, execute the skill on real work, inspect traces, and refine wasted or ambiguous steps.
9. Version the skill and update references when protocols or domain standards change.

## OpenAI-specific optional metadata

`agents/openai.yaml` can define `interface`, `policy.allow_implicit_invocation`, and tool dependencies. This pack uses it for user-facing naming and invocation metadata without forcing external MCP dependencies.

## Sources

- https://agentskills.io/specification
- https://agentskills.io/skill-creation/best-practices
- https://agentskills.io/skill-creation/optimizing-descriptions
- https://agentskills.io/skill-creation/using-scripts
- https://agentskills.io/skill-creation/evaluating-skills
- https://developers.openai.com/codex/build-skills
