# Canonical H2A Human-to-Agent Interaction Profile v0.1

Status: **EXPERIMENTAL**. This is a package-defined profile, not a Google standard.

## Purpose

H2A makes human authority a first-class machine-readable input to agent execution. It prevents a user message from being silently interpreted as unlimited execution authority.

## Core objects

`HumanActor`, `AuthorityGrant`, `Delegation`, `Elicitation`, `ApprovalRequest`, `ApprovalDecision`, `Revocation`, `Acceptance`, `H2AEvent`.

## Addressing

`h2a://<authority-domain>/<mission>/<buildback>/<issue>/<task>/<actor>/<interaction>`

## State machine

`DRAFT → AUTHORIZED → DELEGATED → ACKNOWLEDGED → EXECUTING → {NEEDS_INPUT | APPROVAL_REQUIRED | VERIFYING} → {ACCEPTED | REJECTED}`

Terminal/exception states: `REVOKED | EXPIRED | FAILED | CANCELLED`.

## Authority rules

1. Authority is scoped to explicit actions and resources.
2. Authority may have amount/time/risk constraints.
3. Absence of authority is not consent.
4. Approval for one task does not transitively approve siblings or descendants unless the grant says so.
5. Revocation takes effect for future side effects; in-flight irreversible effects must be reported.
6. High-risk side effects require explicit approval tokens or equivalent host-confirmed gates.
7. Acceptance of an artifact is separate from authorization to produce it.

## Transport mapping

H2A metadata MAY be carried as A2A extension metadata, AG-UI custom/interaction events or application metadata. A2UI may render approval/elicitation interfaces. The H2A profile does not replace those protocols.

## Minimum audit envelope

`actor_id, authority_grant_id, delegation_id, action, resources, risk_class, issued_at, expires_at, revocable, approval_policy, trace_id, task_id, buildback_id`.
