# Canonical Engineering Intelligence Ontology

`Actor → Agent → Skill → Tool → Reference → Evidence → Gate → Artifact → Decision`

Every material object may also carry `Source → Version → Hash → Provenance`.

- Actor owns accountability/authority.
- Agent receives delegated responsibility, not silent accountability transfer.
- Skill is the reusable procedure/behavioral contract.
- Tool is a bounded capability.
- Reference governs a claim with authority class/version/applicability.
- Evidence proves an observation against a baseline.
- Gate decides whether work can start, finish or progress.
- Artifact is a durable, preferably hashable output.
- Decision remains attributable to the accountable Actor or explicit delegate.
