# Architecture

## Canonical neutrality

The pack is a default template. It must not assume a company, product, industry, jurisdiction, cloud, framework, database, identity provider, or regulatory regime. Specialists first discover the active context and then bind conclusions to evidence. Domain-specific rules are routed through `review-domain-rules-compliance`, which loads applicable authorities/policies at runtime instead of embedding a default domain.


The pack uses a manager-style control plane:

1. `orchestrate-platform-review-360` owns scope, baseline, authorization mode, evidence reconciliation, and final release decision.
2. Discovery and Git reconciliation establish the factual baseline.
3. Specialist skills review bounded domains independently where safe.
4. Shared schemas normalize findings/evidence.
5. `synthesize-roadmap-gates` deduplicates root causes, builds dependencies, and computes gates without averaging away blockers.

For OpenAI Agents SDK, the recommended orchestration is agents-as-tools because the manager should retain final-answer ownership. Handoffs remain appropriate for workflows where a specialist should take over a branch.


## DoR/DoD gates

Every specialist now exposes a pre-execution Definition of Ready and a post-execution Definition of Done. The orchestrator treats these as control-plane gates: `NOT_READY` prevents unsafe execution; `CONDITIONAL` constrains scope; `PARTIAL`/`NOT_DONE` propagates to release-gate synthesis rather than being coerced to GREEN.


## Skill System Lifecycle Plane

The canonical pack now has a control plane above the review specialists:

`bootstrap-skill-system`
→ `install-skill-pack`
→ `integrate-skill-pack`
→ `initialize-skill-runtime`
→ `execute-skill-workflow`
→ `verify-skill-system`

This plane manages availability and execution of skills. It does not replace the review-domain orchestrator; once initialized, `execute-skill-workflow` may invoke `orchestrate-platform-review-360` or any bounded specialist.


# v3 Intelligence Plane

Three separable planes now coexist: **Control Plane**, **Review Plane**, and optional **GitHub Intelligence Plane**. The Intelligence Plane may propose patterns/skills but cannot silently promote or install them. BB14 closes the learning loop back into BB00/BB01/BB13.


# v4 Agent Fabric

Six planes may now compose without forcing a monolith: **Control**, **Execution Fabric**, **Review**, **Interoperability (A2A/H2A/UI)**, **Observability**, and **Adaptive Intelligence**. Scheduler/lease/event-journal components are deterministic; LLM agents remain responsible for bounded reasoning. H2A is an experimental package profile, explicitly not a Google standard.
