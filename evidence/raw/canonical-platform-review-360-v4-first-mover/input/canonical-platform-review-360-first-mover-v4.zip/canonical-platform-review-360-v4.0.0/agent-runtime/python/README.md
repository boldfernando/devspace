# OpenAI Agents SDK runtime scaffold

This is an optional runtime example. The skill pack itself does not require the OpenAI API.

## Design

The manager owns the final answer and exposes specialist agents as tools, matching the OpenAI manager-style orchestration pattern. Each specialist loads only its own `SKILL.md`, preserving focused context. For workspace execution with shell/filesystem, prefer SandboxAgent and the built-in Skills capability described in the official Sandbox Agents guide.

## Run

Requires `OPENAI_API_KEY` and Python 3.10+.

```bash
uv run python main.py "Run a READ_ONLY 360 review of the current repository"
```

This scaffold intentionally does not grant shell/filesystem tools. Attach tools/approvals/sandbox capability in the deployment environment according to `protocols/AGENT_AUTHORING_PROTOCOL.md`.


## Lifecycle bootstrap

Before running the review manager, use the operational lifecycle skills or equivalent host-native steps to validate, install/mount, integrate, initialize, and verify the skill pack.
