from __future__ import annotations
import asyncio
import re
import sys
from pathlib import Path
from agents import Agent, Runner

PACK_ROOT = Path(__file__).resolve().parents[2]
SKILLS_ROOT = PACK_ROOT / "skills"
SPECIALISTS = [
    "discover-codebase", "reconcile-git-state", "review-product-jtbd",
    "review-ui-design-system", "review-ux-journeys", "review-frontend-architecture",
    "review-web-performance", "review-api-contracts", "review-data-database",
    "review-auth-iam", "review-fullstack-integration", "review-resilience-errors",
    "review-testing-quality", "review-security-devsecops", "review-cicd-release",
    "review-observability-sre", "review-scalability-cost", "review-accessibility-i18n",
    "review-third-parties", "review-domain-rules-compliance", "review-docs-code-quality",
    "synthesize-roadmap-gates",
]

def body(skill: str) -> str:
    text = (SKILLS_ROOT / skill / "SKILL.md").read_text(encoding="utf-8")
    return re.sub(r"^---\n.*?\n---\n", "", text, count=1, flags=re.S)

def mk_agent(skill: str) -> Agent:
    return Agent(name=skill, instructions=body(skill))

specialists = {name: mk_agent(name) for name in SPECIALISTS}
manager = Agent(
    name="Canonical Platform Review 360 Manager",
    instructions=body("orchestrate-platform-review-360"),
    tools=[
        a.as_tool(tool_name=name.replace("-", "_"), tool_description=f"Run the bounded {name} specialist review.")
        for name, a in specialists.items()
    ],
)

async def main() -> None:
    prompt = " ".join(sys.argv[1:]).strip() or "Run a READ_ONLY 360 review."
    result = await Runner.run(manager, prompt)
    print(result.final_output)

if __name__ == "__main__":
    asyncio.run(main())
