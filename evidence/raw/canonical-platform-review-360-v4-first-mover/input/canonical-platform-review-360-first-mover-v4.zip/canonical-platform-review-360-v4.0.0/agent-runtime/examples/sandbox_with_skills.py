"""Official-pattern example for loading a released skill repository into SandboxAgent.
Replace owner/repo and configure a supported sandbox client before running.
"""
from agents.sandbox import SandboxAgent
from agents.sandbox.capabilities import Capabilities, Skills
from agents.sandbox.entries import GitRepo

agent = SandboxAgent(
    name="Canonical Platform Review 360",
    instructions="Use the mounted canonical review skills and preserve evidence and approval boundaries.",
    capabilities=Capabilities.default()
    + [Skills(from_=GitRepo(repo="OWNER/canonical-platform-review-360", ref="main"))],
)
